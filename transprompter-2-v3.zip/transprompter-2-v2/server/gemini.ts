import 'dotenv/config';
import type { Request } from 'express';
import { GoogleGenAI } from '@google/genai';

let customApiKey: string | null = null;

export function getEffectiveApiKey(req?: Request): string {
  const headerKey = (req?.headers?.['x-gemini-api-key'] as string || '').trim();
  return headerKey || customApiKey || (process.env.GEMINI_API_KEY || '').trim();
}

export function setCustomApiKey(key: string | null): void {
  customApiKey = key ? key.trim() : null;
}

export function getGeminiClient(req?: Request): { client: GoogleGenAI; key: string } {
  const effectiveKey = getEffectiveApiKey(req);
  if (!effectiveKey) {
    throw new Error('Gemini API key is not configured. Please upload or set your Gemini API key via the header button.');
  }
  return {
    client: new GoogleGenAI({
      apiKey: effectiveKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    }),
    key: effectiveKey,
  };
}

export const DEFAULT_MODEL = 'gemini-3.8-flash';
