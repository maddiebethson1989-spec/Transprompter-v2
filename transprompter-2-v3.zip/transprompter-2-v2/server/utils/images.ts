import type { InlineImage } from '../../src/types';

/** Converts a base64 string / URL / `{data, mimeType}` object into a data URI or URL. */
export function formatImageToDataUriOrUrl(input: string | InlineImage | null | undefined): string {
  if (typeof input === 'string') {
    if (input.startsWith('http://') || input.startsWith('https://') || input.startsWith('data:')) {
      return input;
    }
    return `data:image/png;base64,${input}`;
  }
  if (input && input.data) {
    const mime = input.mimeType || 'image/png';
    return `data:${mime};base64,${input.data}`;
  }
  return '';
}

/** Resolves an image (data URI, https URL, or raw base64) into raw base64 data for Gemini. */
export async function resolveImageBase64(
  input: string
): Promise<{ data: string; mimeType: string } | null> {
  if (!input || typeof input !== 'string') return null;
  const trimmed = input.trim();
  if (trimmed.startsWith('data:')) {
    const mimeMatch = trimmed.match(/^data:([^;]+);base64,/);
    const mimeType = mimeMatch ? mimeMatch[1] : 'image/png';
    const data = trimmed.split(',')[1] || '';
    return data ? { data, mimeType } : null;
  }
  if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
    try {
      const resp = await fetch(trimmed);
      if (!resp.ok) return null;
      const arrayBuffer = await resp.arrayBuffer();
      const mimeType = resp.headers.get('content-type') || 'image/png';
      const data = Buffer.from(arrayBuffer).toString('base64');
      return { data, mimeType };
    } catch {
      return null;
    }
  }
  // Otherwise assume raw base64 string
  return { data: trimmed, mimeType: 'image/png' };
}
