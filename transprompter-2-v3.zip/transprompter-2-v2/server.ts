import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use('/media', express.static(path.resolve(__dirname, 'media')));

let customApiKey: string | null = null;
let customAtlasApiKey: string | null = null;

function getEffectiveApiKey(req?: Request): string {
  const headerKey = (req?.headers['x-gemini-api-key'] as string || '').trim();
  return headerKey || customApiKey || (process.env.GEMINI_API_KEY || '').trim();
}

function getEffectiveAtlasApiKey(req?: Request): string {
  const headerKey = (req?.headers['x-atlascloud-api-key'] as string || '').trim();
  return headerKey || customAtlasApiKey || (process.env.ATLASCLOUD_API_KEY || process.env.FAL_KEY || '').trim();
}

function setCustomAtlasApiKey(key: string | null): void {
  customAtlasApiKey = key ? key.trim() : null;
}

function getGeminiClient(req?: Request): { client: GoogleGenAI; key: string } {
  const effectiveKey = getEffectiveApiKey(req);
  if (!effectiveKey) {
    throw new Error('Gemini API key is not configured. Please upload or set your Gemini API key via the header button.');
  }
  return {
    client: new GoogleGenAI({
      apiKey: effectiveKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    }),
    key: effectiveKey,
  };
}

// Fallback Proxy for global ai references
const ai = new Proxy({} as GoogleGenAI, {
  get(_target, prop) {
    const { client } = getGeminiClient();
    return (client as any)[prop];
  },
});

import { ENHANCE_SYSTEM_PROMPT } from './server/prompts/enhance';
import { KEYFRAME_SYSTEM_PROMPT } from './server/prompts/keyframe';
import {
  DEFAULT_CHAT_SYSTEM_PROMPT,
  OUTFIT_SEARCH_DIRECTIVE,
  buildPipelineContextSummary,
} from './server/prompts/chat';
import { formatImageToDataUriOrUrl, resolveImageBase64 } from './server/utils/images';

const DEFAULT_SYSTEM_PROMPT = ENHANCE_SYSTEM_PROMPT;

// --- Gemini API Key Management Endpoints ---

// Get Gemini Key Status
app.get('/api/gemini/status', (req: Request, res: Response) => {
  const headerKey = (req.headers['x-gemini-api-key'] as string || '').trim();
  const effectiveKey = getEffectiveApiKey(req);
  const isConfigured = Boolean(effectiveKey);
  const isCustom = Boolean(headerKey || customApiKey);
  const maskedKey = isConfigured
    ? effectiveKey.length > 8
      ? `${effectiveKey.slice(0, 6)}••••••••${effectiveKey.slice(-4)}`
      : '••••••••'
    : null;

  res.json({
    configured: isConfigured,
    isCustom,
    source: headerKey ? 'client_header' : customApiKey ? 'uploaded' : process.env.GEMINI_API_KEY ? 'server_env' : 'none',
    maskedKey,
  });
});

// Upload or set custom Gemini API key
app.post('/api/gemini/key', async (req: Request, res: Response) => {
  try {
    const { apiKey } = req.body;
    if (!apiKey || typeof apiKey !== 'string' || !apiKey.trim()) {
      res.status(400).json({ error: 'API key is required' });
      return;
    }

    const cleanKey = apiKey.trim();

    // Verify key validity with a lightweight test call
    const testClient = new GoogleGenAI({
      apiKey: cleanKey,
      httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
    });

    try {
      await testClient.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: 'ping',
      });
    } catch (testErr: any) {
      console.warn('Gemini key validation error:', testErr?.message);
      const msg = testErr?.message || '';
      if (
        msg.includes('API_KEY_INVALID') ||
        msg.includes('API key not valid') ||
        msg.includes('PERMISSION_DENIED')
      ) {
        res.status(400).json({
          error: 'The provided Gemini API key was rejected by Google AI. Please check that the key is valid.',
        });
        return;
      }
    }

    customApiKey = cleanKey;
    const maskedKey = cleanKey.length > 8
      ? `${cleanKey.slice(0, 6)}••••••••${cleanKey.slice(-4)}`
      : '••••••••';

    res.json({
      success: true,
      maskedKey,
      isCustom: true,
      message: 'Gemini API key updated and verified successfully',
    });
  } catch (err: any) {
    console.error('Error setting Gemini API key:', err);
    res.status(500).json({ error: err?.message || 'Failed to save Gemini API key' });
  }
});

// Clear custom Gemini API key and revert to server environment default
app.delete('/api/gemini/key', (_req: Request, res: Response) => {
  customApiKey = null;
  const envKey = (process.env.GEMINI_API_KEY || '').trim();
  const maskedKey = envKey
    ? envKey.length > 8
      ? `${envKey.slice(0, 6)}••••••••${envKey.slice(-4)}`
      : '••••••••'
    : null;

  res.json({
    success: true,
    maskedKey,
    configured: Boolean(envKey),
    isCustom: false,
    message: 'Custom Gemini API key cleared. Reverted to server environment.',
  });
});

// Test Gemini API key connectivity
app.post('/api/gemini/test', async (req: Request, res: Response) => {
  try {
    const { apiKey } = req.body;
    const keyToTest = (apiKey || getEffectiveApiKey(req) || '').trim();
    if (!keyToTest) {
      res.status(400).json({ success: false, error: 'No Gemini API key provided to test' });
      return;
    }

    const testClient = new GoogleGenAI({
      apiKey: keyToTest,
      httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
    });

    await testClient.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: 'ping',
    });

    res.json({
      success: true,
      message: 'Google Gemini API key is valid and connected!',
    });
  } catch (err: any) {
    console.warn('Gemini test failed:', err?.message);
    res.status(400).json({
      success: false,
      error: err?.message || 'Google Gemini API key validation failed.',
    });
  }
});

// Enhance Prompt Endpoint (Core Transprompter 2 functionality)
app.post('/api/enhance-prompt', async (req: Request, res: Response) => {
  try {
    const { client: ai } = getGeminiClient(req);
    const { startImage, endImage, basePrompt, duration = 10, model = 'gemini-3.8-flash' } = req.body;

    if (!basePrompt || !basePrompt.trim()) {
      res.status(400).json({ error: 'Base prompt is required' });
      return;
    }
    if (!startImage?.data || !endImage?.data) {
      res.status(400).json({ error: 'Both Start Frame and End Frame are required for delta analysis' });
      return;
    }

    const dur = Math.max(5, Math.min(30, Number(duration) || 10));
    const systemWithDuration = DEFAULT_SYSTEM_PROMPT.replace(/VIDEO_DURATION/g, dur.toString());

    const userMessage = `USER BASE PROMPT:\n"${basePrompt.trim()}"\n\nVIDEO DURATION: ${dur} seconds total\n\nPlease analyze the two provided keyframes (Start Frame A and End Frame B) and generate the complete video generation prompt and audio design prompt according to your instructions.\n\nCRITICAL INSTRUCTION: When enhancing a prompt that includes dialogue, always specify which character is speaking (both in the visual scene character reactions/mouth movements and in the audio design dialogue track).`;

    const parts = [
      {
        inlineData: {
          mimeType: startImage.mimeType || 'image/png',
          data: startImage.data,
        },
      },
      {
        text: '[Start Frame A — Keyframe Image above]',
      },
      {
        inlineData: {
          mimeType: endImage.mimeType || 'image/png',
          data: endImage.data,
        },
      },
      {
        text: '[End Frame B — Keyframe Image above]',
      },
      {
        text: userMessage,
      },
    ];

    const response = await ai.models.generateContent({
      model: model || 'gemini-3.8-flash',
      contents: { parts },
      config: {
        systemInstruction: systemWithDuration,
        temperature: 0.9,
        topP: 0.95,
      },
    });

    const text = response.text || '';
    res.json({ success: true, text });
  } catch (err: any) {
    console.error('Error enhancing prompt:', err);
    res.status(500).json({ error: err?.message || 'Failed to enhance prompt with Gemini' });
  }
});

// Auto-Draft Base Prompt Endpoint (Visual Delta Analysis between Frame A and Frame B)
app.post('/api/draft-prompt', async (req: Request, res: Response) => {
  try {
    const { client: ai } = getGeminiClient(req);
    const { startImage, endImage, model = 'gemini-3.8-flash' } = req.body;

    if (!startImage?.data || !endImage?.data) {
      res.status(400).json({ error: 'Both Start Frame (A) and End Frame (B) are required to draft a transformation prompt' });
      return;
    }

    const draftSystemInstruction = `You are an expert AI video transformation prompt director and cinematography engineer specializing in WAN 3.0 Image-to-Video interpolation.
Your mission is to perform a detailed visual delta analysis between Start Frame (Image A) and End Frame (Image B) and write a rich, cinematic, and descriptive BASE PROMPT (1-2 paragraphs) ready to guide WAN 3.0.

ANALYSIS & DRAFTING GUIDELINES:
1. Identify the subject(s) in Image A and Image B. Keep character invariant traits consistent (age, ethnicity, facial features, hair color).
2. If an anatomical or gender transformation occurs (e.g., male to female), describe the physical shifts: broad shoulders narrowing, height adjusting, waist curving, facial lines softening, and anatomical changes.
3. Describe the apparel and garment transformation: how clothing tears, dissolves, re-weaves, shrinks, or shifts from Image A into the costume/outfit worn in Image B.
4. Describe the catalyst or trigger (e.g., magical glow, particle dispersion, environmental surge, prop reaction, or cinematic action) that initiates the change.
5. Capture emotional reactions, character physical posturing (shock, disbelief, stagger, hands reaching), and environmental interaction.
6. If character dialogue fits the scene, include attributed dialogue in quotation marks (e.g., The character stammers: "What's happening to me...").
7. OUTPUT FORMAT: Output ONLY the drafted base prompt text itself. Do not add preamble, greetings, markdown headers, or disclaimers.`;

    const parts = [
      {
        inlineData: {
          mimeType: startImage.mimeType || 'image/png',
          data: startImage.data,
        },
      },
      {
        text: '[Start Frame A — Initial State]',
      },
      {
        inlineData: {
          mimeType: endImage.mimeType || 'image/png',
          data: endImage.data,
        },
      },
      {
        text: '[End Frame B — Final State]',
      },
      {
        text: 'Perform visual delta analysis between Start Frame A and End Frame B. Write a rich, cinematic base prompt detailing the transformation catalyst, physical morphology, garment shifts, and character reactions.',
      },
    ];

    const response = await ai.models.generateContent({
      model: model || 'gemini-3.8-flash',
      contents: { parts },
      config: {
        systemInstruction: draftSystemInstruction,
        temperature: 0.85,
        topP: 0.95,
      },
    });

    const text = (response.text || '').trim();
    res.json({ success: true, text });
  } catch (err: any) {
    console.error('Error auto-drafting base prompt:', err);
    res.status(500).json({ error: err?.message || 'Failed to auto-draft prompt from keyframes' });
  }
});

// Image Generation & Editing Endpoint (using gemini-3.1-flash-image)
app.post('/api/generate-image', async (req: Request, res: Response) => {
  try {
    const { client: ai } = getGeminiClient(req);
    const { prompt, imageSize = '2K', aspectRatio = '4:3', baseImage } = req.body;

    if (!prompt || !prompt.trim()) {
      res.status(400).json({ error: 'Prompt is required' });
      return;
    }

    // gemini-3.1-flash-image supports 512px, 1K, 2K, 4K
    const validSizes = ['512px', '1K', '2K', '4K'];
    const chosenSize = validSizes.includes(imageSize) ? imageSize : '2K';
    const chosenRatio = ['16:9', '9:16', '1:1', '4:3', '3:4', '1:4', '4:1'].includes(aspectRatio) ? aspectRatio : '4:3';

    const parts: any[] = [];

    // If an existing image is provided to edit, include it first
    if (baseImage && baseImage.data) {
      parts.push({
        inlineData: {
          data: baseImage.data,
          mimeType: baseImage.mimeType || 'image/png',
        },
      });
    }

    parts.push({ text: prompt.trim() });

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-image',
      contents: {
        parts,
      },
      config: {
        imageConfig: {
          aspectRatio: chosenRatio as any,
          imageSize: chosenSize as any,
        },
        thinkingConfig: {
          thinkingLevel: ThinkingLevel.HIGH,
        },
        tools: [
          {
            googleSearch: {
              searchTypes: {
                webSearch: {},
                imageSearch: {},
              },
            },
          },
        ],
      },
    });

    let resultImageUrl: string | null = null;
    let mimeType = 'image/png';

    const candidates = response.candidates || [];
    for (const candidate of candidates) {
      const parts = candidate.content?.parts || [];
      for (const part of parts) {
        if (part.inlineData?.data) {
          mimeType = part.inlineData.mimeType || 'image/png';
          resultImageUrl = `data:${mimeType};base64,${part.inlineData.data}`;
          break;
        }
      }
      if (resultImageUrl) break;
    }

    if (!resultImageUrl) {
      res.status(500).json({ error: 'No image was generated by the model. Try refining your prompt.' });
      return;
    }

    res.json({
      success: true,
      imageUrl: resultImageUrl,
      mimeType,
      size: chosenSize,
      aspectRatio: chosenRatio,
    });
  } catch (err: any) {
    console.error('Error generating image:', err);
    res.status(500).json({ error: err?.message || 'Failed to generate image' });
  }
});

// Multi-turn Gemini Chatbot Endpoint (supporting gemini-3.8-flash, gemini-3.7-flash, gemini-3.6-flash, gemini-3.5-flash, gemini-3.1-pro-preview, gemini-3.1-flash-lite)
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { client: ai } = getGeminiClient(req);
    const {
      messages,
      model = 'gemini-3.8-flash',
      roleInstruction,
      pipelineContext,
    } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: 'Messages history is required' });
      return;
    }

    const allowedModels = [
      'gemini-3.8-flash',
      'gemini-3.5-flash',
      'gemini-3.1-flash-lite',
    ];
    const chosenModel = allowedModels.includes(model) ? model : 'gemini-3.8-flash';

    let systemInstruction = roleInstruction || DEFAULT_CHAT_SYSTEM_PROMPT;

    // Append current pipeline context (Base prompt, enhanced prompt, keyframes availability)
    if (pipelineContext) {
      systemInstruction += buildPipelineContextSummary(pipelineContext);
    }

    systemInstruction += OUTFIT_SEARCH_DIRECTIVE;

    const contents = messages.map((m: { role: string; content: string }, index: number) => {
      const isAssistant = m.role === 'assistant' || m.role === 'model';
      const parts: any[] = [];

      // If keyframe images are provided, attach them to the latest user message or first user message for multi-modal vision
      if (!isAssistant && index === messages.length - 1 && pipelineContext) {
        if (pipelineContext.startImage?.data) {
          parts.push({
            inlineData: {
              data: pipelineContext.startImage.data,
              mimeType: pipelineContext.startImage.mimeType || 'image/png',
            },
          });
          parts.push({ text: `[Context: Attached above is Start Keyframe (Frame A)]` });
        }
        if (pipelineContext.endImage?.data) {
          parts.push({
            inlineData: {
              data: pipelineContext.endImage.data,
              mimeType: pipelineContext.endImage.mimeType || 'image/png',
            },
          });
          parts.push({ text: `[Context: Attached above is End Keyframe (Frame B)]` });
        }
      }

      parts.push({ text: m.content });

      return {
        role: isAssistant ? 'model' : 'user',
        parts,
      };
    });

    const response = await ai.models.generateContent({
      model: chosenModel,
      contents,
      config: {
        systemInstruction,
        temperature: 0.85,
        tools: [{ googleSearch: {} }],
      },
    });

    const reply = response.text || '';
    const grounding = response.candidates?.[0]?.groundingMetadata;
    const searchQueries: string[] = grounding?.webSearchQueries || [];
    res.json({ success: true, reply, modelUsed: chosenModel, searchQueries });
  } catch (err: any) {
    console.error('Error in chat:', err);
    res.status(500).json({ error: err?.message || 'Chat generation failed' });
  }
});

// Dedicated Keyframe Transformation Scenario & Prompt Copilot Endpoint
app.post('/api/keyframe-chat', async (req: Request, res: Response) => {
  try {
    const { client: ai } = getGeminiClient(req);
    const {
      messages,
      activeImage,
      activeImageMime = 'image/png',
      currentPrompt,
      currentEditPrompt,
      model = 'gemini-3.8-flash',
    } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: 'Messages history is required' });
      return;
    }

    let systemInstructionWithContext = KEYFRAME_SYSTEM_PROMPT;
    if (currentPrompt) {
      systemInstructionWithContext += `\n\nActive Studio Initial Prompt: "${currentPrompt}"`;
    }
    if (currentEditPrompt) {
      systemInstructionWithContext += `\nActive Studio Edit Prompt: "${currentEditPrompt}"`;
    }

    // Safely resolve activeImage whether it is data URI, external URL, or base64
    let resolvedImage: { data: string; mimeType: string } | null = null;
    if (activeImage && typeof activeImage === 'string') {
      resolvedImage = await resolveImageBase64(activeImage);
    }

    const validMessages = messages.filter(
      (m: any) => m && m.content && typeof m.content === 'string' && m.content.trim()
    );

    const contents = validMessages.map((m: { role: string; content: string }, index: number) => {
      const isAssistant = m.role === 'assistant' || m.role === 'model';
      const parts: any[] = [];

      // If activeImage is provided and resolved, attach to the latest user message
      if (!isAssistant && index === validMessages.length - 1 && resolvedImage) {
        parts.push({
          inlineData: {
            data: resolvedImage.data,
            mimeType: resolvedImage.mimeType || activeImageMime || 'image/png',
          },
        });
        parts.push({
          text: `[Active Studio Image attached for visual reference: Analyze the character's clothing colors, hair, body, pose, and background details in this frame]`,
        });
      }

      parts.push({ text: m.content });
      return {
        role: isAssistant ? 'model' : 'user',
        parts,
      };
    });

    // Ensure multiturn chat starts with a user turn (required by Gemini SDK)
    if (contents.length > 0 && contents[0].role === 'model') {
      contents.unshift({
        role: 'user',
        parts: [{ text: 'Hello, please assist me with creating scenario prompts.' }],
      });
    }

    // Detect if this is an idea prompt request to maximize randomness and creativity
    const lastUserMsg = validMessages.filter((m: any) => m.role === 'user').slice(-1)[0]?.content || '';
    const isIdeaRequest = /idea|suggest|random|scenario|batch|roll/i.test(lastUserMsg);
    const dynamicTemperature = isIdeaRequest ? 1.0 : 0.95;

    let response;
    let searchQueries: string[] = [];

    try {
      response = await ai.models.generateContent({
        model: model || 'gemini-3.8-flash',
        contents,
        config: {
          systemInstruction: systemInstructionWithContext,
          temperature: dynamicTemperature,
          tools: [{ googleSearch: {} }],
        },
      });
      const grounding = response.candidates?.[0]?.groundingMetadata;
      searchQueries = grounding?.webSearchQueries || [];
    } catch (searchToolErr: any) {
      console.warn('Google Search grounding fallback in keyframe-chat:', searchToolErr?.message);
      response = await ai.models.generateContent({
        model: model || 'gemini-3.8-flash',
        contents,
        config: {
          systemInstruction: systemInstructionWithContext,
          temperature: dynamicTemperature,
        },
      });
    }

    const reply = response.text || '';
    res.json({ success: true, reply, searchQueries });
  } catch (err: any) {
    console.error('Error in keyframe-chat:', err);
    res.status(500).json({ error: err?.message || 'Keyframe chat failed' });
  }
});

// ==========================================
// AtlasCloud Seedream 5.0 Pro Image Editing API
// https://api.atlascloud.ai (bytedance/seedream-v5.0-pro/edit)
// ==========================================

// Valid AtlasCloud 2K & 1.5K aspect ratio presets
const VALID_ATLAS_SIZES = new Set([
  '2048*2048', '2368*1776', '1776*2368', '2816*1584', '1584*2816',
  '2496*1664', '1664*2496', '3136*1344', '1024*1024', '1536*1536',
  '1776*1328', '1328*1776', '2048*1152', '1152*2048',
]);

function normalizeAtlasSize(requestedSize: any, aspectRatio?: string): string {
  if (typeof requestedSize === 'string') {
    const formatted = requestedSize.replace(/x/g, '*').trim();
    if (VALID_ATLAS_SIZES.has(formatted)) return formatted;
  }
  // Standard aspect ratio defaults from official AtlasCloud presets
  switch (aspectRatio) {
    case '16:9': return '2048*1152';
    case '9:16': return '1152*2048';
    case '1:1': return '2048*2048';
    case '4:3': return '2368*1776';
    case '3:4': return '1776*2368';
    default: return '2048*1152';
  }
}

// Check AtlasCloud API key status
app.get(['/api/atlascloud/status', '/api/fal/status', '/api/video-providers/status'], (req: Request, res: Response) => {
  const effectiveKey = getEffectiveAtlasApiKey(req);
  const isCustom = Boolean(customAtlasApiKey) || Boolean(req.headers['x-atlascloud-api-key']);
  const source = req.headers['x-atlascloud-api-key']
    ? 'request-header'
    : customAtlasApiKey
    ? 'uploaded'
    : process.env.ATLASCLOUD_API_KEY
    ? 'environment'
    : 'none';

  let maskedKey: string | null = null;
  if (effectiveKey) {
    maskedKey = effectiveKey.length > 8 ? `${effectiveKey.slice(0, 6)}••••••••${effectiveKey.slice(-4)}` : '••••••••';
  }

  res.json({
    configured: Boolean(effectiveKey),
    isCustom,
    source,
    maskedKey,
    atlascloud: { configured: Boolean(effectiveKey) },
  });
});

// Save or clear AtlasCloud API key
app.post('/api/atlascloud/key', (req: Request, res: Response) => {
  try {
    const { apiKey } = req.body;
    if (typeof apiKey !== 'string') {
      res.status(400).json({ error: 'API key must be a string' });
      return;
    }
    const cleanKey = apiKey.trim();
    if (!cleanKey) {
      setCustomAtlasApiKey(null);
      res.json({
        success: true,
        message: 'AtlasCloud API key cleared',
        configured: Boolean(process.env.ATLASCLOUD_API_KEY || process.env.FAL_KEY),
      });
      return;
    }
    setCustomAtlasApiKey(cleanKey);
    const maskedKey = cleanKey.length > 8 ? `${cleanKey.slice(0, 6)}••••••••${cleanKey.slice(-4)}` : '••••••••';
    res.json({
      success: true,
      message: 'AtlasCloud API key configured successfully',
      configured: true,
      maskedKey,
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to update AtlasCloud API key' });
  }
});

// Clear custom AtlasCloud API key and revert to environment default
app.delete('/api/atlascloud/key', (_req: Request, res: Response) => {
  setCustomAtlasApiKey(null);
  const envKey = (process.env.ATLASCLOUD_API_KEY || process.env.FAL_KEY || '').trim();
  const maskedKey = envKey
    ? envKey.length > 8
      ? `${envKey.slice(0, 6)}••••••••${envKey.slice(-4)}`
      : '••••••••'
    : null;

  res.json({
    success: true,
    maskedKey,
    configured: Boolean(envKey),
    isCustom: false,
    message: 'Custom AtlasCloud API key cleared. Reverted to server environment.',
  });
});

// Test AtlasCloud API key connectivity
app.post('/api/atlascloud/test', async (req: Request, res: Response) => {
  try {
    const { apiKey } = req.body;
    const keyToTest = (apiKey || getEffectiveAtlasApiKey(req) || '').trim();
    if (!keyToTest) {
      res.status(400).json({ success: false, error: 'No AtlasCloud API key provided to test' });
      return;
    }

    const testRes = await fetch('https://api.atlascloud.ai/api/v1/model/prediction/00000000-0000-0000-0000-000000000000', {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${keyToTest}`,
      },
    });

    if (testRes.status === 401) {
      res.status(401).json({
        success: false,
        error: 'AtlasCloud rejected this key: Unauthorized (401). Please check that your key from console.atlascloud.ai is correct.',
      });
      return;
    }

    res.json({
      success: true,
      message: 'AtlasCloud API key is valid and authorized for Seedream 5.0 Pro!',
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to connect to AtlasCloud API.' });
  }
});

// Step 2: Poll status of ByteDance Seedream 5.0 Pro edit on AtlasCloud
const handleSeedreamStatus = async (req: Request, res: Response) => {
  try {
    const rawId = (req.params.id || (req.params as any)[0] || (req.query.id as string) || '').trim();

    if (!rawId) {
      res.status(400).json({ error: 'Prediction ID is required' });
      return;
    }

    const atlasApiKey = getEffectiveAtlasApiKey(req);
    if (!atlasApiKey) {
      res.status(400).json({ error: 'AtlasCloud API key is missing' });
      return;
    }

    const actualPredictionId = rawId.replace(/^atlas:/, '').replace(/^fal:/, '').replace(/^seedream:/, '');

    const pollResponse = await fetch(`https://api.atlascloud.ai/api/v1/model/prediction/${encodeURIComponent(actualPredictionId)}`, {
      headers: {
        Authorization: `Bearer ${atlasApiKey}`,
      },
    });

    const result = await pollResponse.json().catch(() => null);

    if (!pollResponse.ok || !result) {
      const errMsg = result?.message || result?.error || `AtlasCloud status check failed with HTTP ${pollResponse.status}`;
      res.status(pollResponse.status || 500).json({ error: errMsg });
      return;
    }

    const predictionData = result.data || result;
    const status = String(predictionData.status || '').toLowerCase();

    if (status === 'completed' || status === 'succeeded') {
      const outputs = predictionData.outputs || (predictionData.output ? [predictionData.output] : []);
      const outputUrl = outputs.length > 0 ? outputs[0] : null;

      res.json({
        success: true,
        id: actualPredictionId,
        status: 'completed',
        outputUrl,
        outputs,
      });
      return;
    }

    if (status === 'failed') {
      res.json({
        success: false,
        id: actualPredictionId,
        status: 'failed',
        error: predictionData.error || result.message || 'Seedream 5.0 Pro edit failed on AtlasCloud',
      });
      return;
    }

    res.json({
      success: true,
      id: actualPredictionId,
      status: status === 'in_queue' ? 'in_queue' : 'processing',
    });
  } catch (err: any) {
    console.error('Error checking AtlasCloud Seedream status:', err);
    res.status(500).json({
      error: err?.message || 'Failed to check Seedream status on AtlasCloud',
    });
  }
};

app.get(
  [
    '/api/seedream/status/:id',
    '/api/seedream/status/*',
    '/api/atlascloud/seedream-status/:id',
    '/api/atlascloud/seedream-status/*',
    '/api/fal/seedream-status/:id',
    '/api/fal/seedream-status/*',
    '/api/prediction/:id',
    '/api/prediction/*',
  ],
  handleSeedreamStatus
);

// Step 3: Seedream v5.0 Pro Image Editing Endpoint (AtlasCloud)
// https://api.atlascloud.ai/api/v1/model/generateImage
app.post(
  ['/api/seedream/edit', '/api/atlascloud/seedream-edit', '/api/fal/seedream-edit'],
  async (req: Request, res: Response) => {
    try {
      const atlasApiKey = getEffectiveAtlasApiKey(req);

      if (!atlasApiKey) {
        res.status(400).json({
          error:
            'AtlasCloud API key is missing. Please enter your AtlasCloud API key in the API Keys modal or configure ATLASCLOUD_API_KEY in .env (Get your key from https://console.atlascloud.ai).',
        });
        return;
      }

      const {
        prompt,
        images,
        baseImage,
        size = '2048*1152',
        aspectRatio,
        output_format = 'jpeg',
        background = 'opaque',
        thinking = 'enabled',
        prompt_optimization_mode = 'standard',
        enable_base64_output = false,
      } = req.body;

      if (!prompt || !prompt.trim()) {
        res.status(400).json({ error: 'Prompt is required for image editing' });
        return;
      }

      // Prepare image array (supports up to 10 reference images)
      const rawImages: string[] = [];
      const seen = new Set<string>();

      const addImage = (img: any) => {
        if (!img || rawImages.length >= 10) return;
        const fmt = formatImageToDataUriOrUrl(img);
        if (fmt && !seen.has(fmt)) {
          seen.add(fmt);
          rawImages.push(fmt);
        }
      };

      if (baseImage) {
        addImage(baseImage);
      }

      if (Array.isArray(images) && images.length > 0) {
        for (const img of images) {
          addImage(img);
        }
      }

      if (rawImages.length === 0) {
        res.status(400).json({ error: 'At least one input image is required for editing with Seedream-v5.0-Pro' });
        return;
      }

      console.info(`[AtlasCloud] Submitting Seedream 5.0 Pro edit with ${rawImages.length} reference image(s)`);

      const atlasSize = normalizeAtlasSize(size, aspectRatio);

      const atlasPayload = {
        model: 'bytedance/seedream-v5.0-pro/edit',
        prompt: prompt.trim(),
        images: rawImages,
        size: atlasSize,
        output_format: output_format === 'png' ? 'png' : 'jpeg',
        background: background === 'transparent' ? 'transparent' : 'opaque',
        thinking: thinking === 'disabled' ? 'disabled' : 'enabled',
        prompt_optimization_mode: prompt_optimization_mode === 'fast' ? 'fast' : 'standard',
        enable_base64_output: Boolean(enable_base64_output),
      };

      const generateResponse = await fetch('https://api.atlascloud.ai/api/v1/model/generateImage', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${atlasApiKey}`,
        },
        body: JSON.stringify(atlasPayload),
      });

      const generateResult = await generateResponse.json().catch(() => null);

      if (!generateResponse.ok || !generateResult) {
        const errMsg = generateResult?.message || generateResult?.error || `AtlasCloud error HTTP ${generateResponse.status}`;
        res.status(generateResponse.status || 500).json({ error: errMsg });
        return;
      }

      const predictionId = generateResult.data?.id || generateResult.id;
      if (!predictionId) {
        res.status(500).json({
          error: generateResult.message || 'AtlasCloud did not return a prediction ID',
        });
        return;
      }

      res.json({
        success: true,
        predictionId,
        requestId: predictionId,
        status: 'created',
        createdAt: new Date().toISOString(),
      });
    } catch (err: any) {
      console.error('Error submitting Seedream edit to AtlasCloud:', err);
      res.status(500).json({ error: err?.message || 'Server error submitting Seedream edit to AtlasCloud' });
    }
  }
);

// ==========================================
// AtlasCloud WAN 3.0 Video Generation Endpoints
// Model: alibaba/wan-3.0/image-to-video
// ==========================================

// Step 1: Submit Video Generation Request
app.post(
  ['/api/video/generate', '/api/atlascloud/video/generate', '/api/atlascloud/generate-video'],
  async (req: Request, res: Response) => {
    try {
      const atlasApiKey = getEffectiveAtlasApiKey(req);

      if (!atlasApiKey) {
        res.status(400).json({
          error:
            'AtlasCloud API key is missing. Please enter your AtlasCloud API key in the API Keys modal (top right) or configure ATLASCLOUD_API_KEY in .env (Get your key from https://console.atlascloud.ai).',
        });
        return;
      }

      const {
        prompt,
        image,
        last_image,
        resolution = '1080p',
        duration = 5,
        aspect_ratio,
        audio = true,
        seed = -1,
        model = 'alibaba/wan-3.0/image-to-video',
      } = req.body;

      if (!prompt || !String(prompt).trim()) {
        res.status(400).json({ error: 'Video motion prompt is required.' });
        return;
      }

      const formattedImage = formatImageToDataUriOrUrl(image);
      if (!formattedImage) {
        res.status(400).json({ error: 'Start Frame (image) is required for WAN 3.0 video generation.' });
        return;
      }

      const payload: Record<string, any> = {
        model: model || 'alibaba/wan-3.0/image-to-video',
        prompt: String(prompt).trim(),
        image: formattedImage,
        resolution: resolution || '1080p',
        duration: typeof duration === 'number' ? duration : 5,
        audio: audio !== false,
        seed: typeof seed === 'number' ? seed : -1,
      };

      if (last_image) {
        const formattedLastImage = formatImageToDataUriOrUrl(last_image);
        if (formattedLastImage) {
          payload.last_image = formattedLastImage;
        }
      }

      if (aspect_ratio && typeof aspect_ratio === 'string') {
        payload.aspect_ratio = aspect_ratio;
      }

      console.info(
        `[AtlasCloud] Submitting WAN 3.0 video generation (${payload.resolution}, ${payload.duration}s, hasLastFrame: ${Boolean(
          payload.last_image
        )}, audio: ${payload.audio})`
      );

      const generateResponse = await fetch('https://api.atlascloud.ai/api/v1/model/generateVideo', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${atlasApiKey}`,
        },
        body: JSON.stringify(payload),
      });

      const generateResult = await generateResponse.json().catch(() => null);

      if (!generateResponse.ok || !generateResult) {
        const errMsg =
          generateResult?.message ||
          generateResult?.error ||
          `AtlasCloud video generation failed with HTTP ${generateResponse.status}`;
        res.status(generateResponse.status || 500).json({ error: errMsg });
        return;
      }

      const predictionId = generateResult.data?.id || generateResult.id;
      if (!predictionId) {
        res.status(500).json({
          error: generateResult.message || 'AtlasCloud did not return a prediction ID for video generation',
        });
        return;
      }

      res.json({
        success: true,
        id: predictionId,
        predictionId,
        status: 'created',
        createdAt: new Date().toISOString(),
      });
    } catch (err: any) {
      console.error('Error submitting video generation to AtlasCloud:', err);
      res.status(500).json({
        error: err?.message || 'Server error initiating video generation with AtlasCloud',
      });
    }
  }
);

// Step 2: Poll Video Generation Status
app.get(
  [
    '/api/video/status/:id',
    '/api/video/status/*',
    '/api/atlascloud/video/status/:id',
    '/api/atlascloud/video/status/*',
  ],
  async (req: Request, res: Response) => {
    try {
      const rawId = (req.params.id || (req.params as any)[0] || (req.query.id as string) || '').trim();

      if (!rawId) {
        res.status(400).json({ error: 'Prediction ID is required' });
        return;
      }

      const atlasApiKey = getEffectiveAtlasApiKey(req);
      if (!atlasApiKey) {
        res.status(400).json({ error: 'AtlasCloud API key is missing' });
        return;
      }

      const predictionId = rawId.replace(/^atlas:/, '').replace(/^video:/, '');

      const pollResponse = await fetch(
        `https://api.atlascloud.ai/api/v1/model/prediction/${encodeURIComponent(predictionId)}`,
        {
          headers: {
            Authorization: `Bearer ${atlasApiKey}`,
          },
        }
      );

      const result = await pollResponse.json().catch(() => null);

      if (!pollResponse.ok || !result) {
        const errMsg =
          result?.message || result?.error || `AtlasCloud video polling failed with HTTP ${pollResponse.status}`;
        res.status(pollResponse.status || 500).json({ error: errMsg });
        return;
      }

      const predictionData = result.data || result;
      const status = String(predictionData.status || '').toLowerCase();

      if (status === 'completed' || status === 'succeeded') {
        let outputUrl: string | null = null;
        let outputs: string[] = [];

        if (Array.isArray(predictionData.outputs) && predictionData.outputs.length > 0) {
          outputs = predictionData.outputs
            .map((item: any) => (typeof item === 'string' ? item : item?.url || item?.video_url || ''))
            .filter(Boolean);
          outputUrl = outputs[0] || null;
        } else if (typeof predictionData.output === 'string') {
          outputUrl = predictionData.output;
          outputs = [predictionData.output];
        } else if (predictionData.output && typeof predictionData.output === 'object') {
          outputUrl = predictionData.output.url || predictionData.output.video_url || null;
          if (outputUrl) outputs = [outputUrl];
        } else if (typeof predictionData.output_url === 'string') {
          outputUrl = predictionData.output_url;
          outputs = [predictionData.output_url];
        }

        res.json({
          success: true,
          id: predictionId,
          status: 'completed',
          outputUrl,
          outputs,
        });
        return;
      }

      if (status === 'failed') {
        res.json({
          success: false,
          id: predictionId,
          status: 'failed',
          error: predictionData.error || result.message || 'Video generation failed on AtlasCloud',
        });
        return;
      }

      res.json({
        success: true,
        id: predictionId,
        status: status === 'in_queue' ? 'in_queue' : 'processing',
      });
    } catch (err: any) {
      console.error('Error polling video status from AtlasCloud:', err);
      res.status(500).json({
        error: err?.message || 'Failed to check video generation status on AtlasCloud',
      });
    }
  }
);


// Ensure all unhandled /api/* requests return 404 JSON and never fall through to Vite SPA index.html
app.all('/api/*', (req: Request, res: Response) => {
  res.status(404).json({ error: `API route not found: ${req.method} ${req.originalUrl}` });
});

// Serve frontend in development & production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Transprompter 2 server running at http://0.0.0.0:${port}`);
  });
}

startServer();
