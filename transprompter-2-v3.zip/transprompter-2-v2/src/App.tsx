import React, { useState, useEffect, useRef } from 'react';
import type { KeyframeImage, SplitPromptResult, KeyframeHistoryItem, EnhanceHistoryItem, VideoHistoryItem } from './types';
import { safeFetchJson } from './utils/safeApi';
import {
  saveStudioSession,
  loadStudioSession,
  saveEnhanceHistory,
  loadEnhanceHistory,
  saveVideoHistory,
  loadVideoHistory,
} from './utils/persistentStorage';
import { KeyframeGenerator } from './components/KeyframeGenerator';
import { VideoStudio } from './components/VideoStudio';
import { VfxChatbot } from './components/VfxChatbot';
import { AppHeader, type TabView } from './components/layout/AppHeader';
import { ReferenceKeyframesCard } from './components/enhancer/ReferenceKeyframesCard';
import { PromptInputCard } from './components/enhancer/PromptInputCard';
import { EnhancedOutputCard, type OutputTab } from './components/enhancer/EnhancedOutputCard';
import { EnhanceHistoryCard } from './components/enhancer/EnhanceHistoryCard';
import { STEP_CONFIG, type PresetTemplate } from './constants/enhancer';
import { Sparkles } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabView>('enhancer');

  // Keyframes State
  const [startImage, setStartImage] = useState<KeyframeImage | null>(null);
  const [endImage, setEndImage] = useState<KeyframeImage | null>(null);

  // Video Studio Handover State
  const [videoStudioPrompt, setVideoStudioPrompt] = useState<string>('');
  const [videoStudioStartFrame, setVideoStudioStartFrame] = useState<KeyframeImage | null>(null);
  const [videoStudioEndFrame, setVideoStudioEndFrame] = useState<KeyframeImage | null>(null);

  // Persistent Keyframe Studio image, history, and comparison original state across sessions
  const [studioImage, setStudioImage] = useState<string | null>(() => {
    try {
      return localStorage.getItem('transprompter_studio_image') || null;
    } catch {
      return null;
    }
  });
  const [studioMime, setStudioMime] = useState<string>(() => {
    try {
      return localStorage.getItem('transprompter_studio_mime') || 'image/png';
    } catch {
      return 'image/png';
    }
  });
  const [studioHistory, setStudioHistory] = useState<KeyframeHistoryItem[]>(() => {
    try {
      const stored = localStorage.getItem('transprompter_studio_history');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });
  const [originalForCompare, setOriginalForCompare] = useState<string | null>(() => {
    try {
      return localStorage.getItem('transprompter_original_image_for_edit') || null;
    } catch {
      return null;
    }
  });

  // Restore persistent studio session from IndexedDB on initial mount
  useEffect(() => {
    let isMounted = true;
    loadStudioSession()
      .then((session) => {
        if (!isMounted) return;
        if (session.image) {
          setStudioImage(session.image);
        }
        if (session.mime) {
          setStudioMime(session.mime);
        }
        if (session.history && Array.isArray(session.history) && session.history.length > 0) {
          setStudioHistory(session.history);
        }
        if (session.originalForCompare) {
          setOriginalForCompare(session.originalForCompare);
        }
      })
      .catch((err) => {
        console.warn('Failed to restore persistent session from IndexedDB:', err);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  // Save studio state to persistent storage (IndexedDB + fallback) whenever it changes
  useEffect(() => {
    saveStudioSession({
      image: studioImage,
      mime: studioMime,
      history: studioHistory,
      originalForCompare,
    }).catch((e) => {
      console.warn('Failed to save studio state to persistent storage:', e);
    });
  }, [studioImage, studioMime, studioHistory, originalForCompare]);

  // Enhancer inputs
  const [basePrompt, setBasePrompt] = useState('');
  const [duration, setDuration] = useState<number>(10);
  const [selectedEnhanceModel, setSelectedEnhanceModel] = useState<string>('gemini-3.8-flash');

  // Loading & Step Animation
  const [isGenerating, setIsGenerating] = useState(false);
  const [isDraftingPrompt, setIsDraftingPrompt] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  // Result & Output
  const [result, setResult] = useState<SplitPromptResult | null>(null);
  const [activeOutputTab, setActiveOutputTab] = useState<OutputTab>('full');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Enhancement History
  const [enhanceHistory, setEnhanceHistory] = useState<EnhanceHistoryItem[]>([]);

  // Restore enhancement history from storage on initial mount
  useEffect(() => {
    let isMounted = true;
    loadEnhanceHistory()
      .then((items) => {
        if (isMounted && Array.isArray(items)) {
          setEnhanceHistory(items);
        }
      })
      .catch((err) => {
        console.warn('Failed to restore enhancement history:', err);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  // Video Generation History
  const [videoHistory, setVideoHistory] = useState<VideoHistoryItem[]>([]);

  // Restore video generation history from persistent storage on initial mount
  useEffect(() => {
    let isMounted = true;
    loadVideoHistory()
      .then((items) => {
        if (isMounted && Array.isArray(items)) {
          setVideoHistory(items);
        }
      })
      .catch((err) => {
        console.warn('Failed to restore video generation history:', err);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  const handleUpdateVideoHistory = (
    updater: VideoHistoryItem[] | ((prev: VideoHistoryItem[]) => VideoHistoryItem[])
  ) => {
    setVideoHistory((prev) => {
      const next = typeof updater === 'function' ? updater(prev) : updater;
      saveVideoHistory(next).catch((err) => {
        console.warn('Failed to persist video history:', err);
      });
      return next;
    });
  };

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const outputRef = useRef<HTMLDivElement>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // Convert File to KeyframeImage
  const processImageFile = (file: File): Promise<KeyframeImage> => {
    return new Promise((resolve, reject) => {
      const allowed = ['image/png', 'image/jpeg', 'image/webp'];
      if (!allowed.includes(file.type)) {
        reject(new Error('Only PNG, JPG, or WEBP images are supported.'));
        return;
      }
      if (file.size > 15 * 1024 * 1024) {
        reject(new Error('Image must be under 15MB.'));
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        const resultStr = reader.result as string;
        const base64 = resultStr.split(',')[1];
        resolve({
          data: base64,
          mimeType: file.type,
          previewUrl: URL.createObjectURL(file),
          name: file.name,
        });
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(file);
    });
  };

  const handleFileUpload = async (file: File, which: 'start' | 'end') => {
    try {
      const keyframe = await processImageFile(file);
      if (which === 'start') {
        setStartImage(keyframe);
        showToast('Start Frame (A) uploaded');
      } else {
        setEndImage(keyframe);
        showToast('End Frame (B) uploaded');
      }
    } catch (err: any) {
      showToast(err.message || 'Upload failed');
    }
  };

  // Paste image handler from clipboard
  useEffect(() => {
    const handlePaste = async (e: ClipboardEvent) => {
      if (!e.clipboardData?.items) return;
      for (const item of e.clipboardData.items) {
        if (item.type.startsWith('image/')) {
          const file = item.getAsFile();
          if (!file) continue;
          if (!startImage) {
            await handleFileUpload(file, 'start');
          } else {
            await handleFileUpload(file, 'end');
          }
          break;
        }
      }
    };
    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [startImage, endImage]);

  // Output parser to split into video & audio sections
  const splitOutput = (text: string): SplitPromptResult => {
    const audioMatch = text.match(/###\s*\*?\*?Audio Design[^]*$/i);
    let videoText = text;
    let audioText = '';

    if (audioMatch) {
      audioText = audioMatch[0].trim();
      videoText = text.slice(0, audioMatch.index).trim();
    }

    return {
      full: text,
      video: videoText,
      audio: audioText || '(Audio track section detected within full output)',
    };
  };

  // Download helper for keyframe images
  const handleDownloadFrame = (img: KeyframeImage | null, label: string) => {
    if (!img) return;
    try {
      const a = document.createElement('a');
      a.href = img.previewUrl;
      a.download = `wan3-${label}-${Date.now()}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      showToast(`✓ Downloaded ${label.toUpperCase()} Frame`);
    } catch (err) {
      console.error(err);
      showToast('Failed to download image');
    }
  };

  // Swap Start Frame (A) and End Frame (B)
  const handleSwapFrames = () => {
    if (!startImage && !endImage) {
      showToast('No keyframes to swap');
      return;
    }
    const tempStart = startImage;
    setStartImage(endImage);
    setEndImage(tempStart);
    showToast('⇄ Swapped Start (A) and End (B) Frames');
  };

  // Auto-Draft Base Prompt from Keyframes (Visual Delta Analysis)
  const handleAutoDraftPrompt = async () => {
    if (!startImage || !endImage) {
      showToast('⚠️ Please upload or generate both Frame A and Frame B first');
      return;
    }

    if (basePrompt.trim() && !window.confirm('Auto-draft will replace your current base prompt. Continue?')) {
      return;
    }

    setIsDraftingPrompt(true);
    try {
      const data = await safeFetchJson<{
        success: boolean;
        text?: string;
        error?: string;
      }>('/api/draft-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          startImage: { data: startImage.data, mimeType: startImage.mimeType },
          endImage: { data: endImage.data, mimeType: endImage.mimeType },
          model: selectedEnhanceModel,
        }),
      });

      if (!data.success || !data.text) {
        throw new Error(data.error || 'Failed to auto-draft prompt from keyframes');
      }

      setBasePrompt(data.text);
      showToast('✨ Auto-drafted base prompt from keyframes!');
      setTimeout(() => {
        document.getElementById('base-prompt-frame')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'Failed to auto-draft prompt');
    } finally {
      setIsDraftingPrompt(false);
    }
  };

  // Enhance prompt trigger
  const handleEnhance = async () => {
    if (!startImage) {
      setErrorMessage('Please upload or generate the Start Frame (Image A).');
      return;
    }
    if (!endImage) {
      setErrorMessage('Please upload or generate the End Frame (Image B).');
      return;
    }
    if (!basePrompt.trim()) {
      setErrorMessage('Please enter your base prompt describing the transformation.');
      return;
    }

    setErrorMessage(null);
    setIsGenerating(true);
    setCurrentStep(0);

    // Step cycle animation
    let stepIndex = 0;
    const interval = setInterval(() => {
      if (stepIndex < STEP_CONFIG.length - 1) {
        stepIndex++;
        setCurrentStep(stepIndex);
      }
    }, 2800);

    try {
      const data = await safeFetchJson<{
        success: boolean;
        text?: string;
        error?: string;
      }>('/api/enhance-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          startImage: { data: startImage.data, mimeType: startImage.mimeType },
          endImage: { data: endImage.data, mimeType: endImage.mimeType },
          basePrompt: basePrompt.trim(),
          duration,
          model: selectedEnhanceModel,
        }),
      });

      if (!data.success || !data.text) {
        throw new Error(data.error || 'Failed to enhance prompt with Gemini');
      }

      const split = splitOutput(data.text);
      setResult(split);
      showToast('✨ Cinematic prompt enhanced successfully!');

      // Automatically persist to enhancement history
      const newHistoryItem: EnhanceHistoryItem = {
        id: `enh-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        timestamp: Date.now(),
        basePrompt: basePrompt.trim(),
        enhancedResult: split,
        startFrame: startImage ? { ...startImage } : null,
        endFrame: endImage ? { ...endImage } : null,
        duration,
        model: selectedEnhanceModel,
      };

      setEnhanceHistory((prev) => {
        const updated = [newHistoryItem, ...prev.filter((i) => i.id !== newHistoryItem.id)].slice(0, 50);
        saveEnhanceHistory(updated).catch((e) => console.warn('Failed to save enhance history:', e));
        return updated;
      });

      setTimeout(() => {
        outputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 200);
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'An error occurred during prompt generation');
    } finally {
      clearInterval(interval);
      setIsGenerating(false);
    }
  };

  const handleRestoreEnhanceHistory = (item: EnhanceHistoryItem) => {
    setBasePrompt(item.basePrompt);
    if (item.startFrame) {
      setStartImage(item.startFrame);
    }
    if (item.endFrame) {
      setEndImage(item.endFrame);
    }
    if (item.duration) {
      setDuration(item.duration);
    }
    if (item.model) {
      setSelectedEnhanceModel(item.model);
    }
    setResult(item.enhancedResult);
    showToast('✓ Restored prompt & frames from history');
    setTimeout(() => {
      document.getElementById('base-prompt-frame')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const handleDeleteEnhanceHistory = (id: string) => {
    setEnhanceHistory((prev) => {
      const updated = prev.filter((item) => item.id !== id);
      saveEnhanceHistory(updated).catch((e) => console.warn('Failed to update enhance history after delete:', e));
      return updated;
    });
    showToast('Removed from history');
  };

  const handleClearEnhanceHistory = () => {
    if (window.confirm('Are you sure you want to clear all prompt enhancement history?')) {
      setEnhanceHistory([]);
      saveEnhanceHistory([]).catch((e) => console.warn('Failed to clear enhance history:', e));
      showToast('Prompt enhancement history cleared');
    }
  };

  const copyToClipboard = async (text: string, label: string, section: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedSection(section);
      showToast(`${label} copied!`);
      setTimeout(() => setCopiedSection(null), 2000);
    } catch {
      showToast('Failed to copy to clipboard');
    }
  };

  const handleApplyPreset = (preset: PresetTemplate) => {
    setBasePrompt(preset.prompt);
    setDuration(preset.duration);
    showToast(`Loaded preset: ${preset.title}`);
  };

  const handleSendToVideoGenerator = (promptToSend: string) => {
    setVideoStudioPrompt(promptToSend);
    if (startImage) setVideoStudioStartFrame(startImage);
    if (endImage) setVideoStudioEndFrame(endImage);
    setActiveTab('video_studio');
    showToast('✓ Sent keyframes & prompt to Video Studio!');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0a0a0f] text-[#f1f0f5]">
      {/* Animated Glowing Background Orbs */}
      <div className="bg-orbs" aria-hidden="true">
        <div className="orb orb-1" />
        <div className="orb orb-2" />
        <div className="orb orb-3" />
      </div>

      {/* Header */}
      <AppHeader activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Main Content Area */}
      <main className="flex-1 relative z-10 py-8 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto">
          {/* TAB 1: I2V ENHANCER (Core Transprompter 2) */}
          <div className={activeTab === 'enhancer' ? 'block' : 'hidden'}>
            <div className="flex flex-col gap-7">
              {/* Reference Keyframes Card */}
              <ReferenceKeyframesCard
                startImage={startImage}
                endImage={endImage}
                onClearStart={() => setStartImage(null)}
                onClearEnd={() => setEndImage(null)}
                onSwapFrames={handleSwapFrames}
                onOpenInStudio={(previewUrl, mimeType, label) => {
                  setStudioImage(previewUrl);
                  setStudioMime(mimeType);
                  setActiveTab('keyframe_gen');
                  showToast(`Opened ${label} in Keyframe Studio for editing`);
                }}
                onDownloadFrame={handleDownloadFrame}
                onUploadFile={handleFileUpload}
              />

              {/* Desktop Side-by-Side: Base Prompt Frame (Left) & Enhanced WAN 3.0 Prompt Frame (Right) */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
                {/* Frame 1: Base Prompt Frame */}
                <PromptInputCard
                  basePrompt={basePrompt}
                  onBasePromptChange={setBasePrompt}
                  duration={duration}
                  onDurationChange={setDuration}
                  model={selectedEnhanceModel}
                  onModelChange={setSelectedEnhanceModel}
                  errorMessage={errorMessage}
                  isGenerating={isGenerating}
                  isDraftingPrompt={isDraftingPrompt}
                  onAutoDraftPrompt={handleAutoDraftPrompt}
                  hasKeyframes={Boolean(startImage && endImage)}
                  onClearBasePrompt={() => setBasePrompt('')}
                  onEnhance={handleEnhance}
                  onApplyPreset={handleApplyPreset}
                />

                {/* Frame 2: Enhanced WAN 3.0 Prompt Frame */}
                <EnhancedOutputCard
                  outputRef={outputRef}
                  result={result}
                  isGenerating={isGenerating}
                  currentStep={currentStep}
                  activeOutputTab={activeOutputTab}
                  onOutputTabChange={setActiveOutputTab}
                  copiedSection={copiedSection}
                  onCopy={copyToClipboard}
                  onSendToVideoGenerator={handleSendToVideoGenerator}
                />
              </div>

              {/* Prompt Enhancement History (Base Prompt, Enhanced WAN 3.0 Script, & Keyframe Snapshots) */}
              <EnhanceHistoryCard
                history={enhanceHistory}
                onRestore={handleRestoreEnhanceHistory}
                onDeleteItem={handleDeleteEnhanceHistory}
                onClearHistory={handleClearEnhanceHistory}
                onOpenInStudio={(previewUrl, mimeType, label) => {
                  setStudioImage(previewUrl);
                  setStudioMime(mimeType);
                  setActiveTab('keyframe_gen');
                  showToast(`Opened ${label} in Keyframe Studio for editing`);
                }}
                onShowToast={showToast}
              />

              {/* VFX Director Frame - Positioned below Base Prompt and Enhanced WAN 3.0 Prompt frames */}
              <div id="vfx-director-section" className="w-full pt-1">
                <VfxChatbot
                  startImage={startImage}
                  endImage={endImage}
                  basePrompt={basePrompt}
                  enhancedResult={result}
                  onInsertIntoPrompt={(text) => {
                    setBasePrompt(text);
                    document.getElementById('base-prompt-frame')?.scrollIntoView({ behavior: 'smooth' });
                    showToast('Inserted into Base Prompt input');
                  }}
                  onShowToast={showToast}
                />
              </div>
            </div>
          </div>

          {/* TAB 2: VIDEO STUDIO (WAN 3.0 Video Generation via AtlasCloud) */}
          <div className={activeTab === 'video_studio' ? 'block' : 'hidden'}>
            <VideoStudio
              initialPrompt={videoStudioPrompt}
              initialStartFrame={videoStudioStartFrame || startImage}
              initialEndFrame={videoStudioEndFrame || endImage}
              enhancerStartFrame={startImage}
              enhancerEndFrame={endImage}
              studioImage={studioImage}
              studioMime={studioMime}
              videoHistory={videoHistory}
              onUpdateVideoHistory={handleUpdateVideoHistory}
              onShowToast={showToast}
            />
          </div>

          {/* TAB 3: KEYFRAME STUDIO (Image Generation with gemini-3.1-flash-image) */}
          <div className={activeTab === 'keyframe_gen' ? 'block' : 'hidden'}>
            <KeyframeGenerator
              activeStudioImage={studioImage}
              activeStudioMime={studioMime}
              studioHistory={studioHistory}
              originalForCompare={originalForCompare}
              onUpdateStudioState={(img, mime, hist, origCompare) => {
                setStudioImage(img);
                setStudioMime(mime);
                setStudioHistory(hist);
                if (origCompare !== undefined) {
                  setOriginalForCompare(origCompare);
                }
                saveStudioSession({
                  image: img,
                  mime,
                  history: hist,
                  originalForCompare: origCompare !== undefined ? origCompare : originalForCompare,
                }).catch(() => {});
              }}
              onSelectAsStartFrame={(img) => {
                setStartImage(img);
              }}
              onSelectAsEndFrame={(img) => {
                setEndImage(img);
              }}
              startImage={startImage}
              endImage={endImage}
              onShowToast={showToast}
            />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/10 py-6 text-center text-xs text-neutral-500">
        <p>Transprompter 2 · Powered by Gemini AI · Built for WAN 3.0 I2V Studio</p>
      </footer>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-full bg-[#1b192e]/95 border border-pink-500/40 text-pink-300 text-xs font-semibold shadow-2xl backdrop-blur-md flex items-center gap-2 animate-bounce">
          <Sparkles className="w-4 h-4 text-pink-400" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
