export interface PresetTemplate {
  title: string;
  prompt: string;
  duration: number;
}

export const PRESET_TEMPLATES: PresetTemplate[] = [
  {
    title: 'Girly Glitter Solo',
    prompt:
      'the man is holding and inspecting a jar labeled Girly Glitter. The jar begins to glow and get hot, and the man suddenly drops it. The jar hits the floor with a clatter and spills glitter and pink female energy that surrounds the man\'s nipples and crotch.  The man whimpers "My balls are moving..." as the energy begins to transform him, with the man falling to the floor as he changes. The transformed woman begins to panic as she feels her breasts and crotch, and she squeaks helplessly: "I\'m really a girl..." as the women watching giggle and whisper',
    duration: 10,
  },
  {
    title: 'Girly Glitter Group',
    prompt:
      'the men are chatting, when the jar begins to glow and get hot, and the man suddenly drops it. The jar hits the floor, spilling its contents and releasing a wave of pink female magic energy that surrounds the men\'s groins and nipples.  Panicking, the men are shocked as they transform.  The girls in the background point and laugh at the men\'s transformations and their stunned reactions as they feel their crotch or breasts in disbelief.',
    duration: 10,
  },
  {
    title: 'Sorceress Group',
    prompt:
      'the men are chatting when the sorceress in purple casts a spell of pink female magic energy that surrounds the men.  Panicking, the men are shocked as they transform.  The girls in the background point and laugh at the men\'s transformations and their stunned reactions',
    duration: 10,
  },
];

export const STEP_CONFIG = [
  { title: 'Analyzing keyframes…', subtitle: 'Gemini is performing visual delta analysis' },
  { title: 'Crafting morph sequence…', subtitle: 'Building anatomical & garment transition timeline' },
  { title: 'Designing audio track…', subtitle: 'Generating timestamped SFX & character-attributed dialogue' },
  { title: 'Formatting output…', subtitle: 'Structuring the final prompt document' },
];
