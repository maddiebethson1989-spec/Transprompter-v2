export type ImageSize = '1K' | '2K' | '4K';
export type AspectRatio = '16:9' | '9:16' | '1:1' | '4:3' | '3:4';

export interface KeyframeImage {
  data: string; // base64
  mimeType: string;
  previewUrl: string;
  name?: string;
}


export type GeminiChatModel =
  | 'gemini-3.8-flash'
  | 'gemini-3.5-flash';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  modelUsed?: string;
  searchQueries?: string[];
}

export interface SplitPromptResult {
  full: string;
  video: string;
  audio: string;
}

export interface KeyframeHistoryItem {
  id?: string;
  url: string;
  mime: string;
  label: string;
  prompt?: string;
  promptType?: 'generation' | 'edit';
  isEdit?: boolean;
  originalImageUrl?: string;
  timestamp?: number;
  modelUsed?: string;
  aspectRatio?: string;
  imageSize?: string;
  status?: 'loading' | 'completed' | 'failed';
}

export type KeyframeEditModel = 'nano_banana_2' | 'seedream_v5_pro';

export interface EnhanceHistoryItem {
  id: string;
  timestamp: number;
  basePrompt: string;
  enhancedResult: SplitPromptResult;
  startFrame: KeyframeImage | null;
  endFrame: KeyframeImage | null;
  duration?: number;
  model?: string;
  label?: string;
}


// ---------------------------------------------------------------------------
// API request / response shapes (shared between the Express server and client)
// ---------------------------------------------------------------------------

/** Raw base64 image payload (no data-URI prefix). */
export interface InlineImage {
  data: string;
  mimeType?: string;
}

export interface ApiErrorResponse {
  error: string;
}

export interface EnhancePromptRequest {
  startImage: InlineImage;
  endImage: InlineImage;
  basePrompt: string;
  duration?: number;
  model?: string;
}

export interface EnhancePromptResponse {
  success: boolean;
  text: string;
}

export interface DraftPromptRequest {
  startImage: InlineImage;
  endImage: InlineImage;
  model?: string;
}

export interface DraftPromptResponse {
  success: boolean;
  text: string;
}

export interface GenerateImageRequest {
  prompt: string;
  imageSize?: string;
  aspectRatio?: string;
  baseImage?: InlineImage;
}

export interface GenerateImageResponse {
  success: boolean;
  imageUrl: string;
  mimeType: string;
  size: string;
  aspectRatio: string;
}

export interface ChatTurn {
  role: string;
  content: string;
}

export interface PipelineContext {
  basePrompt?: string;
  enhancedPrompt?: string;
  hasStartImage?: boolean;
  hasEndImage?: boolean;
  startImage?: InlineImage;
  endImage?: InlineImage;
}

export interface ChatRequest {
  messages: ChatTurn[];
  model?: string;
  roleInstruction?: string;
  pipelineContext?: PipelineContext;
}

export interface ChatResponse {
  success: boolean;
  reply: string;
  modelUsed: string;
  searchQueries: string[];
}

export interface KeyframeChatRequest {
  messages: ChatTurn[];
  activeImage?: string;
  activeImageMime?: string;
  currentPrompt?: string;
  currentEditPrompt?: string;
  model?: string;
}

export interface KeyframeChatResponse {
  success: boolean;
  reply: string;
  searchQueries: string[];
}

export interface AtlasCloudStatusResponse {
  configured: boolean;
  isCustom?: boolean;
  source?: string;
  maskedKey?: string | null;
  atlascloud?: { configured: boolean };
}

export interface SeedreamEditRequest {
  prompt: string;
  images?: Array<string | InlineImage>;
  baseImage?: string | InlineImage;
  size?: string | { width: number | string; height: number | string };
  aspectRatio?: string;
  output_format?: 'jpeg' | 'png';
  background?: 'opaque' | 'transparent';
  thinking?: 'enabled' | 'disabled';
  enable_safety_checker?: boolean | 'true' | 'false';
  prompt_optimization_mode?: 'standard' | 'fast';
  enable_base64_output?: boolean;
}

export interface SeedreamEditResponse {
  success: boolean;
  predictionId: string;
  requestId: string;
  status: 'created';
  createdAt: string;
}

export type SeedreamJobStatus = 'completed' | 'failed' | 'in_queue' | 'processing';

export interface SeedreamStatusResponse {
  success: boolean;
  id: string;
  status: SeedreamJobStatus;
  outputUrl?: string | null;
  outputs?: string[];
  error?: string;
  logs: unknown[];
}

// ==========================================
// Video Studio / WAN 3.0 Video Generation Types
// ==========================================

export type VideoResolution =
  | '1080p'
  | '720p'
  | '480p'
  | '720p-esr'
  | '1080p-esr'
  | '1440p-esr'
  | '4k-esr';

export type VideoAspectRatio = '16:9' | '9:16' | '1:1' | '4:3' | '3:4' | '21:9';

export interface VideoGenerationRequest {
  model?: string;
  prompt: string;
  image: string | InlineImage;
  last_image?: string | InlineImage;
  resolution?: VideoResolution;
  duration?: number;
  aspect_ratio?: VideoAspectRatio;
  audio?: boolean;
  seed?: number;
}

export interface VideoGenerationResponse {
  success: boolean;
  id: string;
  status: 'created' | 'processing' | 'completed' | 'failed';
  error?: string;
}

export interface VideoStatusResponse {
  success: boolean;
  id: string;
  status: 'created' | 'processing' | 'completed' | 'succeeded' | 'failed';
  outputUrl?: string | null;
  outputs?: string[];
  error?: string;
}

export interface VideoHistoryItem {
  id: string;
  timestamp: number;
  prompt: string;
  videoUrl?: string;
  startFrame?: KeyframeImage | null;
  endFrame?: KeyframeImage | null;
  resolution: VideoResolution;
  aspectRatio?: VideoAspectRatio;
  duration: number;
  audio: boolean;
  seed: number;
  predictionId?: string;
  status?: 'generating' | 'completed' | 'failed';
  error?: string;
}

