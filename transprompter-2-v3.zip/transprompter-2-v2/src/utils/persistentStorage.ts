import { KeyframeHistoryItem, EnhanceHistoryItem, VideoHistoryItem } from '../types';

const DB_NAME = 'transprompter_storage_v2';
const DB_VERSION = 1;
const STORE_NAME = 'studio_store';

const KEY_IMAGE = 'transprompter_studio_image';
const KEY_MIME = 'transprompter_studio_mime';
const KEY_HISTORY = 'transprompter_studio_history';
const KEY_ORIGINAL_COMPARE = 'transprompter_original_image_for_edit';
const KEY_ENHANCE_HISTORY = 'transprompter_enhance_history';
const KEY_VIDEO_HISTORY = 'transprompter_video_history';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const request = window.indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function idbGet<T>(key: string): Promise<T | null> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const request = store.get(key);
      request.onsuccess = () => resolve(request.result ?? null);
      request.onerror = () => reject(request.error);
    });
  } catch (e) {
    console.warn(`IndexedDB get error for key "${key}":`, e);
    return null;
  }
}

export async function idbSet<T>(key: string, value: T): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const request = store.put(value, key);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (e) {
    console.warn(`IndexedDB set error for key "${key}":`, e);
  }
}

export async function idbRemove(key: string): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const request = store.delete(key);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (e) {
    console.warn(`IndexedDB remove error for key "${key}":`, e);
  }
}

/**
 * Saves studio session data across both IndexedDB (virtually unlimited quota for image histories)
 * and localStorage (fallback if supported).
 */
export async function saveStudioSession(data: {
  image: string | null;
  mime: string;
  history: KeyframeHistoryItem[];
  originalForCompare?: string | null;
}): Promise<void> {
  // Only persist completed items with valid URLs
  const persistentHistory = (data.history || []).filter(
    (h) => h.status !== 'loading' && Boolean(h.url)
  );

  // 1. Primary persistence: IndexedDB (handles gigabytes, no QuotaExceededError)
  await Promise.all([
    idbSet(KEY_IMAGE, data.image),
    idbSet(KEY_MIME, data.mime),
    idbSet(KEY_HISTORY, persistentHistory),
    idbSet(KEY_ORIGINAL_COMPARE, data.originalForCompare ?? null),
  ]);

  // 2. Secondary fallback: localStorage (safe catch if quota exceeded)
  try {
    if (data.image) {
      localStorage.setItem(KEY_IMAGE, data.image);
    } else {
      localStorage.removeItem(KEY_IMAGE);
    }
    localStorage.setItem(KEY_MIME, data.mime);
    localStorage.setItem(KEY_HISTORY, JSON.stringify(persistentHistory));
    if (data.originalForCompare) {
      localStorage.setItem(KEY_ORIGINAL_COMPARE, data.originalForCompare);
    } else {
      localStorage.removeItem(KEY_ORIGINAL_COMPARE);
    }
  } catch (quotaErr) {
    // Expected when base64 images exceed browser's 5MB localStorage limit.
    // IndexedDB already has the full persistent copy safely saved.
    console.info('LocalStorage quota reached for images; full history safely persisted in IndexedDB.');
  }
}

/**
 * Loads studio session data, checking IndexedDB first and falling back to localStorage.
 */
export async function loadStudioSession(): Promise<{
  image: string | null;
  mime: string;
  history: KeyframeHistoryItem[];
  originalForCompare?: string | null;
}> {
  // Try IndexedDB first
  try {
    const [idbImage, idbMime, idbHistory, idbOriginal] = await Promise.all([
      idbGet<string>(KEY_IMAGE),
      idbGet<string>(KEY_MIME),
      idbGet<KeyframeHistoryItem[]>(KEY_HISTORY),
      idbGet<string>(KEY_ORIGINAL_COMPARE),
    ]);

    if (idbHistory !== null || idbImage !== null) {
      return {
        image: idbImage ?? null,
        mime: idbMime || 'image/png',
        history: Array.isArray(idbHistory) ? idbHistory : [],
        originalForCompare: idbOriginal ?? null,
      };
    }
  } catch (e) {
    console.warn('Failed to load from IndexedDB, falling back to localStorage:', e);
  }

  // Fallback to localStorage
  try {
    const localImg = localStorage.getItem(KEY_IMAGE);
    const localMime = localStorage.getItem(KEY_MIME) || 'image/png';
    const localHistStr = localStorage.getItem(KEY_HISTORY);
    const localHist = localHistStr ? JSON.parse(localHistStr) : [];
    const localOriginal = localStorage.getItem(KEY_ORIGINAL_COMPARE);

    return {
      image: localImg,
      mime: localMime,
      history: Array.isArray(localHist) ? localHist : [],
      originalForCompare: localOriginal ?? null,
    };
  } catch {
    return {
      image: null,
      mime: 'image/png',
      history: [],
      originalForCompare: null,
    };
  }
}

/**
 * Persists prompt enhancement history across IndexedDB (with complete base64 keyframes)
 * and localStorage (with safe quota fallback).
 */
export async function saveEnhanceHistory(history: EnhanceHistoryItem[]): Promise<void> {
  const safeHistory = history || [];

  // 1. Primary persistence: IndexedDB (stores full base64 frames without quota issues)
  await idbSet(KEY_ENHANCE_HISTORY, safeHistory);

  // 2. Secondary persistence: localStorage
  try {
    localStorage.setItem(KEY_ENHANCE_HISTORY, JSON.stringify(safeHistory));
  } catch (quotaErr) {
    // If base64 frames exceed browser localStorage limit (~5MB), store lightweight preview data in localStorage
    try {
      const lightweight = safeHistory.map((item) => ({
        ...item,
        startFrame: item.startFrame
          ? {
              ...item.startFrame,
              data: '', // Omit heavy base64 for localStorage fallback; IndexedDB retains full image
            }
          : null,
        endFrame: item.endFrame
          ? {
              ...item.endFrame,
              data: '',
            }
          : null,
      }));
      localStorage.setItem(KEY_ENHANCE_HISTORY, JSON.stringify(lightweight));
    } catch {
      console.info('LocalStorage quota reached for prompt history; safely stored in IndexedDB.');
    }
  }
}

/**
 * Loads saved prompt enhancement history, checking IndexedDB first and re-hydrating preview URLs.
 */
export async function loadEnhanceHistory(): Promise<EnhanceHistoryItem[]> {
  // 1. Try IndexedDB first (contains complete image data)
  try {
    const idbData = await idbGet<EnhanceHistoryItem[]>(KEY_ENHANCE_HISTORY);
    if (Array.isArray(idbData)) {
      return idbData.map((item) => ({
        ...item,
        startFrame: item.startFrame
          ? {
              ...item.startFrame,
              previewUrl:
                item.startFrame.previewUrl && !item.startFrame.previewUrl.startsWith('blob:')
                  ? item.startFrame.previewUrl
                  : item.startFrame.data
                  ? `data:${item.startFrame.mimeType || 'image/png'};base64,${item.startFrame.data}`
                  : item.startFrame.previewUrl,
            }
          : null,
        endFrame: item.endFrame
          ? {
              ...item.endFrame,
              previewUrl:
                item.endFrame.previewUrl && !item.endFrame.previewUrl.startsWith('blob:')
                  ? item.endFrame.previewUrl
                  : item.endFrame.data
                  ? `data:${item.endFrame.mimeType || 'image/png'};base64,${item.endFrame.data}`
                  : item.endFrame.previewUrl,
            }
          : null,
      }));
    }
  } catch (e) {
    console.warn('Failed to load enhance history from IndexedDB, falling back to localStorage:', e);
  }

  // 2. Fallback to localStorage
  try {
    const local = localStorage.getItem(KEY_ENHANCE_HISTORY);
    if (local) {
      const parsed = JSON.parse(local);
      if (Array.isArray(parsed)) {
        return parsed.map((item: EnhanceHistoryItem) => ({
          ...item,
          startFrame: item.startFrame
            ? {
                ...item.startFrame,
                previewUrl:
                  item.startFrame.previewUrl && !item.startFrame.previewUrl.startsWith('blob:')
                    ? item.startFrame.previewUrl
                    : item.startFrame.data
                    ? `data:${item.startFrame.mimeType || 'image/png'};base64,${item.startFrame.data}`
                    : item.startFrame.previewUrl,
              }
            : null,
          endFrame: item.endFrame
            ? {
                ...item.endFrame,
                previewUrl:
                  item.endFrame.previewUrl && !item.endFrame.previewUrl.startsWith('blob:')
                    ? item.endFrame.previewUrl
                    : item.endFrame.data
                    ? `data:${item.endFrame.mimeType || 'image/png'};base64,${item.endFrame.data}`
                    : item.endFrame.previewUrl,
              }
            : null,
        }));
      }
    }
  } catch (err) {
    console.warn('Failed to parse enhance history from localStorage:', err);
  }

  return [];
}

/**
 * Persists generated video history across IndexedDB (with keyframes) and localStorage.
 */
export async function saveVideoHistory(history: VideoHistoryItem[]): Promise<void> {
  const safeHistory = (history || []).map((item) => ({
    ...item,
    startFrame: item.startFrame
      ? {
          ...item.startFrame,
          previewUrl:
            item.startFrame.previewUrl && !item.startFrame.previewUrl.startsWith('blob:')
              ? item.startFrame.previewUrl
              : item.startFrame.data
              ? `data:${item.startFrame.mimeType || 'image/png'};base64,${item.startFrame.data}`
              : item.startFrame.previewUrl,
        }
      : null,
    endFrame: item.endFrame
      ? {
          ...item.endFrame,
          previewUrl:
            item.endFrame.previewUrl && !item.endFrame.previewUrl.startsWith('blob:')
              ? item.endFrame.previewUrl
              : item.endFrame.data
              ? `data:${item.endFrame.mimeType || 'image/png'};base64,${item.endFrame.data}`
              : item.endFrame.previewUrl,
        }
      : null,
  }));

  // 1. Immediately save to localStorage (guarantees fast, synchronous retrieval across sessions)
  try {
    localStorage.setItem(KEY_VIDEO_HISTORY, JSON.stringify(safeHistory));
  } catch (quotaErr) {
    // If base64 keyframe payloads hit localStorage quota, save lightweight versions to localStorage
    try {
      const lightweight = safeHistory.map((item) => ({
        ...item,
        startFrame: item.startFrame
          ? {
              mimeType: item.startFrame.mimeType,
              name: item.startFrame.name,
              data: '',
              previewUrl:
                item.startFrame.previewUrl && !item.startFrame.previewUrl.startsWith('blob:')
                  ? item.startFrame.previewUrl
                  : '',
            }
          : null,
        endFrame: item.endFrame
          ? {
              mimeType: item.endFrame.mimeType,
              name: item.endFrame.name,
              data: '',
              previewUrl:
                item.endFrame.previewUrl && !item.endFrame.previewUrl.startsWith('blob:')
                  ? item.endFrame.previewUrl
                  : '',
            }
          : null,
      }));
      localStorage.setItem(KEY_VIDEO_HISTORY, JSON.stringify(lightweight));
    } catch (e) {
      console.warn('LocalStorage save failed for video history:', e);
    }
  }

  // 2. Persist full copy to IndexedDB (virtually unlimited quota for raw image data)
  try {
    await idbSet(KEY_VIDEO_HISTORY, safeHistory);
  } catch (err) {
    console.warn('IndexedDB save failed for video history:', err);
  }
}

/**
 * Loads saved video generation history, checking IndexedDB and falling back to localStorage.
 */
export async function loadVideoHistory(): Promise<VideoHistoryItem[]> {
  // 1. Try IndexedDB first
  try {
    const idbData = await idbGet<VideoHistoryItem[]>(KEY_VIDEO_HISTORY);
    if (Array.isArray(idbData) && idbData.length > 0) {
      return idbData.map((item) => ({
        ...item,
        status: item.status || (item.videoUrl ? 'completed' : 'failed'),
        startFrame: item.startFrame
          ? {
              ...item.startFrame,
              previewUrl:
                item.startFrame.previewUrl && !item.startFrame.previewUrl.startsWith('blob:')
                  ? item.startFrame.previewUrl
                  : item.startFrame.data
                  ? `data:${item.startFrame.mimeType || 'image/png'};base64,${item.startFrame.data}`
                  : item.startFrame.previewUrl,
            }
          : null,
        endFrame: item.endFrame
          ? {
              ...item.endFrame,
              previewUrl:
                item.endFrame.previewUrl && !item.endFrame.previewUrl.startsWith('blob:')
                  ? item.endFrame.previewUrl
                  : item.endFrame.data
                  ? `data:${item.endFrame.mimeType || 'image/png'};base64,${item.endFrame.data}`
                  : item.endFrame.previewUrl,
            }
          : null,
      }));
    }
  } catch (e) {
    console.warn('Failed to load video history from IndexedDB:', e);
  }

  // 2. Fallback to localStorage if IndexedDB had no records or failed
  try {
    const local = localStorage.getItem(KEY_VIDEO_HISTORY);
    if (local) {
      const parsed = JSON.parse(local);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((item: VideoHistoryItem) => ({
          ...item,
          status: item.status || (item.videoUrl ? 'completed' : 'failed'),
          startFrame: item.startFrame
            ? {
                ...item.startFrame,
                previewUrl:
                  item.startFrame.previewUrl && !item.startFrame.previewUrl.startsWith('blob:')
                    ? item.startFrame.previewUrl
                    : item.startFrame.data
                    ? `data:${item.startFrame.mimeType || 'image/png'};base64,${item.startFrame.data}`
                    : item.startFrame.previewUrl,
              }
            : null,
          endFrame: item.endFrame
            ? {
                ...item.endFrame,
                previewUrl:
                  item.endFrame.previewUrl && !item.endFrame.previewUrl.startsWith('blob:')
                    ? item.endFrame.previewUrl
                    : item.endFrame.data
                    ? `data:${item.endFrame.mimeType || 'image/png'};base64,${item.endFrame.data}`
                    : item.endFrame.previewUrl,
              }
            : null,
        }));
      }
    }
  } catch (err) {
    console.warn('Failed to parse video history from localStorage:', err);
  }

  return [];
}

