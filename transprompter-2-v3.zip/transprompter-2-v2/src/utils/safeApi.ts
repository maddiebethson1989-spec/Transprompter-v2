const STORAGE_KEY = 'transprompter_gemini_api_key';
const ATLASCLOUD_STORAGE_KEY = 'transprompter_atlascloud_api_key';

export function getStoredGeminiApiKey(): string {
  if (typeof window === 'undefined') return '';
  return localStorage.getItem(STORAGE_KEY) || '';
}

export function setStoredGeminiApiKey(key: string): void {
  if (typeof window === 'undefined') return;
  if (!key || !key.trim()) {
    localStorage.removeItem(STORAGE_KEY);
  } else {
    localStorage.setItem(STORAGE_KEY, key.trim());
  }
}

export function getStoredAtlasCloudApiKey(): string {
  if (typeof window === 'undefined') return '';
  return localStorage.getItem(ATLASCLOUD_STORAGE_KEY) || '';
}

export function setStoredAtlasCloudApiKey(key: string): void {
  if (typeof window === 'undefined') return;
  if (!key || !key.trim()) {
    localStorage.removeItem(ATLASCLOUD_STORAGE_KEY);
  } else {
    localStorage.setItem(ATLASCLOUD_STORAGE_KEY, key.trim());
  }
}

/**
 * Safe API request helper to prevent JSON parsing errors on HTML fallback or network errors.
 */
export async function safeFetchJson<T = any>(
  input: RequestInfo | URL,
  init?: RequestInit
): Promise<T> {
  const urlStr =
    typeof input === 'string'
      ? input
      : input instanceof URL
      ? input.toString()
      : (input as Request).url || 'API endpoint';

  // Automatically attach custom Gemini & AtlasCloud API keys if configured
  const storedGeminiKey = getStoredGeminiApiKey();
  const storedAtlasKey = getStoredAtlasCloudApiKey();
  const headers = new Headers(init?.headers);
  if (storedGeminiKey && !headers.has('x-gemini-api-key')) {
    headers.set('x-gemini-api-key', storedGeminiKey);
  }
  if (storedAtlasKey && !headers.has('x-atlascloud-api-key')) {
    headers.set('x-atlascloud-api-key', storedAtlasKey);
  }

  const res = await fetch(input, {
    ...init,
    headers,
  });
  const contentType = res.headers.get('content-type') || '';

  if (!contentType.includes('application/json')) {
    const rawText = await res.text().catch(() => '');

    // Attempt parsing as JSON in case content-type was omitted or mislabeled by a proxy
    if (rawText && (rawText.trim().startsWith('{') || rawText.trim().startsWith('['))) {
      try {
        const parsed = JSON.parse(rawText);
        if (!res.ok) {
          throw new Error(parsed?.error || parsed?.message || `Server returned error HTTP ${res.status}`);
        }
        return parsed as T;
      } catch (parseErr: any) {
        if (!res.ok) {
          throw new Error(`Server returned error HTTP ${res.status}: ${res.statusText}`);
        }
      }
    }

    if (!res.ok) {
      throw new Error(
        `Server returned error HTTP ${res.status}: ${res.statusText || 'Unexpected non-JSON response'}`
      );
    }

    throw new Error(
      `Endpoint ${urlStr} returned an HTML page instead of JSON. The server route may be missing or the dev server was restarting.`
    );
  }

  const data = await res.json();
  if (!res.ok) {
    const errMsg = data?.error || data?.message || `Server returned error HTTP ${res.status}`;
    throw new Error(errMsg);
  }

  return data as T;
}
