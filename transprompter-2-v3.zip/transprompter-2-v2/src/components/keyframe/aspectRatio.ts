import { AspectRatio } from '../../types';

// Helper to detect closest supported Aspect Ratio to match any image
export const detectNearestAspectRatio = (width: number, height: number): AspectRatio => {
  if (!width || !height) return '4:3';
  const ratio = width / height;
  const candidates: { ratio: AspectRatio; val: number }[] = [
    { ratio: '16:9', val: 16 / 9 },
    { ratio: '4:3', val: 4 / 3 },
    { ratio: '1:1', val: 1.0 },
    { ratio: '3:4', val: 3 / 4 },
    { ratio: '9:16', val: 9 / 16 },
  ];

  let closest = candidates[0];
  let minDiff = Math.abs(ratio - candidates[0].val);

  for (let i = 1; i < candidates.length; i++) {
    const diff = Math.abs(ratio - candidates[i].val);
    if (diff < minDiff) {
      minDiff = diff;
      closest = candidates[i];
    }
  }

  return closest.ratio;
};
