import { KeyframeImage, KeyframeHistoryItem } from '../../types';

export interface ReferenceImageItem {
  id: string;
  url: string;
  mime: string;
  name?: string;
  source?: 'upload' | 'start_frame' | 'end_frame' | 'history';
}

export interface KeyframeGeneratorProps {
  onSelectAsStartFrame: (img: KeyframeImage) => void;
  onSelectAsEndFrame: (img: KeyframeImage) => void;
  onShowToast: (msg: string) => void;
  activeStudioImage?: string | null;
  activeStudioMime?: string;
  studioHistory?: KeyframeHistoryItem[];
  originalForCompare?: string | null;
  startImage?: KeyframeImage | null;
  endImage?: KeyframeImage | null;
  onUpdateStudioState?: (
    img: string | null,
    mime: string,
    history: KeyframeHistoryItem[],
    originalForCompare?: string | null
  ) => void;
}
