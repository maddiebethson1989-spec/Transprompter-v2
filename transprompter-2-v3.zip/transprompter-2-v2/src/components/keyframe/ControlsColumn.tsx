import type { KeyframeStudio } from './useKeyframeStudio';
import { ModeToggle } from './ModeToggle';
import { EditModePanel } from './EditModePanel';
import { GenerateModePanel } from './GenerateModePanel';
import { ResolutionControls } from './ResolutionControls';

interface ControlsColumnProps {
  studio: KeyframeStudio;
}

export function ControlsColumn({ studio }: ControlsColumnProps) {
  const { error, isEditMode, studioControlsRef } = studio;

  return (
    <div ref={studioControlsRef} className="order-2 lg:order-1 lg:col-span-6 flex flex-col gap-4">
      <div className="trans-card p-6 flex flex-col gap-5">
        {/* Mode Toggle: Text-to-Image vs Edit Prompt */}
        <ModeToggle studio={studio} />

        {/* TAB CONTENT: EDIT PROMPT MODE */}
        {isEditMode ? (
          <EditModePanel studio={studio} />
        ) : (
          /* TAB CONTENT: TEXT TO IMAGE MODE */
          <GenerateModePanel studio={studio} />
        )}

        {/* Unified Resolution & Aspect Ratio Controls (Used by both Seedream-v5.0-Pro & Nano Banana 2) */}
        <ResolutionControls studio={studio} />

        {error && (
          <div className="p-3 bg-red-950/40 border border-red-500/30 rounded-xl text-xs text-red-300">{error}</div>
        )}
      </div>
    </div>
  );
}
