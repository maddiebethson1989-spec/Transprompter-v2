import React, { useRef } from 'react';
import {
  Sparkles,
  Loader2,
  Wand2,
  Upload,
  Trash2,
  Cpu,
  Zap,
  Plus,
  X,
  ImagePlus,
  Layers,
  Info,
} from 'lucide-react';
import type { KeyframeStudio } from './useKeyframeStudio';

interface EditModePanelProps {
  studio: KeyframeStudio;
}

export function EditModePanel({ studio }: EditModePanelProps) {
  const {
    imageSize,
    aspectRatio,
    generatedImage,
    history,
    editPrompt,
    setEditPrompt,
    editModel,
    setEditModel,
    seedreamFormat,
    setSeedreamFormat,
    seedreamThinking,
    setSeedreamThinking,
    isButtonCooldown,
    handleClearActiveImage,
    handleRunEdit,
    handleOpenUpload,
    triggerCraftReversePrompt,
    referenceImages,
    handleRemoveReferenceImage,
    handleClearReferenceImages,
    handleImportStartFrameAsReference,
    handleImportEndFrameAsReference,
    handleAddReferenceImage,
    startImage,
    endImage,
  } = studio;

  const multiRefInputRef = useRef<HTMLInputElement>(null);

  const onMultiRefUploadChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const allowed = ['image/png', 'image/jpeg', 'image/webp'];
      if (!allowed.includes(file.type)) return;

      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        handleAddReferenceImage(result, file.type, file.name, 'upload');
      };
      reader.readAsDataURL(file);
    });

    if (e.target) e.target.value = '';
  };

  const totalImageCount = (generatedImage ? 1 : 0) + referenceImages.length;

  return (
    <div className="flex flex-col gap-4 animate-in fade-in duration-200">
      <div className="flex items-center justify-between">
        <label className="block text-xs font-semibold uppercase tracking-wider text-pink-300 flex items-center gap-1.5">
          <Wand2 className="w-3.5 h-3.5" />
          <span>Run Edit Prompt on Active Image</span>
        </label>
      </div>

      {/* Hidden file input for uploading additional reference images */}
      <input
        ref={multiRefInputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        multiple
        className="hidden"
        onChange={onMultiRefUploadChange}
      />

      {generatedImage ? (
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-3 p-2.5 rounded-xl bg-black/40 border border-white/10">
            <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 bg-neutral-900 border border-white/10 relative">
              <img src={generatedImage} alt="Current Base" className="w-full h-full object-cover" />
              <span className="absolute bottom-0 right-0 bg-black/80 text-[9px] font-mono text-pink-300 px-1 rounded-tl">
                Pos 1
              </span>
            </div>
            <div className="flex-1 min-w-0 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-neutral-200 truncate">Position 1: Primary Base Image</span>
              </div>
              <span className="text-[11px] text-neutral-400">
                {imageSize} · {aspectRatio} · {history.length} edits applied
              </span>
            </div>
            <button
              type="button"
              onClick={() => handleOpenUpload('edit')}
              className="px-2.5 py-1 text-xs rounded-lg bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/10 transition flex items-center gap-1.5 flex-shrink-0"
              title="Upload a new image to replace active target"
            >
              <Upload className="w-3.5 h-3.5 text-pink-400" />
              <span>Replace</span>
            </button>
            <button
              type="button"
              onClick={handleClearActiveImage}
              className="px-2.5 py-1 text-xs rounded-lg bg-white/5 hover:bg-red-500/20 text-neutral-400 hover:text-red-300 border border-white/10 hover:border-red-500/30 transition flex items-center gap-1.5 flex-shrink-0"
              title="Clear active image from canvas"
            >
              <Trash2 className="w-3.5 h-3.5 text-red-400" />
              <span>Clear</span>
            </button>
          </div>

          {/* Quick Banner: Craft matching reverse prompt in Copilot */}
          <div className="flex items-center justify-between p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/25">
            <div className="flex items-center gap-2 min-w-0">
              <Wand2 className="w-4 h-4 text-purple-400 flex-shrink-0" />
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-medium text-purple-200 truncate">Craft Reverse Prompt in Copilot</span>
                <span className="text-[10px] text-purple-300/80 truncate">
                  Inspect this frame to write matching male pre-transformation prompt
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => triggerCraftReversePrompt()}
              className="px-2.5 py-1.5 rounded-lg bg-purple-500/25 hover:bg-purple-500/40 text-purple-100 border border-purple-400/40 text-xs font-semibold transition flex items-center gap-1.5 flex-shrink-0 shadow-sm"
              title="Ask Copilot to analyze this image and craft matching Start Frame reverse edit prompt"
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-300" />
              <span>Craft Prompt</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="p-4 rounded-xl border border-dashed border-pink-500/40 bg-pink-500/5 flex flex-col items-center text-center gap-3">
          <div className="w-10 h-10 rounded-full bg-pink-500/20 flex items-center justify-center text-pink-300">
            <Upload className="w-5 h-5" />
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-xs font-semibold text-neutral-200">Upload an Image to Edit or Reverse-Prompt</span>
            <span className="text-[11px] text-neutral-400 max-w-sm">
              Upload any character photo, rendered keyframe, or End Frame to perform image-to-image AI edits or craft
              matching Start Frame reverse prompts.
            </span>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-2 mt-1">
            <button
              type="button"
              onClick={() => handleOpenUpload('edit')}
              className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 text-white text-xs font-semibold shadow transition flex items-center gap-1.5"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Image to Edit</span>
            </button>
            <button
              type="button"
              onClick={() => handleOpenUpload('reverse_prompt')}
              className="px-3.5 py-1.5 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/40 text-xs font-semibold transition flex items-center gap-1.5"
            >
              <Wand2 className="w-3.5 h-3.5 text-purple-300" />
              <span>Upload & Craft Reverse Prompt</span>
            </button>
          </div>
        </div>
      )}

      {/* Model Selector: Nano Banana 2 vs Seedream-v5.0-Pro */}
      <div className="bg-[#0e0e17] p-3.5 rounded-xl border border-white/10 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral-300 flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-pink-400" />
            <span>Editing Engine</span>
          </span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30">
            {editModel === 'seedream_v5_pro' ? 'ByteDance via AtlasCloud' : 'Google Gemini 3.1'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {/* Option 1: Seedream-v5.0-Pro */}
          <button
            type="button"
            onClick={() => setEditModel('seedream_v5_pro')}
            className={`p-3 rounded-xl border text-left transition flex flex-col justify-between gap-1 ${
              editModel === 'seedream_v5_pro'
                ? 'bg-gradient-to-br from-pink-500/25 to-purple-600/25 border-pink-500 text-white shadow-md shadow-pink-500/20'
                : 'bg-black/40 border-white/10 text-neutral-400 hover:text-white hover:border-white/20'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                Seedream-v5.0-Pro
              </span>
              {editModel === 'seedream_v5_pro' && <span className="w-2 h-2 rounded-full bg-pink-400" />}
            </div>
            <span className="text-[11px] text-neutral-300 line-clamp-1">ByteDance flagship next-gen image editing</span>
            <span className="text-[10px] text-neutral-500 font-mono">AtlasCloud · Up to 10 reference images</span>
          </button>

          {/* Option 2: Nano Banana 2 */}
          <button
            type="button"
            onClick={() => setEditModel('nano_banana_2')}
            className={`p-3 rounded-xl border text-left transition flex flex-col justify-between gap-1 ${
              editModel === 'nano_banana_2'
                ? 'bg-gradient-to-br from-pink-500/25 to-purple-600/25 border-pink-500 text-white shadow-md shadow-pink-500/20'
                : 'bg-black/40 border-white/10 text-neutral-400 hover:text-white hover:border-white/20'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                Nano Banana 2
              </span>
              {editModel === 'nano_banana_2' && <span className="w-2 h-2 rounded-full bg-amber-400" />}
            </div>
            <span className="text-[11px] text-neutral-300 line-clamp-1">gemini-3.1-flash-image</span>
            <span className="text-[10px] text-neutral-500 font-mono">High thinking · Multimodal in-context edits</span>
          </button>
        </div>

        {/* Seedream-Specific Parameters (Thinking, Mode, Format) */}
        {editModel === 'seedream_v5_pro' && (
          <div className="pt-2 border-t border-white/10 grid grid-cols-1 sm:grid-cols-3 gap-2">
            {/* Optimization Mode option */}
            <div className="flex items-center justify-between p-2 rounded-lg bg-black/30 border border-white/5 text-[11px]">
              <span className="text-neutral-300 font-medium">Optimization</span>
              <button
                type="button"
                onClick={() => studio.setSeedreamMode(studio.seedreamMode === 'standard' ? 'fast' : 'standard')}
                className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono transition ${
                  studio.seedreamMode === 'standard'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                }`}
                title="Toggle AtlasCloud prompt optimization mode (standard vs fast)"
              >
                {studio.seedreamMode === 'standard' ? 'Standard' : 'Fast'}
              </button>
            </div>

            {/* Thinking option */}
            <div className="flex items-center justify-between p-2 rounded-lg bg-black/30 border border-white/5 text-[11px]">
              <span className="text-neutral-300 font-medium">Prompt Thinking</span>
              <button
                type="button"
                onClick={() => setSeedreamThinking(seedreamThinking === 'enabled' ? 'disabled' : 'enabled')}
                className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono transition ${
                  seedreamThinking === 'enabled'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-white/5 text-neutral-400 border border-white/10'
                }`}
              >
                {seedreamThinking === 'enabled' ? 'Enabled' : 'Disabled'}
              </button>
            </div>

            {/* Format option */}
            <div className="flex items-center justify-between p-2 rounded-lg bg-black/30 border border-white/5 text-[11px]">
              <span className="text-neutral-300 font-medium">Output Format</span>
              <div className="flex items-center gap-1 font-mono text-[10px]">
                <button
                  type="button"
                  onClick={() => setSeedreamFormat('jpeg')}
                  className={`px-1.5 py-0.5 rounded transition ${
                    seedreamFormat === 'jpeg' ? 'bg-pink-500/30 text-pink-300 font-bold' : 'text-neutral-500'
                  }`}
                >
                  JPEG
                </button>
                <span className="text-neutral-600">/</span>
                <button
                  type="button"
                  onClick={() => setSeedreamFormat('png')}
                  className={`px-1.5 py-0.5 rounded transition ${
                    seedreamFormat === 'png' ? 'bg-pink-500/30 text-pink-300 font-bold' : 'text-neutral-500'
                  }`}
                >
                  PNG
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Seedream 5.0 Pro: Multi-Image Reference Gallery (Up to 10 images) */}
      {editModel === 'seedream_v5_pro' && (
        <div className="bg-[#0e0e17] p-3.5 rounded-xl border border-white/10 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-3.5 h-3.5 text-pink-400" />
              <span className="text-xs font-semibold text-neutral-200">
                Reference Image Slots (Positions 1 – 10)
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-pink-500/10 text-pink-300 border border-pink-500/20 font-semibold">
                {totalImageCount} / 10 active
              </span>
              {referenceImages.length > 0 && (
                <button
                  type="button"
                  onClick={handleClearReferenceImages}
                  className="text-[10px] text-neutral-400 hover:text-red-400 transition"
                  title="Clear additional reference images"
                >
                  Clear Extra
                </button>
              )}
            </div>
          </div>

          {/* Reference Thumbnails Carousel / Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-2.5">
            {/* Slot 1: Primary Active Image */}
            <div className="relative rounded-xl border border-pink-500/40 bg-pink-500/10 p-1.5 flex flex-col gap-1.5">
              <div className="aspect-square rounded-lg overflow-hidden bg-black/60 relative">
                {generatedImage ? (
                  <img src={generatedImage} alt="Position 1" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-neutral-500 text-[10px] p-2 text-center">
                    Primary Base Needed
                  </div>
                )}
                <span className="absolute top-1 left-1 bg-pink-600 text-white font-mono text-[9px] font-bold px-1.5 py-0.2 rounded shadow">
                  Pos 1
                </span>
              </div>
              <span className="text-[10px] font-semibold text-pink-200 truncate px-0.5">
                Primary Base
              </span>
            </div>

            {/* Slots 2..N: Additional Reference Images */}
            {referenceImages.map((ref, idx) => (
              <div
                key={ref.id}
                className="relative rounded-xl border border-white/10 bg-black/40 p-1.5 flex flex-col gap-1.5 group hover:border-pink-500/40 transition"
              >
                <div className="aspect-square rounded-lg overflow-hidden bg-black/60 relative">
                  <img src={ref.url} alt={`Position ${idx + 2}`} className="w-full h-full object-cover" />
                  <span className="absolute top-1 left-1 bg-indigo-600 text-white font-mono text-[9px] font-bold px-1.5 py-0.2 rounded shadow">
                    Pos {idx + 2}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleRemoveReferenceImage(ref.id)}
                    className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/80 hover:bg-red-500 text-neutral-300 hover:text-white flex items-center justify-center transition shadow opacity-80 hover:opacity-100"
                    title={`Remove Position ${idx + 2}`}
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
                <span className="text-[10px] text-neutral-300 truncate px-0.5" title={ref.name}>
                  {ref.name || `Reference ${idx + 2}`}
                </span>
              </div>
            ))}

            {/* Add Reference Slot Button (if under 10 images) */}
            {totalImageCount < 10 && (
              <button
                type="button"
                onClick={() => multiRefInputRef.current?.click()}
                className="rounded-xl border-2 border-dashed border-white/10 hover:border-pink-500/50 hover:bg-pink-500/5 p-2 flex flex-col items-center justify-center gap-1.5 text-neutral-400 hover:text-pink-300 transition group aspect-square"
                title="Upload another reference image"
              >
                <div className="w-7 h-7 rounded-full bg-white/5 group-hover:bg-pink-500/20 flex items-center justify-center transition">
                  <Plus className="w-4 h-4 text-pink-400" />
                </div>
                <span className="text-[10px] font-semibold text-center leading-tight">
                  + Add Ref
                  <span className="block text-[8px] text-neutral-500 font-mono">Pos {totalImageCount + 1}</span>
                </span>
              </button>
            )}
          </div>

          {/* Quick Import Toolbar for Reference Images */}
          <div className="pt-2 border-t border-white/5 flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[10px] text-neutral-400 font-medium">Quick Add:</span>
              {startImage?.data && (
                <button
                  type="button"
                  onClick={handleImportStartFrameAsReference}
                  disabled={totalImageCount >= 10}
                  className="px-2 py-0.5 rounded text-[10px] bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/10 transition flex items-center gap-1 disabled:opacity-50"
                  title="Import Enhancer Start Frame as an edit reference"
                >
                  <ImagePlus className="w-3 h-3 text-pink-400" />
                  <span>Start Frame</span>
                </button>
              )}
              {endImage?.data && (
                <button
                  type="button"
                  onClick={handleImportEndFrameAsReference}
                  disabled={totalImageCount >= 10}
                  className="px-2 py-0.5 rounded text-[10px] bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/10 transition flex items-center gap-1 disabled:opacity-50"
                  title="Import Enhancer End Frame as an edit reference"
                >
                  <ImagePlus className="w-3 h-3 text-purple-400" />
                  <span>End Frame</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => multiRefInputRef.current?.click()}
                disabled={totalImageCount >= 10}
                className="px-2 py-0.5 rounded text-[10px] bg-pink-500/10 hover:bg-pink-500/20 text-pink-300 border border-pink-500/30 transition flex items-center gap-1 disabled:opacity-50"
              >
                <Upload className="w-3 h-3" />
                <span>Upload Photos</span>
              </button>
            </div>

            <div className="text-[10px] text-neutral-500 font-mono">
              Positions 1 – {Math.max(1, totalImageCount)} available in prompt
            </div>
          </div>

          {/* Prompting Hint Banner */}
          <div className="p-2.5 rounded-lg bg-pink-500/5 border border-pink-500/20 text-[11px] text-neutral-300 flex items-start gap-2">
            <Info className="w-3.5 h-3.5 text-pink-400 flex-shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <span className="font-semibold text-pink-300">Seedream 5.0 Reference Syntax:</span> Refer to images by their numbered position (e.g. <span className="font-mono text-white text-[10px]">"Apply the hair and lighting from position 2 to the character in position 1"</span>).
            </div>
          </div>
        </div>
      )}

      {/* Edit Prompt Textarea */}
      <textarea
        value={editPrompt}
        onChange={(e) => setEditPrompt(e.target.value)}
        placeholder={
          editModel === 'seedream_v5_pro'
            ? referenceImages.length > 0
              ? `Describe edits with multi-image references: e.g. "Preserve character identity in position 1, transfer the outfit from position 2, and adopt the background lighting from position 3"...`
              : 'Describe edits for Seedream-v5.0-Pro (AtlasCloud): e.g. "Preserve character identity but change armor to black obsidian with glowing red runes", "Transform daytime lighting into dusk with volumetric mist"...'
            : 'Describe edits for Nano Banana 2 (Gemini Image): e.g. "Add a glowing mystical aura around the character", "Change background to neon cyber city"...'
        }
        rows={4}
        className="w-full bg-[#0e0e17] border border-white/10 rounded-xl p-3.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500/60 focus:ring-2 focus:ring-pink-500/20 transition resize-none"
      />

      {/* Action button for editing */}
      <button
        onClick={() => handleRunEdit()}
        disabled={isButtonCooldown || !editPrompt.trim() || !generatedImage}
        className="relative overflow-hidden w-full py-3.5 px-6 rounded-xl font-semibold text-sm text-white bg-gradient-to-r from-pink-600 via-fuchsia-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-pink-600/30 transition transform active:scale-[0.99]"
      >
        <div className="relative z-10 flex items-center justify-center gap-2">
          {isButtonCooldown ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-white" />
              <span>Submitting edit request…</span>
            </>
          ) : (
            <>
              <Wand2 className="w-4 h-4" />
              <span>
                Apply Edit with{' '}
                {editModel === 'seedream_v5_pro'
                  ? `Seedream-v5.0-Pro (${totalImageCount} image${totalImageCount > 1 ? 's' : ''})`
                  : 'Nano Banana 2'}
              </span>
            </>
          )}
        </div>
        <div className="btn-shimmer" />
      </button>
    </div>
  );
}
