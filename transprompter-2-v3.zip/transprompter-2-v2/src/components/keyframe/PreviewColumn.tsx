import type { KeyframeStudio } from './useKeyframeStudio';
import { PreviewHeader } from './PreviewHeader';
import { PreviewCanvas } from './PreviewCanvas';
import { VersionHistory } from './VersionHistory';
import { BindFrameActions } from './BindFrameActions';

interface PreviewColumnProps {
  studio: KeyframeStudio;
}

export function PreviewColumn({ studio }: PreviewColumnProps) {
  const { generatedImage, history } = studio;

  return (
    <div className="order-1 lg:order-2 lg:col-span-6 flex flex-col">
      <div className="trans-card p-6 flex flex-col h-full justify-between gap-5">
        <div>
          <PreviewHeader studio={studio} />

          <PreviewCanvas studio={studio} />

          {/* Version History Thumbnails */}
          {history.length > 0 && <VersionHistory studio={studio} />}
        </div>

        {/* Action Buttons to bind image to Start or End Frame */}
        {generatedImage && <BindFrameActions studio={studio} />}
      </div>
    </div>
  );
}
