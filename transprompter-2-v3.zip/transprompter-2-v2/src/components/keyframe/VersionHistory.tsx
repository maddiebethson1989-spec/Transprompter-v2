import { ImageSize, AspectRatio } from '../../types';
import { Loader2, Download, Trash2, Layers, X } from 'lucide-react';
import type { KeyframeStudio } from './useKeyframeStudio';

interface VersionHistoryProps {
  studio: KeyframeStudio;
}

export function VersionHistory({ studio }: VersionHistoryProps) {
  const {
    onShowToast,
    prompt,
    setPrompt,
    setImageSize,
    setAspectRatio,
    generatedImage,
    setGeneratedImage,
    generatedMime,
    setGeneratedMime,
    history,
    setOriginalImageForCompare,
    setZoomViewingMode,
    editPrompt,
    setEditPrompt,
    isEditMode,
    setIsEditMode,
    setEditModel,
    activeHistoryItemId,
    setActiveHistoryItemId,
    updateStudio,
    handleDeleteHistoryItem,
    handleClearAllHistory,
    handleDownload,
  } = studio;

  return (
    <div className="mt-3 pt-3 border-t border-white/10">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[11px] font-semibold text-neutral-300 flex items-center gap-1.5">
          <Layers className="w-3.5 h-3.5 text-pink-400" />
          <span>Saved History ({history.length})</span>
          <span className="text-[10px] text-neutral-500 font-normal">· Click to switch active frame</span>
        </span>
        <button
          type="button"
          onClick={handleClearAllHistory}
          className="text-[10px] text-neutral-500 hover:text-rose-400 flex items-center gap-1 transition"
          title="Clear all saved history items"
        >
          <Trash2 className="w-3 h-3" />
          <span>Clear History</span>
        </button>
      </div>

      <div className="flex items-center gap-2 overflow-x-auto pb-1.5 scrollbar-thin">
        {history.map((item, idx) => {
          const isItemActive = activeHistoryItemId ? item.id === activeHistoryItemId : generatedImage === item.url;

          return (
            <div key={item.id || idx} className="relative group flex-shrink-0">
              {item.status === 'loading' ? (
                <button
                  type="button"
                  onClick={() => {
                    setActiveHistoryItemId(item.id || null);
                    setGeneratedImage(null);
                    if (item.prompt) {
                      if (item.isEdit) {
                        setIsEditMode(true);
                        setEditPrompt(item.prompt);
                      } else {
                        setIsEditMode(false);
                        setPrompt(item.prompt);
                      }
                    }
                    onShowToast('Switched to live generation progress');
                  }}
                  className={`w-16 h-16 rounded-xl overflow-hidden border transition block relative text-left bg-[#12101e] flex-shrink-0 ${
                    isItemActive
                      ? 'border-pink-500 ring-2 ring-pink-500/40 shadow-md shadow-pink-500/25'
                      : 'border-pink-500/40 hover:border-pink-500 hover:ring-2 hover:ring-pink-500/20'
                  }`}
                  title={item.prompt ? `Generating: "${item.prompt}" (Click to view progress)` : 'Generating keyframe…'}
                >
                  <div className="w-full h-full relative overflow-hidden">
                    <video
                      src="/media/loader.mp4"
                      autoPlay
                      loop
                      muted
                      playsInline
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center pb-3">
                      <Loader2 className="w-4 h-4 text-pink-400 animate-spin" />
                    </div>
                  </div>
                  <span
                    className={`absolute bottom-0 inset-x-0 px-1 py-0.5 text-[8px] text-center font-mono truncate ${
                      isItemActive ? 'bg-pink-600/90 text-white font-bold' : 'bg-pink-950/90 text-pink-300'
                    }`}
                  >
                    {isItemActive ? 'Active' : item.isEdit ? 'Editing…' : 'Generating…'}
                  </span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    const currentUrl = generatedImage;
                    const currentMime = generatedMime;
                    const currentPromptText = (isEditMode ? editPrompt : prompt) || '';

                    // Set active item and active image
                    setActiveHistoryItemId(item.id || null);
                    setGeneratedImage(item.url);
                    setGeneratedMime(item.mime);

                    // Determine if this item was an edit or an original generation
                    const isEditItem = Boolean(
                      item.isEdit ||
                      item.promptType === 'edit' ||
                      item.label.toLowerCase().includes('seedream:') ||
                      item.label.toLowerCase().includes('nano banana')
                    );

                    // Determine original photo it was edited from
                    let origForComp: string | null = null;
                    if (isEditItem) {
                      if (item.originalImageUrl) {
                        origForComp = item.originalImageUrl;
                      } else if (idx > 0 && history[idx - 1]?.url) {
                        origForComp = history[idx - 1].url;
                      }
                    }
                    setOriginalImageForCompare(origForComp);
                    setZoomViewingMode('edited');

                    if (isEditItem) {
                      // Item was an edit: populate edit box and switch to Edit mode
                      setIsEditMode(true);
                      if (item.prompt) {
                        setEditPrompt(item.prompt);
                      }
                    } else {
                      // Item was generated: populate Keyframe Visual Description and switch to Text-to-Image mode
                      setIsEditMode(false);
                      if (item.prompt) {
                        setPrompt(item.prompt);
                      }
                    }

                    // If model info was stored, switch to that model
                    if (item.modelUsed?.includes('seedream')) {
                      setEditModel('seedream_v5_pro');
                    } else if (item.modelUsed?.includes('gemini') && isEditItem) {
                      setEditModel('nano_banana_2');
                    }

                    // If aspect ratio and size were stored, restore them too
                    if (item.aspectRatio) {
                      setAspectRatio(item.aspectRatio as AspectRatio);
                    }
                    if (item.imageSize) {
                      setImageSize(item.imageSize as ImageSize);
                    }

                    updateStudio(item.url, item.mime, history, origForComp);
                    onShowToast(
                      item.prompt
                        ? isEditItem
                          ? `Restored edit prompt: "${item.prompt.slice(0, 30)}…"`
                          : `Restored visual prompt: "${item.prompt.slice(0, 30)}…"`
                        : `Restored version ${idx + 1}`
                    );
                  }}
                  className={`w-16 h-16 rounded-xl overflow-hidden border transition block relative text-left bg-neutral-900 group ${
                    isItemActive
                      ? 'border-pink-500 ring-2 ring-pink-500/40 shadow-md shadow-pink-500/25'
                      : 'border-white/15 hover:border-pink-500 hover:ring-2 hover:ring-pink-500/20'
                  }`}
                  title={item.prompt ? `Prompt: ${item.prompt}` : `Restore: ${item.label}`}
                >
                  <img src={item.url} alt={`v${idx + 1}`} className="w-full h-full object-cover" />
                  <span
                    className={`absolute bottom-0 inset-x-0 px-1 py-0.5 text-[9px] text-center font-mono truncate ${
                      isItemActive ? 'bg-pink-600/90 text-white font-bold' : 'bg-black/80 text-neutral-300'
                    }`}
                  >
                    {isItemActive ? 'Active' : item.prompt ? item.prompt.slice(0, 10) : `v${idx + 1}`}
                  </span>
                </button>
              )}

              {/* Top action buttons: Delete (Trash) and Download - Hidden on mobile view, visible on desktop hover */}
              {item.status !== 'loading' && (
                <div className="hidden sm:flex absolute top-1 right-1 items-center gap-0.5 opacity-0 group-hover:opacity-100 transition z-10">
                  <button
                    type="button"
                    onClick={(e) => handleDeleteHistoryItem(idx, e)}
                    className="p-1 rounded bg-black/90 text-neutral-300 hover:text-rose-400 hover:bg-rose-950/80 transition shadow border border-white/10"
                    title="Delete this history item"
                  >
                    <X className="w-2.5 h-2.5" />
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDownload(item.url, `wan3-keyframe-v${idx + 1}-${Date.now()}.png`);
                    }}
                    className="p-1 rounded bg-black/90 text-neutral-300 hover:text-pink-300 transition shadow border border-white/10"
                    title="Download this version"
                  >
                    <Download className="w-2.5 h-2.5" />
                  </button>
                </div>
              )}
            </div>
          );
        })}

        {/* Current Active Indicator if not already present in history */}
        {generatedImage && !history.some((h) => h.url === generatedImage) && (
          <div
            className="w-16 h-16 rounded-xl overflow-hidden border-2 border-pink-500 flex-shrink-0 relative shadow-lg shadow-pink-500/20 bg-neutral-900"
            title="Currently active frame in studio"
          >
            <img src={generatedImage} alt="Current" className="w-full h-full object-cover" />
            <span className="absolute bottom-0 inset-x-0 bg-pink-600/90 text-[9px] text-center font-mono text-white font-bold py-0.5">
              Active
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
