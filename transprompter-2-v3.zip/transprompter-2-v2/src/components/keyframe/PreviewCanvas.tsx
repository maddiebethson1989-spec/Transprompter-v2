import { Download, Wand2, Upload, Trash2, ZoomIn, RotateCcw } from 'lucide-react';
import type { KeyframeStudio } from './useKeyframeStudio';

interface PreviewCanvasProps {
  studio: KeyframeStudio;
}

export function PreviewCanvas({ studio }: PreviewCanvasProps) {
  const {
    imageSize,
    aspectRatio,
    generatedImage,
    setIsZoomModalOpen,
    setZoomScale,
    isButtonCooldown,
    activeItem,
    handleClearActiveImage,
    handleRetry,
    isDragOver,
    setIsDragOver,
    handleOpenUpload,
    processUploadedFile,
    handleDownload,
  } = studio;

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragOver(true);
      }}
      onDragLeave={() => setIsDragOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setIsDragOver(false);
        const file = e.dataTransfer.files?.[0];
        if (file) processUploadedFile(file, 'edit');
      }}
      className={`relative aspect-video w-full rounded-xl overflow-hidden bg-[#0e0e17] border flex items-center justify-center group transition ${
        isDragOver ? 'border-pink-500 ring-2 ring-pink-500/40 bg-pink-950/20' : 'border-white/10'
      }`}
    >
      {/* Drag-over overlay */}
      {isDragOver && (
        <div className="absolute inset-0 z-30 bg-[#0e0e17]/90 backdrop-blur-sm flex flex-col items-center justify-center gap-2 border-2 border-dashed border-pink-500 rounded-xl text-pink-300 animate-in fade-in duration-150">
          <Upload className="w-10 h-10 animate-bounce text-pink-400" />
          <span className="text-sm font-semibold">Drop image to load into Studio</span>
          <span className="text-xs text-neutral-400">Ready for editing or crafting reverse prompts</span>
        </div>
      )}

      {activeItem?.status === 'loading' ? (
        <div className="relative w-full h-full flex items-center justify-center bg-black overflow-hidden select-none animate-in fade-in duration-200">
          <video
            key="preview-loader-video"
            src="/media/loader.mp4"
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-contain bg-black"
          />
        </div>
      ) : generatedImage ? (
        <>
          <img
            src={generatedImage}
            alt="Generated Keyframe"
            onClick={() => {
              setZoomScale(1);
              setIsZoomModalOpen(true);
            }}
            className="w-full h-full object-contain bg-black/60 cursor-zoom-in"
            title="Click to zoom rendered preview"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 opacity-0 group-hover:opacity-100 transition-opacity p-4 flex flex-col justify-between pointer-events-none">
            <div className="flex items-center justify-between pointer-events-auto">
              <span className="text-xs font-mono px-2 py-1 rounded bg-black/60 backdrop-blur-md text-pink-300 border border-white/10">
                {imageSize} · {aspectRatio}
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setZoomScale(1);
                    setIsZoomModalOpen(true);
                  }}
                  className="p-1.5 rounded-lg bg-black/60 hover:bg-black/80 text-pink-300 hover:text-white backdrop-blur-md border border-white/10 transition"
                  title="Zoom & Inspect Frame"
                >
                  <ZoomIn className="w-4 h-4 text-pink-400" />
                </button>
                <button
                  type="button"
                  onClick={handleClearActiveImage}
                  className="p-1.5 rounded-lg bg-red-950/70 hover:bg-red-900/90 text-red-300 backdrop-blur-md border border-red-500/40 transition"
                  title="Clear active image from canvas"
                >
                  <Trash2 className="w-4 h-4 text-red-400" />
                </button>
                <button
                  onClick={() => handleDownload()}
                  className="p-1.5 rounded-lg bg-black/60 hover:bg-black/80 text-white backdrop-blur-md border border-white/10 transition"
                  title="Download Image"
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={handleRetry}
                  disabled={isButtonCooldown}
                  className="p-1.5 rounded-lg bg-pink-500/20 hover:bg-pink-500/40 text-pink-300 hover:text-white backdrop-blur-md border border-pink-500/40 transition disabled:opacity-50"
                  title="Retry Frame"
                >
                  <RotateCcw className="w-4 h-4 text-pink-400" />
                </button>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="flex flex-col items-center justify-center p-6 text-center gap-3 w-full max-w-sm">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-pink-500/20 via-purple-500/20 to-blue-500/10 border border-white/10 flex items-center justify-center text-pink-300 shadow-inner">
            <Upload className="w-6 h-6 text-pink-400" />
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-sm font-semibold text-neutral-200">Keyframe Studio Canvas</span>
            <span className="text-xs text-neutral-400">
              Generate from text, or upload an image to run AI edits or craft reverse prompts
            </span>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-2 mt-1 w-full">
            <button
              type="button"
              onClick={() => handleOpenUpload('edit')}
              className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 text-white text-xs font-semibold shadow-md flex items-center gap-1.5 transition"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload to Edit</span>
            </button>
            <button
              type="button"
              onClick={() => handleOpenUpload('reverse_prompt')}
              className="px-3 py-1.5 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/40 text-xs font-semibold transition flex items-center gap-1.5"
            >
              <Wand2 className="w-3.5 h-3.5 text-purple-300" />
              <span>Upload & Craft Reverse Prompt</span>
            </button>
          </div>
          <span className="text-[10px] text-neutral-500">Supports PNG, JPG, or WEBP · Drag & drop directly here</span>
        </div>
      )}
    </div>
  );
}
