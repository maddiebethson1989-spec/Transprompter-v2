import { Sparkles, Loader2 } from 'lucide-react';
import type { KeyframeStudio } from './useKeyframeStudio';
import { PRESET_PROMPTS } from './constants';

interface GenerateModePanelProps {
  studio: KeyframeStudio;
}

export function GenerateModePanel({ studio }: GenerateModePanelProps) {
  const { onShowToast, prompt, setPrompt, imageSize, setEditPrompt, isButtonCooldown, handleGenerate } = studio;

  return (
    <div className="flex flex-col gap-4 animate-in fade-in duration-200">
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="block text-sm font-semibold text-neutral-300">
            Keyframe Visual Description (End Frame B)
          </label>
        </div>
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Describe the cinematic frame in vivid photographic or painterly detail: lighting, character posture, materials, atmosphere, camera lens..."
          rows={4}
          className="w-full bg-[#0e0e17] border border-white/10 rounded-xl p-3.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500/60 focus:ring-2 focus:ring-pink-500/20 transition resize-none"
        />
      </div>

      {/* Presets */}
      <div>
        <div className="mb-2">
          <span className="text-xs font-medium text-neutral-400 block">Transformation Scenario Presets:</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {PRESET_PROMPTS.map((p, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                setPrompt(p.prompt);
                if (p.matchingEdit) {
                  setEditPrompt(p.matchingEdit);
                }
                onShowToast(`✓ Loaded preset "${p.title}"`);
              }}
              className="text-left p-2.5 rounded-lg bg-neutral-900/60 border border-white/5 hover:border-pink-500/30 hover:bg-pink-500/5 transition text-xs group"
              title="Click to populate Keyframe Visual Description"
            >
              <div className="font-semibold text-neutral-300 group-hover:text-pink-300 flex items-center justify-between">
                <span>{p.title}</span>
                <Sparkles className="w-3 h-3 text-pink-400 opacity-60 group-hover:opacity-100" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Action button for generation */}
      <button
        onClick={() => handleGenerate()}
        disabled={isButtonCooldown || !prompt.trim()}
        className="relative overflow-hidden w-full py-3.5 px-6 rounded-xl font-semibold text-sm text-white bg-gradient-to-r from-pink-600 via-fuchsia-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-pink-600/30 transition transform active:scale-[0.99]"
      >
        <div className="relative z-10 flex items-center justify-center gap-2">
          {isButtonCooldown ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-white" />
              <span>Submitting generation…</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Generate {imageSize} Keyframe</span>
            </>
          )}
        </div>
        <div className="btn-shimmer" />
      </button>
    </div>
  );
}
