import { ImageSize, AspectRatio } from '../../types';
import { Sparkles } from 'lucide-react';
import type { KeyframeStudio } from './useKeyframeStudio';

interface ResolutionControlsProps {
  studio: KeyframeStudio;
}

export function ResolutionControls({ studio }: ResolutionControlsProps) {
  const {
    imageSize,
    setImageSize,
    aspectRatio,
    isAutoRatio,
    detectedRatio,
    detectedDimensions,
    isEditMode,
    editModel,
    seedreamSize,
    handleSelectAutoRatio,
    handleSelectSpecificRatio,
  } = studio;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-white/10">
      {/* Image Resolution Tier */}
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-300">
            Resolution Quality
          </label>
        </div>
        <div className="grid grid-cols-3 gap-1.5 bg-[#0e0e17] p-1 rounded-xl border border-white/10">
          {(['1K', '2K', '4K'] as ImageSize[]).map((size) => {
            const isSeedreamDisabled = isEditMode && editModel === 'seedream_v5_pro' && size === '4K';
            const isSelected = imageSize === size;

            return (
              <button
                key={size}
                type="button"
                disabled={isSeedreamDisabled}
                onClick={() => {
                  if (!isSeedreamDisabled) {
                    setImageSize(size);
                  }
                }}
                className={`py-2 px-2 rounded-lg text-xs font-bold transition flex flex-col items-center gap-0.5 ${
                  isSeedreamDisabled
                    ? 'opacity-30 cursor-not-allowed bg-black/20 text-neutral-600 border border-white/5'
                    : isSelected
                      ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-lg shadow-pink-500/25'
                      : 'text-neutral-400 hover:text-white hover:bg-white/5'
                }`}
                title={
                  isSeedreamDisabled
                    ? '4K resolution is not supported by Seedream-v5.0-Pro (max 2K)'
                    : `${size} Resolution`
                }
              >
                <span>{size}</span>
                <span className="text-[9px] opacity-75 font-normal">
                  {isSeedreamDisabled ? 'N/A' : size === '1K' ? '1K Tier' : size === '2K' ? '2K Tier' : 'Ultra-4K'}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Aspect Ratio */}
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-2">
            <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-300">
              Aspect Ratio
            </label>
            {isEditMode && isAutoRatio && (
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 flex items-center gap-1 animate-in fade-in duration-150">
                <Sparkles className="w-2.5 h-2.5 text-pink-400" />
                <span>Auto: {detectedRatio}</span>
                {detectedDimensions && (
                  <span className="opacity-75">
                    ({detectedDimensions.width}×{detectedDimensions.height})
                  </span>
                )}
              </span>
            )}
          </div>
          {isEditMode && editModel === 'seedream_v5_pro' && (
            <span className="text-[10px] font-mono text-pink-400">{seedreamSize}</span>
          )}
        </div>

        {isEditMode ? (
          /* Edit Existing Image Aspect Ratio with "Auto" option to match image */
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1 bg-[#0e0e17] p-1 rounded-xl border border-white/10">
            {/* Auto Option */}
            <button
              type="button"
              onClick={handleSelectAutoRatio}
              className={`py-2 px-1 rounded-lg text-xs font-bold transition flex flex-col items-center gap-0.5 relative ${
                isAutoRatio
                  ? 'bg-gradient-to-r from-pink-500/30 to-purple-600/30 text-pink-200 border border-pink-500/60 shadow-md shadow-pink-500/10'
                  : 'text-neutral-400 hover:text-white hover:bg-white/5 border border-transparent'
              }`}
              title={
                detectedDimensions
                  ? `Auto-match image aspect ratio: ${detectedRatio} (${detectedDimensions.width}×${detectedDimensions.height})`
                  : 'Auto-match image aspect ratio'
              }
            >
              <span className="flex items-center gap-1">
                <Sparkles className={`w-3 h-3 ${isAutoRatio ? 'text-pink-300' : 'text-neutral-400'}`} />
                <span>Auto</span>
              </span>
              <span className="text-[9px] opacity-80 font-normal truncate max-w-full">
                {detectedDimensions ? `Match (${detectedRatio})` : 'Match Image'}
              </span>
            </button>

            {(['16:9', '4:3', '1:1', '3:4', '9:16'] as AspectRatio[]).map((ratio) => (
              <button
                key={ratio}
                type="button"
                onClick={() => handleSelectSpecificRatio(ratio)}
                className={`py-2 px-1 rounded-lg text-xs font-bold transition flex flex-col items-center gap-0.5 ${
                  !isAutoRatio && aspectRatio === ratio
                    ? 'bg-pink-500/20 text-pink-300 border border-pink-500/40'
                    : 'text-neutral-400 hover:text-white hover:bg-white/5 border border-transparent'
                }`}
              >
                <span>{ratio}</span>
                <span className="text-[9px] opacity-75 font-normal">
                  {ratio === '16:9'
                    ? 'WAN'
                    : ratio === '4:3'
                      ? 'Standard'
                      : ratio === '1:1'
                        ? 'Square'
                        : ratio === '3:4'
                          ? 'Portrait'
                          : 'Vert'}
                </span>
              </button>
            ))}
          </div>
        ) : (
          /* Text-to-Image Standard Aspect Ratio options */
          <div className="grid grid-cols-5 gap-1 bg-[#0e0e17] p-1 rounded-xl border border-white/10">
            {(['16:9', '4:3', '1:1', '3:4', '9:16'] as AspectRatio[]).map((ratio) => (
              <button
                key={ratio}
                type="button"
                onClick={() => handleSelectSpecificRatio(ratio)}
                className={`py-2 px-1 rounded-lg text-xs font-bold transition flex flex-col items-center gap-0.5 ${
                  aspectRatio === ratio
                    ? 'bg-pink-500/20 text-pink-300 border border-pink-500/40'
                    : 'text-neutral-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <span>{ratio}</span>
                <span className="text-[9px] opacity-75 font-normal">
                  {ratio === '16:9'
                    ? 'WAN'
                    : ratio === '4:3'
                      ? 'Standard'
                      : ratio === '1:1'
                        ? 'Square'
                        : ratio === '3:4'
                          ? 'Portrait'
                          : 'Vert'}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
