import { Download, Trash2, RotateCcw } from 'lucide-react';
import type { KeyframeStudio } from './useKeyframeStudio';

interface BindFrameActionsProps {
  studio: KeyframeStudio;
}

export function BindFrameActions({ studio }: BindFrameActionsProps) {
  const {
    imageSize,
    appliedTo,
    isButtonCooldown,
    handleDeleteActiveFrame,
    handleRetry,
    handleApplyStart,
    handleApplyEnd,
    handleDownload,
  } = studio;

  return (
    <div className="pt-2 border-t border-white/10 flex flex-col gap-3">
      <span className="text-xs font-semibold text-neutral-400">Direct Pipeline Integration:</span>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <button
          onClick={handleApplyStart}
          className={`py-3 px-4 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-2 ${
            appliedTo === 'start' || appliedTo === 'both'
              ? 'bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-600/30'
              : 'bg-indigo-500/15 border-indigo-500/30 text-indigo-300 hover:bg-indigo-500/25'
          }`}
        >
          <span className="w-5 h-5 rounded-md bg-indigo-500/30 flex items-center justify-center font-bold">A</span>
          <span>
            {appliedTo === 'start' || appliedTo === 'both' ? '✓ Set as Start Frame (Active)' : 'Use as Start Frame (A)'}
          </span>
        </button>

        <button
          onClick={handleApplyEnd}
          className={`py-3 px-4 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-2 ${
            appliedTo === 'end' || appliedTo === 'both'
              ? 'bg-pink-600 text-white border-pink-400 shadow-md shadow-pink-600/30'
              : 'bg-pink-500/15 border-pink-500/30 text-pink-300 hover:bg-pink-500/25'
          }`}
        >
          <span className="w-5 h-5 rounded-md bg-pink-500/30 flex items-center justify-center font-bold">B</span>
          <span>
            {appliedTo === 'end' || appliedTo === 'both' ? '✓ Set as End Frame (Active)' : 'Use as End Frame (B)'}
          </span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => handleDownload()}
          className="w-full py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-medium text-neutral-300 hover:text-white flex items-center justify-center gap-2 transition"
        >
          <Download className="w-3.5 h-3.5 text-pink-400" />
          <span>Download ({imageSize} · PNG)</span>
        </button>
        <button
          type="button"
          onClick={handleRetry}
          disabled={isButtonCooldown}
          className="w-full py-2 px-3 rounded-xl bg-pink-500/15 hover:bg-pink-500/25 border border-pink-500/30 text-xs font-medium text-pink-300 hover:text-pink-200 flex items-center justify-center gap-2 transition disabled:opacity-50"
          title="Retry generation or edit on original image"
        >
          <RotateCcw className="w-3.5 h-3.5 text-pink-400" />
          <span>Retry Active Frame</span>
        </button>
      </div>

      <button
        type="button"
        onClick={handleDeleteActiveFrame}
        className="w-full py-2 px-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-xs font-medium text-red-300 hover:text-red-200 flex items-center justify-center gap-2 transition active:scale-[0.99]"
        title="Delete active frame from history and canvas"
      >
        <Trash2 className="w-3.5 h-3.5 text-red-400" />
        <span>Delete Active Frame</span>
      </button>
    </div>
  );
}
