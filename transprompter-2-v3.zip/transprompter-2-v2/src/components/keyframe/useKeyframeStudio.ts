import React, { useState, useRef, useEffect } from 'react';
import { ImageSize, AspectRatio, KeyframeImage, KeyframeEditModel, KeyframeHistoryItem } from '../../types';
import { safeFetchJson } from '../../utils/safeApi';
import { saveStudioSession } from '../../utils/persistentStorage';
import { detectNearestAspectRatio } from './aspectRatio';
import type { KeyframeGeneratorProps, ReferenceImageItem } from './types';

export function useKeyframeStudio({
  onSelectAsStartFrame,
  onSelectAsEndFrame,
  onShowToast,
  activeStudioImage,
  activeStudioMime = 'image/png',
  studioHistory = [],
  originalForCompare: originalForCompareProp = null,
  startImage,
  endImage,
  onUpdateStudioState,
}: KeyframeGeneratorProps) {
  // Generation parameters
  const [prompt, setPrompt] = useState('');
  const [imageSize, setImageSize] = useState<ImageSize>('2K');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('4:3');

  // Multi-image reference tracking for Seedream 5.0 Pro (supports up to 10 images)
  const [referenceImages, setReferenceImages] = useState<ReferenceImageItem[]>([]);
  const refUploadInputRef = useRef<HTMLInputElement>(null);

  // Auto Aspect Ratio tracking for Edit Existing Image mode to match base image
  const [isAutoRatio, setIsAutoRatio] = useState(false);
  const [detectedRatio, setDetectedRatio] = useState<AspectRatio>('4:3');
  const [detectedDimensions, setDetectedDimensions] = useState<{ width: number; height: number } | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingAction, setLoadingAction] = useState<'generate' | 'edit'>('generate');
  const [error, setError] = useState<string | null>(null);

  // 1-second cooldown on buttons so user can generate or edit again after 1s
  const [isGenerateCoolingDown, setIsGenerateCoolingDown] = useState(false);
  const [isEditCoolingDown, setIsEditCoolingDown] = useState(false);

  // Tracking in-flight generation/edit job
  const activeJobRef = useRef<{
    id: string;
    type: 'generate' | 'edit';
    prompt: string;
    sourcePhoto?: string | null;
    sourceMime?: string;
    aspectRatio: AspectRatio;
    imageSize: ImageSize;
    modelUsed: string;
  } | null>(null);

  // Result images & version history initialized from persistent props
  const [generatedImage, setGeneratedImage] = useState<string | null>(activeStudioImage ?? null);
  const [generatedMime, setGeneratedMime] = useState<string>(activeStudioMime || 'image/png');
  const [history, setHistory] = useState<KeyframeHistoryItem[]>(studioHistory || []);
  const [appliedTo, setAppliedTo] = useState<'start' | 'end' | 'both' | null>(null);

  // Original image tracking for A/B comparison on edit generations
  const [originalImageForCompare, setOriginalImageForCompare] = useState<string | null>(originalForCompareProp ?? null);
  // In zoom lightbox: 'edited' (default) or 'original'
  const [zoomViewingMode, setZoomViewingMode] = useState<'edited' | 'original'>('edited');

  // Zoom inspector modal state for Rendered Preview
  const [isZoomModalOpen, setIsZoomModalOpen] = useState(false);
  const [zoomScale, setZoomScale] = useState(1);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isZoomModalOpen) {
        setIsZoomModalOpen(false);
      }
      // Toggle compare shortcut (c, b, or Space) when zoomed in on an edit generation
      if (
        (e.key === 'c' || e.key === 'C' || e.key === 'b' || e.key === 'B') &&
        isZoomModalOpen &&
        originalImageForCompare
      ) {
        setZoomViewingMode((prev) => (prev === 'edited' ? 'original' : 'edited'));
      }
    };
    if (isZoomModalOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isZoomModalOpen, originalImageForCompare]);

  // Sync state if props change from outside (e.g. storage reload)
  useEffect(() => {
    if (activeStudioImage !== undefined && activeStudioImage !== generatedImage) {
      setGeneratedImage(activeStudioImage);
    }
    if (activeStudioMime && activeStudioMime !== generatedMime) {
      setGeneratedMime(activeStudioMime);
    }
  }, [activeStudioImage, activeStudioMime]);

  useEffect(() => {
    if (studioHistory && studioHistory !== history) {
      setHistory(studioHistory);
    }
  }, [studioHistory]);

  useEffect(() => {
    if (originalForCompareProp !== undefined && originalForCompareProp !== originalImageForCompare) {
      setOriginalImageForCompare(originalForCompareProp);
    }
  }, [originalForCompareProp]);

  // Edit Prompt mode state - default to edit mode if there's already an active image
  const [editPrompt, setEditPrompt] = useState('');
  const [isEditMode, setIsEditMode] = useState(Boolean(activeStudioImage));

  const studioControlsRef = useRef<HTMLDivElement>(null);
  const copilotRef = useRef<HTMLDivElement>(null);
  const [copilotInitialQuery, setCopilotInitialQuery] = useState<string | null>(null);

  // Callback from Copilot to apply initial generation prompt (End Frame)
  const handleApplyInitialPrompt = (newPromptText: string, autoGenerate: boolean = false) => {
    setPrompt(newPromptText);
    setIsEditMode(false);
    studioControlsRef.current?.scrollIntoView({ behavior: 'smooth' });
    if (autoGenerate) {
      handleGenerate(newPromptText);
    } else {
      onShowToast('✓ Loaded prompt into Text-to-Image studio');
    }
  };

  // Callback from Copilot to apply reverse edit prompt (Start Frame)
  const handleApplyEditPrompt = (newEditPromptText: string, autoRunEdit: boolean = false) => {
    setEditPrompt(newEditPromptText);
    setIsEditMode(true);
    setEditModel('nano_banana_2');
    studioControlsRef.current?.scrollIntoView({ behavior: 'smooth' });
    if (autoRunEdit && generatedImage) {
      handleRunEdit(newEditPromptText);
    } else {
      onShowToast('✓ Loaded prompt into Edit mode');
    }
  };

  // Edit Model selection: Nano Banana 2 (gemini-3.1-flash-image) or Seedream-v5.0-Pro (ByteDance via AtlasCloud)
  const [editModel, setEditModel] = useState<KeyframeEditModel>('nano_banana_2');
  const [seedreamFormat, setSeedreamFormat] = useState<'jpeg' | 'png'>('jpeg');
  const [seedreamThinking, setSeedreamThinking] = useState<'enabled' | 'disabled'>('enabled');
  const [seedreamSafetyChecker, setSeedreamSafetyChecker] = useState<boolean>(false);
  const [seedreamMode, setSeedreamMode] = useState<'standard' | 'fast'>('standard');
  const [seedreamStatus, setSeedreamStatus] = useState<string>('');
  const [seedreamSeconds, setSeedreamSeconds] = useState<number>(0);

  // Ensure 4K is not selected if active model is Seedream
  useEffect(() => {
    if (isEditMode && editModel === 'seedream_v5_pro' && imageSize === '4K') {
      setImageSize('2K');
    }
  }, [editModel, isEditMode, imageSize]);

  // Unified Seedream pixel dimensions calculated from official AtlasCloud 2K & 1.5K presets
  const getSeedreamDimensions = (size: ImageSize, ratio: AspectRatio): string => {
    if (size === '1K') {
      switch (ratio) {
        case '16:9':
          return '2048*1152'; // 1.5K official preset
        case '9:16':
          return '1152*2048'; // 1.5K official preset
        case '1:1':
          return '1024*1024'; // 1K official preset
        case '4:3':
          return '1776*1328'; // 1.5K official preset
        case '3:4':
          return '1328*1776'; // 1.5K official preset
        default:
          return '1024*1024';
      }
    } else {
      // 2K (or 4K which maps to Seedream max 2K resolution)
      switch (ratio) {
        case '16:9':
          return '2816*1584'; // 2K official preset
        case '9:16':
          return '1584*2816'; // 2K official preset
        case '1:1':
          return '2048*2048'; // 2K official preset
        case '4:3':
          return '2368*1776'; // 2K official preset
        case '3:4':
          return '1776*2368'; // 2K official preset
        default:
          return '2048*2048';
      }
    }
  };

  const seedreamSize = getSeedreamDimensions(imageSize, aspectRatio);

  const editPollRef = useRef<NodeJS.Timeout | null>(null);
  const editTimerRef = useRef<NodeJS.Timeout | null>(null);

  // 1-second button cooldown state so generate/edit button becomes active again after 1s
  const [isButtonCooldown, setIsButtonCooldown] = useState(false);
  const buttonCooldownTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Active history item ID being viewed (allows switching between generating jobs and completed images)
  const [activeHistoryItemId, setActiveHistoryItemId] = useState<string | null>(null);
  const activeHistoryItemIdRef = useRef<string | null>(null);
  const generatedImageRef = useRef<string | null>(generatedImage);
  const generatedMimeRef = useRef<string>(generatedMime);
  const originalImageForCompareRef = useRef<string | null>(originalImageForCompare);

  useEffect(() => {
    activeHistoryItemIdRef.current = activeHistoryItemId;
  }, [activeHistoryItemId]);

  useEffect(() => {
    generatedImageRef.current = generatedImage;
  }, [generatedImage]);

  useEffect(() => {
    generatedMimeRef.current = generatedMime;
  }, [generatedMime]);

  useEffect(() => {
    originalImageForCompareRef.current = originalImageForCompare;
  }, [originalImageForCompare]);

  // Derived currently active history item (or null)
  const activeItem = activeHistoryItemId
    ? history.find((h) => h.id === activeHistoryItemId) || null
    : generatedImage
      ? history.find((h) => h.url === generatedImage) || null
      : null;

  // Inspect generated/active image to detect its real dimensions and nearest aspect ratio for Auto mode
  useEffect(() => {
    if (!generatedImage) {
      setDetectedDimensions(null);
      return;
    }
    const img = new Image();
    img.onload = () => {
      const w = img.naturalWidth || img.width;
      const h = img.naturalHeight || img.height;
      if (w && h) {
        setDetectedDimensions({ width: w, height: h });
        const nearest = detectNearestAspectRatio(w, h);
        setDetectedRatio(nearest);
        if (isAutoRatio) {
          setAspectRatio(nearest);
        }
      }
    };
    img.src = generatedImage;
  }, [generatedImage, isAutoRatio]);

  const handleSelectAutoRatio = () => {
    setIsAutoRatio(true);
    if (generatedImage) {
      const img = new Image();
      img.onload = () => {
        const w = img.naturalWidth || img.width;
        const h = img.naturalHeight || img.height;
        if (w && h) {
          const nearest = detectNearestAspectRatio(w, h);
          setDetectedDimensions({ width: w, height: h });
          setDetectedRatio(nearest);
          setAspectRatio(nearest);
          onShowToast(`✓ Aspect ratio auto-matched to image (${nearest} · ${w}×${h})`);
        }
      };
      img.src = generatedImage;
    } else {
      onShowToast('✓ Auto aspect ratio enabled (matches image being edited)');
    }
  };

  const handleSelectSpecificRatio = (ratio: AspectRatio) => {
    setIsAutoRatio(false);
    setAspectRatio(ratio);
  };

  useEffect(() => {
    return () => {
      if (editPollRef.current) clearInterval(editPollRef.current);
      if (editTimerRef.current) clearInterval(editTimerRef.current);
      if (buttonCooldownTimerRef.current) clearTimeout(buttonCooldownTimerRef.current);
    };
  }, []);

  // Sync to parent studio state whenever generatedImage or history updates
  const updateStudio = (
    newImage: string | null,
    newMime: string,
    newHistory: KeyframeHistoryItem[],
    newOriginalCompare?: string | null
  ) => {
    setGeneratedImage(newImage);
    setGeneratedMime(newMime);
    setHistory(newHistory);
    const origToUse = newOriginalCompare !== undefined ? newOriginalCompare : originalImageForCompare;
    if (newOriginalCompare !== undefined) {
      setOriginalImageForCompare(newOriginalCompare);
    }
    onUpdateStudioState?.(newImage, newMime, newHistory, origToUse);
    saveStudioSession({
      image: newImage,
      mime: newMime,
      history: newHistory,
      originalForCompare: origToUse,
    }).catch(() => {});
  };

  // Delete an individual history item
  const handleDeleteHistoryItem = (indexToDelete: number, e: React.MouseEvent) => {
    e.stopPropagation();
    const itemToDelete = history[indexToDelete];
    const newHistory = history.filter((_, idx) => idx !== indexToDelete);
    setHistory(newHistory);

    // If deleting the currently active item, clear canvas
    if (
      (itemToDelete?.id && itemToDelete.id === activeHistoryItemId) ||
      (itemToDelete?.url && itemToDelete.url === generatedImage)
    ) {
      setGeneratedImage(null);
      setActiveHistoryItemId(null);
      setOriginalImageForCompare(null);
      onUpdateStudioState?.(null, 'image/png', newHistory, null);
      saveStudioSession({
        image: null,
        mime: 'image/png',
        history: newHistory.filter((h) => h.status !== 'loading' && Boolean(h.url)),
        originalForCompare: null,
      }).catch(() => {});
    } else {
      onUpdateStudioState?.(generatedImage, generatedMime, newHistory, originalImageForCompare);
      saveStudioSession({
        image: generatedImage,
        mime: generatedMime,
        history: newHistory.filter((h) => h.status !== 'loading' && Boolean(h.url)),
        originalForCompare: originalImageForCompare,
      }).catch(() => {});
    }
    onShowToast('History item deleted');
  };

  // Clear all history
  const handleClearAllHistory = () => {
    setHistory([]);
    setActiveHistoryItemId(null);
    setOriginalImageForCompare(null);
    onUpdateStudioState?.(generatedImage, generatedMime, [], null);
    saveStudioSession({
      image: generatedImage,
      mime: generatedMime,
      history: [],
      originalForCompare: null,
    }).catch(() => {});
    onShowToast('History cleared');
  };

  // Clear the active image from the canvas (saving to history if not already present)
  const handleClearActiveImage = () => {
    if (!generatedImage) return;

    const alreadyInHistory = history.some((h) => h.url === generatedImage);
    let updatedHistory = history;
    if (!alreadyInHistory) {
      const currentPromptText = (isEditMode ? editPrompt : prompt) || '';
      updatedHistory = [
        ...history,
        {
          id: `item-${Date.now()}-${Math.random()}`,
          url: generatedImage,
          mime: generatedMime,
          label: isEditMode ? 'Edited Version' : 'Keyframe',
          prompt: currentPromptText,
          promptType: isEditMode ? 'edit' : 'generation',
          isEdit: isEditMode,
          originalImageUrl: originalImageForCompare || undefined,
          timestamp: Date.now(),
          aspectRatio,
          imageSize,
          modelUsed: isEditMode
            ? editModel === 'seedream_v5_pro'
              ? 'bytedance/seedream-v5.0-pro/edit'
              : 'gemini-3.1-flash-image'
            : 'gemini-3.1-flash-image',
        },
      ];
    }
    setGeneratedImage(null);
    setActiveHistoryItemId(null);
    setOriginalImageForCompare(null);
    setAppliedTo(null);
    setError(null);
    setHistory(updatedHistory);
    onUpdateStudioState?.(null, 'image/png', updatedHistory, null);
    saveStudioSession({
      image: null,
      mime: 'image/png',
      history: updatedHistory.filter((h) => h.status !== 'loading' && Boolean(h.url)),
      originalForCompare: null,
    }).catch(() => {});
    onShowToast('✓ Active image cleared from canvas (preserved in History)');
  };

  // Delete the active frame from history and clear it from the active image (User Request 4)
  const handleDeleteActiveFrame = () => {
    if (!generatedImage) return;

    const currentUrl = generatedImage;
    const updatedHistory = history.filter((h) => h.url !== currentUrl);

    setGeneratedImage(null);
    setActiveHistoryItemId(null);
    setOriginalImageForCompare(null);
    setAppliedTo(null);
    setError(null);
    setHistory(updatedHistory);

    onUpdateStudioState?.(null, 'image/png', updatedHistory, null);
    saveStudioSession({
      image: null,
      mime: 'image/png',
      history: updatedHistory.filter((h) => h.status !== 'loading' && Boolean(h.url)),
      originalForCompare: null,
    }).catch(() => {});

    onShowToast('🗑️ Active frame deleted from history and canvas');
  };

  // Reset Text to Image, Edit Image, and Rendered Preview to default settings
  const [isConfirmingReset, setIsConfirmingReset] = useState(false);
  const resetTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    return () => {
      if (resetTimerRef.current) {
        clearTimeout(resetTimerRef.current);
      }
    };
  }, []);

  const handleResetButtonClick = () => {
    // If already at defaults, perform clean reset with toast immediately
    const hasWork =
      Boolean(prompt.trim()) ||
      Boolean(editPrompt.trim()) ||
      Boolean(generatedImage) ||
      imageSize !== '2K' ||
      aspectRatio !== '4:3' ||
      isEditMode;

    if (!hasWork) {
      handleResetAll();
      return;
    }

    if (!isConfirmingReset) {
      setIsConfirmingReset(true);
      if (resetTimerRef.current) clearTimeout(resetTimerRef.current);
      resetTimerRef.current = setTimeout(() => {
        setIsConfirmingReset(false);
      }, 4000);
    } else {
      if (resetTimerRef.current) clearTimeout(resetTimerRef.current);
      setIsConfirmingReset(false);
      handleResetAll();
    }
  };

  const handleResetAll = () => {
    // 1. Reset Text to Image to default settings
    setPrompt('');
    setImageSize('2K');
    setAspectRatio('4:3');
    setIsAutoRatio(false);
    setDetectedDimensions(null);
    setIsEditMode(false);

    // 2. Reset Edit Image to default settings
    setEditPrompt('');
    setEditModel('nano_banana_2');
    setSeedreamFormat('jpeg');
    setSeedreamThinking('enabled');
    setSeedreamSafetyChecker(false);
    setSeedreamMode('standard');
    setSeedreamStatus('');
    setSeedreamSeconds(0);

    // 3. Preserve generation history: ensure active image is preserved in history if not already present
    let currentHistory = history;
    if (generatedImage && !history.some((h) => h.url === generatedImage)) {
      currentHistory = [
        ...history,
        {
          id: `item-${Date.now()}-${Math.random()}`,
          url: generatedImage,
          mime: generatedMime,
          label: isEditMode ? 'Edited Version' : 'Keyframe',
          prompt: (isEditMode ? editPrompt : prompt) || '',
          promptType: isEditMode ? 'edit' : 'generation',
          isEdit: isEditMode,
          originalImageUrl: originalImageForCompare || undefined,
          timestamp: Date.now(),
          aspectRatio,
          imageSize,
          modelUsed: isEditMode
            ? editModel === 'seedream_v5_pro'
              ? 'bytedance/seedream-v5.0-pro/edit'
              : 'gemini-3.1-flash-image'
            : 'gemini-3.1-flash-image',
        },
      ];
      setHistory(currentHistory);
    }

    // 4. Reset Rendered Preview canvas to default settings (preserving generation history)
    setGeneratedImage(null);
    setGeneratedMime('image/png');
    setActiveHistoryItemId(null);
    setOriginalImageForCompare(null);
    setZoomViewingMode('edited');
    setAppliedTo(null);
    setError(null);
    setLoading(false);
    setIsButtonCooldown(false);
    setIsGenerateCoolingDown(false);
    setIsEditCoolingDown(false);
    activeJobRef.current = null;

    // 5. Sync persistent storage while preserving history
    onUpdateStudioState?.(null, 'image/png', currentHistory, null);
    saveStudioSession({
      image: null,
      mime: 'image/png',
      history: currentHistory.filter((h) => h.status !== 'loading' && Boolean(h.url)),
      originalForCompare: null,
    }).catch(() => {});

    onShowToast('✓ Keyframe Generator reset to default settings (history preserved)');
  };

  // Custom reference upload for editing
  const uploadInputRef = useRef<HTMLInputElement>(null);

  // Generate a brand new image
  const handleGenerate = async (customPrompt?: string) => {
    const textToUse = (customPrompt || prompt).trim();
    if (!textToUse) {
      setError('Please enter a descriptive prompt for keyframe generation.');
      return;
    }

    const currentJobId = `gen-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const generatingItem: KeyframeHistoryItem = {
      id: currentJobId,
      url: '',
      mime: 'image/png',
      label: 'Generating…',
      prompt: textToUse,
      promptType: 'generation',
      isEdit: false,
      timestamp: Date.now(),
      modelUsed: 'gemini-3.1-flash-image',
      aspectRatio,
      imageSize,
      status: 'loading',
    };

    // If there is currently an active canvas image that isn't in history, preserve it
    let currentHistory = history;
    if (generatedImage && !currentHistory.some((h) => h.url === generatedImage)) {
      currentHistory = [
        ...currentHistory,
        {
          id: `item-${Date.now()}-${Math.random()}`,
          url: generatedImage,
          mime: generatedMime,
          label: 'Generated Keyframe',
          prompt: prompt || textToUse,
          promptType: 'generation',
          isEdit: false,
          timestamp: Date.now() - 500,
          modelUsed: 'gemini-3.1-flash-image',
          aspectRatio,
          imageSize,
        },
      ];
    }

    // Have the generating item appear in history as soon as it begins generating!
    const updatedHistory = [...currentHistory, generatingItem];
    setHistory(updatedHistory);
    setActiveHistoryItemId(currentJobId);
    setGeneratedImage(null);
    setOriginalImageForCompare(null);
    setError(null);
    setAppliedTo(null);

    // Activate 1-second button cooldown: button becomes active again after 1s
    setIsButtonCooldown(true);
    if (buttonCooldownTimerRef.current) clearTimeout(buttonCooldownTimerRef.current);
    buttonCooldownTimerRef.current = setTimeout(() => {
      setIsButtonCooldown(false);
    }, 1000);

    try {
      const data = await safeFetchJson<{ success: boolean; imageUrl?: string; mimeType?: string; error?: string }>(
        '/api/generate-image',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: textToUse,
            imageSize,
            aspectRatio,
          }),
        }
      );

      if (!data.success || !data.imageUrl) {
        throw new Error(data.error || 'Failed to generate image');
      }

      const newUrl = data.imageUrl;
      const newMime = data.mimeType || 'image/png';

      setHistory((prevHistory) => {
        const updated = prevHistory.map((h) => {
          if (h.id === currentJobId) {
            return {
              ...h,
              url: newUrl,
              mime: newMime,
              label: 'Generated Keyframe',
              status: 'completed' as const,
            };
          }
          return h;
        });

        // If the user is currently viewing this generating item on canvas, update canvas to completed image!
        if (activeHistoryItemIdRef.current === currentJobId) {
          setGeneratedImage(newUrl);
          setGeneratedMime(newMime);
          setOriginalImageForCompare(null);
          updateStudio(newUrl, newMime, updated, null);
          onShowToast(`Keyframe generated in ${imageSize} (${aspectRatio})!`);
        } else {
          // The user switched active image to another history item while it was generating!
          // Leave the active image undisturbed; update history and session in background.
          saveStudioSession({
            image: generatedImageRef.current,
            mime: generatedMimeRef.current,
            history: updated.filter((h) => h.status !== 'loading' && Boolean(h.url)),
            originalForCompare: originalImageForCompareRef.current,
          }).catch(() => {});
          onUpdateStudioState?.(
            generatedImageRef.current,
            generatedMimeRef.current,
            updated,
            originalImageForCompareRef.current
          );
          onShowToast(`✓ Keyframe finished rendering! Available in Saved History.`);
        }

        return updated;
      });
    } catch (err: any) {
      console.error(err);
      // Remove failed item from history
      setHistory((prev) => prev.filter((h) => h.id !== currentJobId));
      if (activeHistoryItemIdRef.current === currentJobId) {
        setActiveHistoryItemId(null);
        setError(err?.message || 'Error communicating with Gemini image generator');
      }
      onShowToast('Generation failed: ' + (err?.message || 'Error'));
    }
  };

  // Reference Image Management for Seedream 5.0 Pro (Supports up to 10 images)
  const handleAddReferenceImage = (
    url: string,
    mime: string = 'image/png',
    name?: string,
    source: 'upload' | 'start_frame' | 'end_frame' | 'history' = 'upload'
  ) => {
    if (referenceImages.length >= 9) {
      onShowToast('Maximum 10 reference images reached (1 primary + 9 references)');
      return;
    }
    const newRef: ReferenceImageItem = {
      id: `ref-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      url,
      mime,
      name: name || `Reference #${referenceImages.length + 2}`,
      source,
    };
    setReferenceImages((prev) => [...prev, newRef]);
    onShowToast(`✓ Added reference image (Position ${referenceImages.length + 2})`);
  };

  const handleRemoveReferenceImage = (id: string) => {
    setReferenceImages((prev) => prev.filter((r) => r.id !== id));
    onShowToast('Reference image removed');
  };

  const handleClearReferenceImages = () => {
    setReferenceImages([]);
    onShowToast('Cleared all reference images');
  };

  const handleImportStartFrameAsReference = () => {
    if (!startImage?.data) {
      onShowToast('No Start Frame is currently loaded in the Enhancer tab');
      return;
    }
    const url = startImage.data.startsWith('data:')
      ? startImage.data
      : `data:${startImage.mimeType || 'image/png'};base64,${startImage.data}`;
    handleAddReferenceImage(url, startImage.mimeType || 'image/png', 'Start Frame', 'start_frame');
  };

  const handleImportEndFrameAsReference = () => {
    if (!endImage?.data) {
      onShowToast('No End Frame is currently loaded in the Enhancer tab');
      return;
    }
    const url = endImage.data.startsWith('data:')
      ? endImage.data
      : `data:${endImage.mimeType || 'image/png'};base64,${endImage.data}`;
    handleAddReferenceImage(url, endImage.mimeType || 'image/png', 'End Frame', 'end_frame');
  };

  const handleImportHistoryItemAsReference = (item: KeyframeHistoryItem) => {
    if (!item?.url) return;
    handleAddReferenceImage(item.url, item.mime || 'image/png', item.label || 'History Frame', 'history');
  };

  const handleUploadRefFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const allowed = ['image/png', 'image/jpeg', 'image/webp'];
      if (!allowed.includes(file.type)) return;

      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        handleAddReferenceImage(result, file.type, file.name, 'upload');
      };
      reader.readAsDataURL(file);
    });

    if (e.target) e.target.value = '';
  };

  // Run an edit prompt on the current image (supports Nano Banana 2 or Seedream-v5.0-Pro)
  const handleRunEdit = async (
    customEditInstruction?: string,
    customSourcePhoto?: string,
    customSourceMime?: string
  ) => {
    const instruction = (customEditInstruction || editPrompt).trim();
    if (!instruction) {
      setError('Please provide an edit instruction (e.g. "add glowing wings", "change lighting to sunset").');
      return;
    }
    const sourcePhoto = customSourcePhoto || generatedImage;
    const sourceMime = customSourceMime || generatedMime || 'image/png';
    if (!sourcePhoto) {
      setError('Please select or generate an image first before editing.');
      return;
    }

    const base64Data = sourcePhoto.includes(',') ? sourcePhoto.split(',')[1] : sourcePhoto;

    const currentJobId = `edit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const generatingItem: KeyframeHistoryItem = {
      id: currentJobId,
      url: '',
      mime: 'image/png',
      label: `${editModel === 'seedream_v5_pro' ? 'Seedream' : 'Nano Banana 2'}: ${instruction.slice(0, 15)}…`,
      prompt: instruction,
      promptType: 'edit',
      isEdit: true,
      originalImageUrl: sourcePhoto,
      timestamp: Date.now(),
      modelUsed: editModel === 'seedream_v5_pro' ? 'bytedance/seedream-v5.0-pro/edit' : 'gemini-3.1-flash-image',
      aspectRatio,
      imageSize,
      status: 'loading',
    };

    // Ensure sourcePhoto is in history if not already present
    let currentHistory = history;
    if (sourcePhoto && !currentHistory.some((h) => h.url === sourcePhoto)) {
      currentHistory = [
        ...currentHistory,
        {
          id: `base-${Date.now()}-${Math.random()}`,
          url: sourcePhoto,
          mime: sourceMime,
          label: 'Original Keyframe (Base)',
          prompt: prompt || 'Original keyframe base before edits',
          promptType: 'generation',
          isEdit: false,
          timestamp: Date.now() - 500,
          aspectRatio,
          imageSize,
          modelUsed: 'gemini-3.1-flash-image',
        },
      ];
    }

    // Have the generating edit item appear in history as soon as it begins generating!
    const updatedHistory = [...currentHistory, generatingItem];
    setHistory(updatedHistory);
    setActiveHistoryItemId(currentJobId);
    setGeneratedImage(null);
    setOriginalImageForCompare(sourcePhoto);
    setError(null);
    setAppliedTo(null);

    // Activate 1-second button cooldown: button becomes active again after 1s
    setIsButtonCooldown(true);
    if (buttonCooldownTimerRef.current) clearTimeout(buttonCooldownTimerRef.current);
    buttonCooldownTimerRef.current = setTimeout(() => {
      setIsButtonCooldown(false);
    }, 1000);

    const completeEditJob = (outputImg: string, outputMime: string, modelName: string, successToast: string) => {
      setHistory((prevHistory) => {
        const updated = prevHistory.map((h) => {
          if (h.id === currentJobId) {
            return {
              ...h,
              url: outputImg,
              mime: outputMime,
              label: `${modelName === 'seedream' ? 'Seedream' : 'Nano Banana 2'}: ${instruction.length > 20 ? instruction.slice(0, 20) + '…' : instruction}`,
              status: 'completed' as const,
            };
          }
          return h;
        });

        if (activeHistoryItemIdRef.current === currentJobId) {
          setGeneratedImage(outputImg);
          setGeneratedMime(outputMime);
          setOriginalImageForCompare(sourcePhoto);
          setZoomViewingMode('edited');
          updateStudio(outputImg, outputMime, updated, sourcePhoto);
          setEditPrompt('');
          onShowToast(successToast);
        } else {
          saveStudioSession({
            image: generatedImageRef.current,
            mime: generatedMimeRef.current,
            history: updated.filter((h) => h.status !== 'loading' && Boolean(h.url)),
            originalForCompare: originalImageForCompareRef.current,
          }).catch(() => {});
          onUpdateStudioState?.(
            generatedImageRef.current,
            generatedMimeRef.current,
            updated,
            originalImageForCompareRef.current
          );
          onShowToast(`✓ Edit completed in background! Available in Saved History.`);
        }

        return updated;
      });
    };

    const failEditJob = (errMsg: string) => {
      setHistory((prev) => prev.filter((h) => h.id !== currentJobId));
      if (activeHistoryItemIdRef.current === currentJobId) {
        setActiveHistoryItemId(null);
        setError(errMsg);
      }
      onShowToast('Edit failed: ' + errMsg);
    };

    // BRANCH 1: ByteDance Seedream-v5.0-Pro (via AtlasCloud)
    if (editModel === 'seedream_v5_pro') {
      setSeedreamStatus('submitting');
      setSeedreamSeconds(0);

      if (editTimerRef.current) clearInterval(editTimerRef.current);
      if (editPollRef.current) clearInterval(editPollRef.current);

      editTimerRef.current = setInterval(() => {
        setSeedreamSeconds((prev) => prev + 1);
      }, 1000);

      // Collect all reference images: Position 1 is the primary base, followed by additional reference images (up to 10 total)
      const allImages = [
        sourcePhoto,
        ...referenceImages.map((r) => r.url),
      ].slice(0, 10);

      try {
        const data = await safeFetchJson<{ success: boolean; predictionId?: string; error?: string }>(
          '/api/seedream/edit',
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              prompt: instruction,
              images: allImages,
              baseImage: {
                data: base64Data,
                mimeType: sourceMime,
              },
              size: seedreamSize,
              aspectRatio,
              output_format: seedreamFormat,
              thinking: seedreamThinking,
              prompt_optimization_mode: seedreamMode,
            }),
          }
        );

        if (!data.success || !data.predictionId) {
          throw new Error(data.error || 'Failed to submit edit job to Seedream-v5.0-Pro on AtlasCloud');
        }

        const predictionId = data.predictionId;
        setSeedreamStatus('processing');

        // Poll prediction
        const checkStatus = async () => {
          try {
            const pollData = await safeFetchJson<{
              success: boolean;
              status: string;
              outputUrl?: string;
              outputs?: string[];
              error?: string;
            }>(`/api/seedream/status/${encodeURIComponent(predictionId)}`);

            const status = pollData.status;
            setSeedreamStatus(status || 'processing');

            if (status === 'completed' || status === 'succeeded') {
              if (editPollRef.current) clearInterval(editPollRef.current);
              if (editTimerRef.current) clearInterval(editTimerRef.current);

              const outputImg = pollData.outputUrl || (pollData.outputs && pollData.outputs[0]);
              if (!outputImg) {
                throw new Error('Seedream completed without an output image');
              }

              completeEditJob(
                outputImg,
                seedreamFormat === 'png' ? 'image/png' : 'image/jpeg',
                'seedream',
                '🎨 Keyframe edited with Seedream-v5.0-Pro (AtlasCloud)!'
              );
            } else if (status === 'failed') {
              if (editPollRef.current) clearInterval(editPollRef.current);
              if (editTimerRef.current) clearInterval(editTimerRef.current);
              failEditJob(pollData.error || 'Seedream-v5.0-Pro editing failed on AtlasCloud');
            }
          } catch (pollErr: any) {
            console.error('Polling error:', pollErr);
          }
        };

        editPollRef.current = setInterval(checkStatus, 2500);
        checkStatus();
      } catch (err: any) {
        if (editTimerRef.current) clearInterval(editTimerRef.current);
        if (editPollRef.current) clearInterval(editPollRef.current);
        console.error(err);
        failEditJob(err?.message || 'Failed to submit Seedream-v5.0-Pro edit to AtlasCloud');
      }
      return;
    }

    // BRANCH 2: Nano Banana 2 (gemini-3.1-flash-image)
    try {
      const data = await safeFetchJson<{ success: boolean; imageUrl?: string; mimeType?: string; error?: string }>(
        '/api/generate-image',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: instruction,
            imageSize,
            aspectRatio,
            baseImage: {
              data: base64Data,
              mimeType: sourceMime,
            },
          }),
        }
      );

      if (!data.success || !data.imageUrl) {
        throw new Error(data.error || 'Failed to edit image');
      }

      completeEditJob(
        data.imageUrl,
        data.mimeType || 'image/png',
        'nano',
        '🍌 Keyframe edited with Nano Banana 2 (Gemini Image)!'
      );
    } catch (err: any) {
      console.error(err);
      failEditJob(err?.message || 'Failed to apply image edit');
    }
  };

  // Retry active frame: runs the prompt again for generations, or runs the same edit prompt again on the same original image
  const handleRetry = () => {
    if (activeItem?.status === 'loading') return;

    // Check if the current active frame was an edit
    const isEdit = Boolean(
      activeItem?.isEdit ||
      activeItem?.promptType === 'edit' ||
      activeItem?.originalImageUrl ||
      (originalImageForCompare && editPrompt.trim())
    );

    if (isEdit) {
      const editPromptToUse = (activeItem?.prompt || editPrompt || '').trim();
      if (!editPromptToUse) {
        onShowToast('No edit prompt found to retry.');
        return;
      }
      const originalImageToUse = activeItem?.originalImageUrl || originalImageForCompare;
      if (!originalImageToUse) {
        onShowToast('Original base image not found for retry. Re-running edit on current image.');
        handleRunEdit(editPromptToUse);
        return;
      }
      onShowToast('Retrying edit with the same original base image…');
      handleRunEdit(editPromptToUse, originalImageToUse);
    } else {
      const promptToUse = (activeItem?.prompt || prompt || '').trim();
      if (!promptToUse) {
        onShowToast('No prompt found to retry generation.');
        return;
      }
      onShowToast('Retrying keyframe generation…');
      handleGenerate(promptToUse);
    }
  };

  // Undo edit back to previous image
  const handleUndo = () => {
    if (history.length === 0) return;
    const prev = history[history.length - 1];
    const newHistory = history.slice(0, -1);
    const prevOriginal =
      prev.originalImageUrl || (newHistory.length > 0 ? newHistory[newHistory.length - 1].url : null);
    const origToSet = prev.isEdit ? prevOriginal : null;
    setOriginalImageForCompare(origToSet);
    updateStudio(prev.url, prev.mime, newHistory, origToSet);
    if (prev.prompt) {
      setEditPrompt(prev.prompt);
      setPrompt(prev.prompt);
    }
    setAppliedTo(null);
    onShowToast('Reverted to previous version');
  };

  // Upload intent tracking: 'edit' or 'reverse_prompt'
  const [uploadIntent, setUploadIntent] = useState<'edit' | 'reverse_prompt'>('edit');
  const [isDragOver, setIsDragOver] = useState(false);

  // Trigger file dialog with specific intent
  const handleOpenUpload = (intent: 'edit' | 'reverse_prompt' = 'edit') => {
    setUploadIntent(intent);
    uploadInputRef.current?.click();
  };

  // Trigger Copilot reverse prompt analysis on active or uploaded image
  const triggerCraftReversePrompt = (specificImage?: string) => {
    const target = specificImage || generatedImage;
    if (!target) {
      onShowToast('Please upload or generate an image first!');
      return;
    }
    // Smoothly scroll down to copilot
    copilotRef.current?.scrollIntoView({ behavior: 'smooth' });

    const query =
      'Look at this attached image loaded in the studio. Please inspect its setting, character appearance, hair, body types, and outfits, and write the exact matching Start Frame reverse edit prompt for Nano Banana 2 to show the characters as young adult men before the transformation, keeping identical hair textures, colors, body types, ethnicity, and matching casual clothes!';

    // Reset and trigger copilot
    setCopilotInitialQuery(null);
    setTimeout(() => {
      setCopilotInitialQuery(query);
    }, 50);
  };

  // Core file processor for input change, drag-drop, or Copilot upload
  const processUploadedFile = (file: File, intent: 'edit' | 'reverse_prompt' = uploadIntent) => {
    const allowed = ['image/png', 'image/jpeg', 'image/webp'];
    if (!allowed.includes(file.type)) {
      setError('Only PNG, JPG, or WEBP images can be uploaded.');
      onShowToast('⚠️ Only PNG, JPG, or WEBP images supported');
      return;
    }
    setError(null);

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;

      const uploadedItem: KeyframeHistoryItem = {
        id: `upload-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        url: result,
        mime: file.type,
        label: 'Uploaded Image',
        prompt: prompt.trim() || editPrompt.trim() || 'Uploaded image reference for editing & reverse prompts',
        promptType: 'edit',
        isEdit: true,
        originalImageUrl: result,
        timestamp: Date.now(),
        aspectRatio,
        imageSize,
        modelUsed: 'uploaded-source',
      };

      const newHistory: KeyframeHistoryItem[] = [uploadedItem, ...history.filter((h) => h.url !== result)];

      updateStudio(result, file.type, newHistory, result);
      setIsEditMode(true);
      setEditModel('nano_banana_2');

      if (intent === 'reverse_prompt') {
        onShowToast('✓ Image uploaded! Analyzing for reverse prompt in Copilot...');
        triggerCraftReversePrompt(result);
      } else {
        onShowToast('✓ Image uploaded to Studio. Ready for editing & reverse prompts!');
      }
    };
    reader.readAsDataURL(file);
  };

  // Upload an external image via file picker
  const handleUploadCustomImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processUploadedFile(file, uploadIntent);
    }
    e.target.value = '';
  };

  const createKeyframeObj = (): KeyframeImage => {
    if (!generatedImage) throw new Error('No image available');
    const base64 = generatedImage.includes(',') ? generatedImage.split(',')[1] : generatedImage;
    return {
      data: base64,
      mimeType: generatedMime,
      previewUrl: generatedImage,
      name: `gemini-keyframe-${imageSize.toLowerCase()}`,
    };
  };

  const handleApplyStart = () => {
    try {
      const obj = createKeyframeObj();
      onSelectAsStartFrame(obj);
      setAppliedTo((prev) => (prev === 'end' ? 'both' : 'start'));
      setIsEditMode(true); // Keep active for editing right away
      setEditModel('nano_banana_2');
      onShowToast('Set as Start Frame (A) · Image remains active for editing');
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleApplyEnd = () => {
    try {
      const obj = createKeyframeObj();
      onSelectAsEndFrame(obj);
      setAppliedTo((prev) => (prev === 'start' ? 'both' : 'end'));
      setIsEditMode(true); // Keep active for editing right away
      setEditModel('nano_banana_2');
      onShowToast('Set as End Frame (B) · Image remains active for editing');
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDownload = (customUrl?: string, customName?: string) => {
    const urlToDownload = customUrl || generatedImage;
    if (!urlToDownload) return;

    try {
      const a = document.createElement('a');
      a.href = urlToDownload;
      a.download = customName || `wan3-keyframe-${Date.now()}-${imageSize}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      onShowToast('✓ Keyframe downloaded successfully');
    } catch (err: any) {
      console.error('Download failed', err);
      onShowToast('Failed to download image');
    }
  };

  return {
    onSelectAsStartFrame,
    onSelectAsEndFrame,
    onShowToast,
    activeStudioImage,
    activeStudioMime,
    studioHistory,
    originalForCompareProp,
    onUpdateStudioState,
    prompt,
    setPrompt,
    imageSize,
    setImageSize,
    aspectRatio,
    setAspectRatio,
    isAutoRatio,
    setIsAutoRatio,
    detectedRatio,
    setDetectedRatio,
    detectedDimensions,
    setDetectedDimensions,
    loading,
    setLoading,
    loadingAction,
    setLoadingAction,
    error,
    setError,
    isGenerateCoolingDown,
    setIsGenerateCoolingDown,
    isEditCoolingDown,
    setIsEditCoolingDown,
    activeJobRef,
    generatedImage,
    setGeneratedImage,
    generatedMime,
    setGeneratedMime,
    history,
    setHistory,
    appliedTo,
    setAppliedTo,
    originalImageForCompare,
    setOriginalImageForCompare,
    zoomViewingMode,
    setZoomViewingMode,
    isZoomModalOpen,
    setIsZoomModalOpen,
    zoomScale,
    setZoomScale,
    editPrompt,
    setEditPrompt,
    isEditMode,
    setIsEditMode,
    studioControlsRef,
    copilotRef,
    copilotInitialQuery,
    setCopilotInitialQuery,
    handleApplyInitialPrompt,
    handleApplyEditPrompt,
    editModel,
    setEditModel,
    seedreamFormat,
    setSeedreamFormat,
    seedreamThinking,
    setSeedreamThinking,
    seedreamSafetyChecker,
    setSeedreamSafetyChecker,
    seedreamMode,
    setSeedreamMode,
    seedreamStatus,
    setSeedreamStatus,
    seedreamSeconds,
    setSeedreamSeconds,
    getSeedreamDimensions,
    seedreamSize,
    editPollRef,
    editTimerRef,
    isButtonCooldown,
    setIsButtonCooldown,
    buttonCooldownTimerRef,
    activeHistoryItemId,
    setActiveHistoryItemId,
    activeHistoryItemIdRef,
    generatedImageRef,
    generatedMimeRef,
    originalImageForCompareRef,
    activeItem,
    handleSelectAutoRatio,
    handleSelectSpecificRatio,
    updateStudio,
    handleDeleteHistoryItem,
    handleClearAllHistory,
    handleClearActiveImage,
    handleDeleteActiveFrame,
    isConfirmingReset,
    setIsConfirmingReset,
    resetTimerRef,
    handleResetButtonClick,
    handleResetAll,
    uploadInputRef,
    handleGenerate,
    handleRunEdit,
    handleRetry,
    handleUndo,
    uploadIntent,
    setUploadIntent,
    isDragOver,
    setIsDragOver,
    handleOpenUpload,
    triggerCraftReversePrompt,
    processUploadedFile,
    handleUploadCustomImage,
    referenceImages,
    setReferenceImages,
    refUploadInputRef,
    handleAddReferenceImage,
    handleRemoveReferenceImage,
    handleClearReferenceImages,
    handleImportStartFrameAsReference,
    handleImportEndFrameAsReference,
    handleImportHistoryItemAsReference,
    handleUploadRefFiles,
    startImage,
    endImage,
    handleApplyStart,
    handleApplyEnd,
    handleDownload,
  };
}

export type KeyframeStudio = ReturnType<typeof useKeyframeStudio>;
