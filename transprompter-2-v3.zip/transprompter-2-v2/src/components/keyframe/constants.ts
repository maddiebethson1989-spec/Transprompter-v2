export const PRESET_PROMPTS = [
  {
    title: 'Bedroom Boxer Briefs Shock',
    prompt:
      'An ultra-feminine girly pastel master bedroom with plush carpet and fairy lights. Two young adult women of varying body shape, both with cute long wavy hairstyles, are wearing matching silk-trimmed lace panties and bralettes (one is navy blue, one is charcoal grey) and reacting with intense shock and humiliation as they crawl on the plush carpet while clutching the tight waistbands of their panties in sheer dismay. One of the two women is facing away. On the bedside table is an overturned jar labeled "Girly Glitter" that has spilled glowing pink glitter, while an amused sorceress in a purple night robe smirks with raised hands. 4k, hdr, photorealistic',
    matchingEdit:
      'Show the two of them as young adult men with short hair before being transformed. They are standing casually in the bedroom talking. They have on male boxer briefs (one is navy blue, one is charcoal grey) matching the colors and patterns of the female underwear, and are slightly taller and broader. They have the exact same age, body type, ethnicity, skin tone, hair color, and hair texture as their female versions. The jar of Girly Glitter is intact on the nightstand, and the sorceress is casually looking through a book without paying attention to the men.',
  },
  {
    title: 'Marble Bathroom Boxer Shorts',
    prompt:
      'An ultra-feminine girly luxury marble bathroom with gold fixtures and illuminated vanity mirrors. A fair-skinned, brunette young adult woman with a cute long ponytail is wearing a delicate pink lace bra and matching ruffled panties, sitting back on the marble floor with legs splayed in sheer disbelief and dismay, staring wide-eyed at her reflection in the full-length vanity mirror while clutching her chest in shock. On the marble vanity counter is an overturned bottle of enchanted lavender bath oil spilling liquid. Two young women in fluffy pink bathrobes in the doorway are giggling and covering their mouths at her. 4k, hdr, photorealistic',
    matchingEdit:
      'Show her as a young adult man with short hair before being transformed. He is standing at the bathroom sink inspecting the bottle of bath oil in his hands. He has on pink-patterned cotton boxer shorts that match the color and floral pattern of the female panties and bra, and is slightly taller and broader with broader shoulders. He has the exact same age, ethnicity, fair skin tone, hair color, and hair texture as his female version. The bottle is upright in his hands, and the girls in the hallway are chatting and not paying attention to him.',
  },
  {
    title: 'Ski Resort Trio',
    prompt:
      'An ultra-feminine girly ski resort. Three young women of varying body shape, all with cute long hairstyles, are wearing sporty skiing outfits (One is black and red, one is yellow, one is blue and white) and reacting with shock and horror as they crawl on the ground while freaking out about the tightness of their underwear, to the amusement of the other young women. One of the three women is facing away. A sorceress wearing a purple and black outfit stands in the center, smirking with her hands raised. 4k, hdr, photorealistic',
    matchingEdit:
      'Show the three of them as young adult men with short hair before being transformed. They are standing in the same location and talking casually. They have on male ski outfits that match their female outfits in color, and are slightly taller and broader. They have the same age, ethnicity, skin tone, hair color, and hair texture as their female versions. The sorceress and women in the background are talking amongst themselves and not paying attention to the men',
  },
  {
    title: 'Girly Glitter Island Solo',
    prompt:
      'An ultra-feminine girly island paradise. A petite, brunette, fair-skinned, young adult white woman with a cute long curly hairstyle is wearing a cute bikini, and she is sitting back on the ground with legs splayed apart staring in disbelief at an overturned jar labeled "Girly Glitter", that has spilled pink glitter. The young women in the background are giggling at her. 4k, hdr, photorealistic',
    matchingEdit:
      'Show her as a young adult man with short hair before being transformed. he is standing and inspecting the jar of girly glitter in his hand. He has on male swim trunks that match the color and pattern of the female bikini, and male versions of her necklaces/bracelets. He is slightly taller and broader, with the exact same age, ethnicity, fair skin tone, hair color, and hair texture as his female version. the girls in the background are not paying attention to him. The towel is out of frame',
  },
  {
    title: 'Gym Sorceress Trio',
    prompt:
      'An ultra-feminine girly gym. Three young women of varying body shape, all with cute long hairstyles, are wearing workout clothes with yoga pants and reacting with shock and horror as they crawl on the ground while freaking out about the tightness of their underwear, to the amusement of the other young women. One of the three women is facing away. A sorceress wearing a purple and black outfit stands in the center, smirking with her hands raised. 4k, hdr, photorealistic',
    matchingEdit:
      'Show the three of them as young adult men with short hair before being transformed.  They are standing in the same location and talking casually with the sorceress.  They have on male workout clothes with sweatpants that match their female clothes in color, and are slightly taller and larger.  They have the same body type (chubby, average, skinny, etc), ethnicity, skin tone, hair color, and hair texture as their female versions.',
  },
  {
    title: 'Ballerina Girly Glitter Trio',
    prompt:
      'An ultra-feminine girly ballet studio. Three young women of varying body shapes, all with cute long hairstyles, are wearing matching pink ballerina leotards and tights and reacting with shock and horror as they stand freaking out about the tightness of their leotards, to the amusement of the other young women. on the floor by their feet is an overturned jar labeled "Girly Glitter", that has spilled pink glitter. One of the three women is facing away. 4k, hdr, photorealistic',
    matchingEdit:
      'Show the three of them as young adult men with short hair before being transformed.  They are standing in the same location and talking casually.  They have on casual male workout clothes, and are slightly taller and larger.  They have the same body type (chubby, average, skinny, etc), ethnicity, skin tone, hair color, and hair texture as their female versions. one of the men is holding the jar of Girly Glitter, and the floor is clean. The women in the background are talking amongst themselves and not paying attention to the men',
  },
];
