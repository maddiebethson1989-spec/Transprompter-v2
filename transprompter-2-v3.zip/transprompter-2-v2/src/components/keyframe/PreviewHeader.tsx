import { Loader2, Download, Wand2, Upload, Trash2, RotateCcw } from 'lucide-react';
import type { KeyframeStudio } from './useKeyframeStudio';

interface PreviewHeaderProps {
  studio: KeyframeStudio;
}

export function PreviewHeader({ studio }: PreviewHeaderProps) {
  const {
    loading,
    generatedImage,
    isButtonCooldown,
    activeItem,
    handleClearActiveImage,
    isConfirmingReset,
    handleResetButtonClick,
    handleRetry,
    handleOpenUpload,
    triggerCraftReversePrompt,
    handleDownload,
  } = studio;

  return (
    <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
      <span className="text-sm font-semibold text-neutral-300 flex items-center gap-2">
        <span>Rendered Preview</span>
      </span>
      <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
        <button
          type="button"
          onClick={() => handleOpenUpload('edit')}
          disabled={loading}
          className="text-xs px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/10 flex items-center gap-1.5 transition font-medium"
          title="Upload an image to studio for editing or reverse prompts"
        >
          <Upload className="w-3.5 h-3.5 text-pink-400" />
          <span>Upload</span>
        </button>
        {generatedImage && (
          <>
            <button
              type="button"
              onClick={() => triggerCraftReversePrompt()}
              className="text-xs px-2.5 py-1 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/40 flex items-center gap-1.5 transition font-medium"
              title="Ask Copilot to inspect this active image and craft matching Start Frame reverse edit prompt"
            >
              <Wand2 className="w-3.5 h-3.5 text-purple-300" />
              <span className="hidden sm:inline">Craft Reverse Prompt</span>
              <span className="sm:hidden">Reverse</span>
            </button>
            <button
              type="button"
              onClick={handleClearActiveImage}
              className="text-xs px-2.5 py-1 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-300 hover:text-red-200 border border-red-500/30 flex items-center gap-1.5 transition font-medium"
              title="Clear active image from canvas"
            >
              <Trash2 className="w-3.5 h-3.5 text-red-400" />
              <span>Clear Image</span>
            </button>
            <button
              onClick={() => handleDownload()}
              className="text-xs px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white border border-white/20 flex items-center gap-1.5 transition font-medium"
              title="Download full resolution frame"
            >
              <Download className="w-3.5 h-3.5 text-pink-400" />
              <span>Download</span>
            </button>
            <button
              type="button"
              onClick={handleRetry}
              disabled={isButtonCooldown}
              className="text-xs px-2.5 py-1 rounded-lg bg-pink-500/15 hover:bg-pink-500/25 text-pink-300 hover:text-pink-200 border border-pink-500/30 flex items-center gap-1.5 transition font-medium disabled:opacity-50"
              title="Retry generation or re-run edit on original base image"
            >
              <RotateCcw className="w-3.5 h-3.5 text-pink-400" />
              <span>Retry</span>
            </button>
          </>
        )}
        <button
          type="button"
          onClick={handleResetButtonClick}
          disabled={loading}
          className={`text-xs px-2.5 py-1 rounded-lg border transition flex items-center gap-1.5 font-medium ${
            isConfirmingReset
              ? 'bg-red-500/20 text-red-200 border-red-500/50 hover:bg-red-500/30'
              : 'bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white border-white/10'
          }`}
          title="Reset Text to Image, Edit Image, and Rendered Preview to default settings (preserves generation history)"
        >
          <RotateCcw className={`w-3.5 h-3.5 ${isConfirmingReset ? 'text-red-400' : 'text-neutral-400'}`} />
          <span>{isConfirmingReset ? 'Confirm Reset?' : 'Reset'}</span>
        </button>
      </div>
      {activeItem?.status === 'loading' && (
        <div className="flex items-center gap-2">
          <span className="text-xs px-2.5 py-1 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 flex items-center gap-1.5 font-medium">
            <Loader2 className="w-3 h-3 animate-spin text-pink-400" />
            <span>Rendering…</span>
          </span>
        </div>
      )}
    </div>
  );
}
