import { Sparkles, Wand2, Undo2, RotateCcw } from 'lucide-react';
import type { KeyframeStudio } from './useKeyframeStudio';

interface ModeToggleProps {
  studio: KeyframeStudio;
}

export function ModeToggle({ studio }: ModeToggleProps) {
  const {
    loading,
    generatedImage,
    history,
    isEditMode,
    setIsEditMode,
    setEditModel,
    isConfirmingReset,
    handleResetButtonClick,
    handleUndo,
  } = studio;

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-white/10">
      <div className="flex items-center gap-1 bg-[#0e0e17] p-1 rounded-xl border border-white/10 w-full sm:w-auto">
        <button
          type="button"
          onClick={() => setIsEditMode(false)}
          className={`flex-1 sm:flex-initial px-4 py-1.5 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
            !isEditMode
              ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
              : 'text-neutral-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Text to Image</span>
        </button>
        <button
          type="button"
          onClick={() => {
            setIsEditMode(true);
            setEditModel('nano_banana_2');
          }}
          className={`flex-1 sm:flex-initial px-4 py-1.5 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
            isEditMode
              ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
              : 'text-neutral-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Wand2 className="w-3.5 h-3.5" />
          <span>Edit Existing Image</span>
          {generatedImage && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />}
        </button>
      </div>

      <div className="flex items-center gap-2">
        {history.length > 0 && (
          <button
            onClick={handleUndo}
            disabled={loading}
            className="text-xs text-neutral-400 hover:text-pink-300 flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition disabled:opacity-50"
            title="Undo last edit"
          >
            <Undo2 className="w-3.5 h-3.5" />
            <span>Undo ({history.length})</span>
          </button>
        )}

        <button
          type="button"
          onClick={handleResetButtonClick}
          disabled={loading}
          className={`text-xs flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition font-medium border ${
            isConfirmingReset
              ? 'bg-red-500/20 text-red-200 border-red-500/50 hover:bg-red-500/30'
              : 'text-neutral-400 hover:text-white bg-white/5 hover:bg-white/10 border-white/10 hover:border-white/20'
          }`}
          title="Reset Text-to-Image, Edit Image, and Rendered Preview to default settings (preserves generation history)"
        >
          <RotateCcw className={`w-3.5 h-3.5 ${isConfirmingReset ? 'text-red-400' : 'text-neutral-400'}`} />
          <span>{isConfirmingReset ? 'Confirm Reset?' : 'Reset'}</span>
        </button>
      </div>
    </div>
  );
}
