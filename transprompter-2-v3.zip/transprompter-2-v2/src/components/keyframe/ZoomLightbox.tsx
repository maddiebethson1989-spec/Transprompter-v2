import { Download, X, ZoomIn, ZoomOut, ArrowLeftRight } from 'lucide-react';
import type { KeyframeStudio } from './useKeyframeStudio';

interface ZoomLightboxProps {
  studio: KeyframeStudio;
}

export function ZoomLightbox({ studio }: ZoomLightboxProps) {
  const {
    imageSize,
    aspectRatio,
    generatedImage,
    originalImageForCompare,
    zoomViewingMode,
    setZoomViewingMode,
    setIsZoomModalOpen,
    zoomScale,
    setZoomScale,
    handleDownload,
  } = studio;

  const hasOriginalForCompare = Boolean(originalImageForCompare && originalImageForCompare !== generatedImage);
  const currentZoomImage =
    zoomViewingMode === 'original' && hasOriginalForCompare ? originalImageForCompare : generatedImage;

  return (
    <div
      role="dialog"
      aria-modal="true"
      data-backdrop="true"
      className="fixed inset-0 z-[99999] w-screen h-[100dvh] max-h-[100dvh] bg-black/95 backdrop-blur-md flex flex-col items-center justify-between p-2.5 sm:p-6 select-none overflow-hidden touch-pan-y animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget || (e.target as HTMLElement).getAttribute('data-backdrop') === 'true') {
          setIsZoomModalOpen(false);
        }
      }}
    >
      {/* Dedicated Floating Close Button - Guaranteed accessible on mobile and touch devices with safe-area spacing */}
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setIsZoomModalOpen(false);
        }}
        onTouchEnd={(e) => {
          e.stopPropagation();
          setIsZoomModalOpen(false);
        }}
        className="fixed top-[max(0.75rem,env(safe-area-inset-top))] right-[max(0.75rem,env(safe-area-inset-right))] z-[100000] w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-[#181628]/95 hover:bg-red-500/40 active:bg-red-600/70 text-white border-2 border-white/35 shadow-2xl backdrop-blur-md flex items-center justify-center transition active:scale-95 touch-manipulation cursor-pointer"
        aria-label="Close Zoom Inspector"
        title="Close Inspector (Esc)"
      >
        <X className="w-5 h-5 text-white stroke-[2.5]" />
      </button>

      {/* Top Control Bar */}
      <div className="w-full max-w-6xl flex flex-col gap-2 pb-2.5 sm:pb-3 border-b border-white/10 text-xs">
        {/* Header Title Row */}
        <div className="flex items-center justify-between gap-2 pr-12 sm:pr-0">
          <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
            <span className="font-bold text-white flex items-center gap-1.5 truncate">
              <ZoomIn className="w-4 h-4 text-pink-400 flex-shrink-0" />
              <span className="truncate sm:hidden">Zoom Inspector</span>
              <span className="hidden sm:inline">Rendered Preview Zoom Inspector</span>
            </span>
            <span className="text-[10px] font-mono px-1.5 sm:px-2 py-0.5 rounded bg-pink-500/20 text-pink-300 border border-pink-500/30 flex-shrink-0">
              {imageSize} · {aspectRatio}
            </span>
            {hasOriginalForCompare && (
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full border flex-shrink-0 transition ${
                  zoomViewingMode === 'original'
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    : 'bg-pink-500/20 text-pink-300 border-pink-500/40'
                }`}
              >
                {zoomViewingMode === 'original' ? 'Viewing Original Photo' : 'Viewing Edited Generation'}
              </span>
            )}
          </div>
        </div>

        {/* Controls Row */}
        <div className="flex items-center justify-between gap-2 flex-wrap">
          {/* Zoom In / Out / Presets */}
          <div className="flex items-center bg-[#141220] border border-white/15 rounded-xl p-1 gap-1">
            <button
              type="button"
              onClick={() => setZoomScale((prev) => Math.max(0.25, Number((prev - 0.25).toFixed(2))))}
              className="p-1.5 sm:p-2 rounded-lg text-neutral-300 hover:text-white hover:bg-white/10 active:scale-95 transition touch-manipulation"
              title="Zoom Out (-25%)"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="text-xs font-mono font-bold text-pink-300 px-1.5 sm:px-2 min-w-[3rem] text-center select-none">
              {Math.round(zoomScale * 100)}%
            </span>
            <button
              type="button"
              onClick={() => setZoomScale((prev) => Math.min(4, Number((prev + 0.25).toFixed(2))))}
              className="p-1.5 sm:p-2 rounded-lg text-neutral-300 hover:text-white hover:bg-white/10 active:scale-95 transition touch-manipulation"
              title="Zoom In (+25%)"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setZoomScale(1)}
              className={`text-[10px] sm:text-xs font-semibold px-2 py-1 rounded-lg transition border-l border-white/10 ${
                zoomScale === 1 ? 'bg-pink-500/20 text-pink-300' : 'text-neutral-400 hover:text-white hover:bg-white/10'
              }`}
              title="Reset zoom to 100%"
            >
              100%
            </button>
            <button
              type="button"
              onClick={() => setZoomScale(2)}
              className={`hidden sm:inline-flex text-xs font-semibold px-2 py-1 rounded-lg transition ${
                zoomScale === 2 ? 'bg-pink-500/20 text-pink-300' : 'text-neutral-400 hover:text-white hover:bg-white/10'
              }`}
              title="Zoom to 200%"
            >
              200%
            </button>
            <button
              type="button"
              onClick={() => setZoomScale(3)}
              className={`hidden sm:inline-flex text-xs font-semibold px-2 py-1 rounded-lg transition ${
                zoomScale === 3 ? 'bg-pink-500/20 text-pink-300' : 'text-neutral-400 hover:text-white hover:bg-white/10'
              }`}
              title="Zoom to 300%"
            >
              300%
            </button>
          </div>

          {/* Comparison Button & Actions */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Compare Button: switches between Original Photo and Edited Generation */}
            {hasOriginalForCompare && (
              <button
                type="button"
                onClick={() => setZoomViewingMode((prev) => (prev === 'edited' ? 'original' : 'edited'))}
                className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition active:scale-95 touch-manipulation cursor-pointer border ${
                  zoomViewingMode === 'original'
                    ? 'bg-amber-500/25 text-amber-300 border-amber-500/50 shadow-md shadow-amber-500/20 ring-1 ring-amber-500/30'
                    : 'bg-gradient-to-r from-pink-500/25 to-purple-500/25 text-pink-300 border-pink-500/40 hover:bg-pink-500/35'
                }`}
                title={
                  zoomViewingMode === 'original'
                    ? 'Showing Original Photo. Click to switch back to Edited Keyframe.'
                    : 'Showing Edited Keyframe. Click to switch to Original Photo it was edited from.'
                }
              >
                <ArrowLeftRight className="w-3.5 h-3.5" />
                <span>
                  {zoomViewingMode === 'original' ? 'Switch to Edited (After)' : 'Switch to Original (Before)'}
                </span>
              </button>
            )}

            <button
              type="button"
              onClick={() => handleDownload(currentZoomImage || undefined)}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-white font-medium flex items-center gap-1.5 border border-white/10 transition touch-manipulation cursor-pointer"
              title="Download currently displayed frame"
            >
              <Download className="w-3.5 h-3.5 text-pink-400" />
              <span className="hidden sm:inline">Download</span>
            </button>

            <button
              type="button"
              onClick={() => setIsZoomModalOpen(false)}
              onTouchEnd={(e) => {
                e.stopPropagation();
                setIsZoomModalOpen(false);
              }}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-white/10 hover:bg-red-500/20 active:scale-95 text-neutral-200 hover:text-red-300 border border-white/15 transition flex items-center gap-1.5 font-bold touch-manipulation cursor-pointer"
              title="Close Inspector (Esc)"
            >
              <X className="w-4 h-4" />
              <span>Close</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Zoom Display Container with wheel zoom and scroll pan */}
      <div
        data-backdrop="true"
        className="flex-1 w-full min-h-0 max-w-6xl overflow-auto my-1.5 sm:my-3 relative flex items-center justify-center rounded-2xl bg-black/75 border border-white/10 p-2 sm:p-4 scrollbar-thin cursor-grab active:cursor-grabbing"
        onWheel={(e) => {
          e.preventDefault();
          if (e.deltaY < 0) {
            setZoomScale((prev) => Math.min(4, Number((prev + 0.15).toFixed(2))));
          } else {
            setZoomScale((prev) => Math.max(0.25, Number((prev - 0.15).toFixed(2))));
          }
        }}
      >
        {/* Floating Comparison Segmented Pill (visible on mobile and desktop) */}
        {hasOriginalForCompare && (
          <div className="absolute top-3 left-1/2 -translate-x-1/2 z-30 flex items-center bg-[#131220]/95 backdrop-blur-md p-1 rounded-full border border-white/25 shadow-2xl">
            <button
              type="button"
              onClick={() => setZoomViewingMode('original')}
              className={`px-3 py-1.5 text-xs font-bold rounded-full transition flex items-center gap-1.5 touch-manipulation cursor-pointer ${
                zoomViewingMode === 'original'
                  ? 'bg-amber-500 text-black shadow-md'
                  : 'text-neutral-400 hover:text-white'
              }`}
              title="Switch to original photo before edit"
            >
              <span>Original (Before)</span>
            </button>
            <button
              type="button"
              onClick={() => setZoomViewingMode('edited')}
              className={`px-3 py-1.5 text-xs font-bold rounded-full transition flex items-center gap-1.5 touch-manipulation cursor-pointer ${
                zoomViewingMode === 'edited'
                  ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
                  : 'text-neutral-400 hover:text-white'
              }`}
              title="Switch to edited generation"
            >
              <span>Edited (After)</span>
            </button>
          </div>
        )}

        {/* Current View Badge in Bottom-Left of Zoom Container */}
        {hasOriginalForCompare && (
          <div className="absolute bottom-3 left-3 z-30 pointer-events-none">
            <span
              className={`px-2.5 py-1 rounded-lg text-[10px] sm:text-[11px] font-mono font-bold shadow-lg backdrop-blur-md border ${
                zoomViewingMode === 'original'
                  ? 'bg-amber-950/90 text-amber-300 border-amber-500/50'
                  : 'bg-pink-950/90 text-pink-300 border-pink-500/50'
              }`}
            >
              {zoomViewingMode === 'original' ? '📷 ORIGINAL PHOTO (Before Edit)' : '✨ EDITED GENERATION (After Edit)'}
            </span>
          </div>
        )}

        <div data-backdrop="true" className="flex items-center justify-center min-w-full min-h-full p-2">
          <img
            src={currentZoomImage || ''}
            alt={zoomViewingMode === 'original' ? 'Original Keyframe Photo' : 'Zoomed Keyframe Preview'}
            onClick={(e) => e.stopPropagation()}
            style={{
              transform: `scale(${zoomScale})`,
              transition: 'transform 0.12s ease-out',
              transformOrigin: 'center center',
            }}
            className="max-h-[60vh] sm:max-h-[70vh] max-w-full object-contain select-none shadow-2xl rounded-lg"
            draggable={false}
          />
        </div>
      </div>

      {/* Bottom Bar: Mobile Close Button and Desktop Hints */}
      <div className="flex-shrink-0 w-full max-w-6xl pt-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs z-30">
        {/* Mobile Full-Width Close Button */}
        <button
          type="button"
          onClick={() => setIsZoomModalOpen(false)}
          onTouchEnd={(e) => {
            e.stopPropagation();
            setIsZoomModalOpen(false);
          }}
          className="w-full sm:hidden py-3 px-4 rounded-xl bg-gradient-to-r from-red-600/95 to-pink-600/95 active:scale-[0.98] text-white font-bold flex items-center justify-center gap-2 shadow-xl shadow-red-950/50 transition text-sm touch-manipulation cursor-pointer border border-white/20"
        >
          <X className="w-5 h-5 text-white stroke-[2.5]" />
          <span>Close Zoom Pop-up</span>
        </button>

        {/* Desktop Hints */}
        <div className="hidden sm:flex items-center justify-between w-full text-[11px] text-neutral-400">
          <span className="flex items-center gap-2">
            <span>💡 Scroll mouse wheel to zoom in / out · Drag scrollbars to pan</span>
            {hasOriginalForCompare && (
              <span className="text-pink-300 font-semibold">
                · Press <kbd className="px-1.5 py-0.5 rounded bg-white/10 font-mono text-white text-[10px]">C</kbd> or{' '}
                <kbd className="px-1.5 py-0.5 rounded bg-white/10 font-mono text-white text-[10px]">B</kbd> to toggle
                Original vs Edited
              </span>
            )}
          </span>
          <span className="text-neutral-500">
            Press <kbd className="px-1.5 py-0.5 rounded bg-white/10 font-mono text-white text-[10px]">Esc</kbd> or tap
            outside to exit
          </span>
        </div>
      </div>
    </div>
  );
}
