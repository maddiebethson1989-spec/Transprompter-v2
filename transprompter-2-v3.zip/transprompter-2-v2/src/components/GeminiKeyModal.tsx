import React, { useState, useEffect, useRef } from 'react';
import {
  Key,
  Upload,
  FileText,
  Check,
  AlertCircle,
  Eye,
  EyeOff,
  ClipboardPaste,
  Trash2,
  ExternalLink,
  X,
  Sparkles,
  Loader2,
  ShieldCheck,
  Layers,
  Wand2,
} from 'lucide-react';
import {
  safeFetchJson,
  getStoredGeminiApiKey,
  setStoredGeminiApiKey,
  getStoredAtlasCloudApiKey,
  setStoredAtlasCloudApiKey,
} from '../utils/safeApi';

export interface GeminiKeyStatus {
  configured: boolean;
  isCustom: boolean;
  source: string;
  maskedKey: string | null;
}

export interface AtlasCloudKeyStatus {
  configured: boolean;
  isCustom: boolean;
  source: string;
  maskedKey: string | null;
}

export type ApiKeyTab = 'gemini' | 'atlascloud';

export interface GeminiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: ApiKeyTab;
  onKeyUpdated?: (status: GeminiKeyStatus) => void;
  onAtlasKeyUpdated?: (status: AtlasCloudKeyStatus) => void;
}

export function GeminiKeyModal({
  isOpen,
  onClose,
  initialTab = 'gemini',
  onKeyUpdated,
  onAtlasKeyUpdated,
}: GeminiKeyModalProps) {
  const [activeTab, setActiveTab] = useState<ApiKeyTab>(initialTab);

  // Gemini state
  const [geminiKey, setGeminiKey] = useState('');
  const [showGeminiKey, setShowGeminiKey] = useState(false);
  const [geminiFileName, setGeminiFileName] = useState<string | null>(null);
  const [geminiStatus, setGeminiStatus] = useState<GeminiKeyStatus | null>(null);
  const [isLoadingGeminiStatus, setIsLoadingGeminiStatus] = useState(false);
  const [isSavingGemini, setIsSavingGemini] = useState(false);
  const [isTestingGemini, setIsTestingGemini] = useState(false);
  const [isResettingGemini, setIsResettingGemini] = useState(false);

  // AtlasCloud state
  const [atlasKey, setAtlasKey] = useState('');
  const [showAtlasKey, setShowAtlasKey] = useState(false);
  const [atlasFileName, setAtlasFileName] = useState<string | null>(null);
  const [atlasStatus, setAtlasStatus] = useState<AtlasCloudKeyStatus | null>(null);
  const [isLoadingAtlasStatus, setIsLoadingAtlasStatus] = useState(false);
  const [isSavingAtlas, setIsSavingAtlas] = useState(false);
  const [isTestingAtlas, setIsTestingAtlas] = useState(false);
  const [isResettingAtlas, setIsResettingAtlas] = useState(false);

  // Drag & drop and common UI state
  const [isDragOver, setIsDragOver] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch Gemini status
  const fetchGeminiStatus = async () => {
    setIsLoadingGeminiStatus(true);
    try {
      const data = await safeFetchJson<GeminiKeyStatus>('/api/gemini/status');
      setGeminiStatus(data);
      if (onKeyUpdated) onKeyUpdated(data);
    } catch {
      const stored = getStoredGeminiApiKey();
      if (stored) {
        const fallback: GeminiKeyStatus = {
          configured: true,
          isCustom: true,
          source: 'uploaded',
          maskedKey: stored.length > 8 ? `${stored.slice(0, 6)}••••••••${stored.slice(-4)}` : '••••••••',
        };
        setGeminiStatus(fallback);
        if (onKeyUpdated) onKeyUpdated(fallback);
      }
    } finally {
      setIsLoadingGeminiStatus(false);
    }
  };

  // Fetch AtlasCloud status
  const fetchAtlasStatus = async () => {
    setIsLoadingAtlasStatus(true);
    try {
      const data = await safeFetchJson<AtlasCloudKeyStatus>('/api/atlascloud/status');
      setAtlasStatus(data);
      if (onAtlasKeyUpdated) onAtlasKeyUpdated(data);
    } catch {
      const stored = getStoredAtlasCloudApiKey();
      if (stored) {
        const fallback: AtlasCloudKeyStatus = {
          configured: true,
          isCustom: true,
          source: 'uploaded',
          maskedKey: stored.length > 8 ? `${stored.slice(0, 6)}••••••••${stored.slice(-4)}` : '••••••••',
        };
        setAtlasStatus(fallback);
        if (onAtlasKeyUpdated) onAtlasKeyUpdated(fallback);
      }
    } finally {
      setIsLoadingAtlasStatus(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setFeedback(null);
      setGeminiFileName(null);
      setAtlasFileName(null);
      if (initialTab) {
        setActiveTab(initialTab);
      }

      // Pre-fill Gemini
      const storedGemini = getStoredGeminiApiKey();
      setGeminiKey(storedGemini || '');

      // Pre-fill AtlasCloud
      const storedAtlas = getStoredAtlasCloudApiKey();
      setAtlasKey(storedAtlas || '');

      fetchGeminiStatus();
      fetchAtlasStatus();
    }
  }, [isOpen, initialTab]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Parser for Gemini Keys
  const extractGeminiKeyFromText = (text: string): string => {
    const trimmed = text.trim();

    if (trimmed.startsWith('{')) {
      try {
        const parsed = JSON.parse(trimmed);
        const candidate =
          parsed.GEMINI_API_KEY ||
          parsed.gemini_api_key ||
          parsed.apiKey ||
          parsed.key ||
          parsed.api_key;
        if (candidate && typeof candidate === 'string') {
          return candidate.trim();
        }
      } catch {
        // Continue
      }
    }

    const regexMatch = trimmed.match(/AIzaSy[A-Za-z0-9_-]{33}/);
    if (regexMatch) return regexMatch[0];

    const lines = trimmed.split(/[\r\n]+/);
    for (const line of lines) {
      const lineTrim = line.trim();
      if (lineTrim.startsWith('#')) continue;
      const envMatch = lineTrim.match(/^(?:GEMINI_API_KEY|VITE_GEMINI_API_KEY|API_KEY)\s*=\s*["']?([^"'\s]+)["']?/i);
      if (envMatch && envMatch[1]) return envMatch[1].trim();
    }

    if (lines.length === 1 && !trimmed.includes(' ') && trimmed.startsWith('AIzaSy')) {
      return trimmed.replace(/["';]/g, '');
    }

    return '';
  };

  // Parser for AtlasCloud Keys
  const extractAtlasKeyFromText = (text: string): string => {
    const trimmed = text.trim();

    if (trimmed.startsWith('{')) {
      try {
        const parsed = JSON.parse(trimmed);
        const candidate =
          parsed.ATLASCLOUD_API_KEY ||
          parsed.atlascloud_api_key ||
          parsed.ATLAS_API_KEY ||
          parsed.atlas_api_key ||
          parsed.FAL_KEY ||
          parsed.fal_key ||
          parsed.apiKey ||
          parsed.key;
        if (candidate && typeof candidate === 'string') {
          return candidate.trim();
        }
      } catch {
        // Continue
      }
    }

    const lines = trimmed.split(/[\r\n]+/);
    for (const line of lines) {
      const lineTrim = line.trim();
      if (lineTrim.startsWith('#')) continue;
      const envMatch = lineTrim.match(/^(?:ATLASCLOUD_API_KEY|ATLAS_API_KEY|FAL_KEY|VITE_ATLASCLOUD_API_KEY)\s*=\s*["']?([^"'\s]+)["']?/i);
      if (envMatch && envMatch[1]) return envMatch[1].trim();
    }

    // Single line alphanumeric token (AtlasCloud keys or bearer tokens)
    if (lines.length === 1 && !trimmed.includes(' ') && trimmed.length >= 16) {
      return trimmed.replace(/["';]/g, '');
    }

    return '';
  };

  const handleFileProcess = (file: File) => {
    if (!file) return;
    setFeedback(null);

    const isGemini = activeTab === 'gemini';
    if (isGemini) {
      setGeminiFileName(file.name);
    } else {
      setAtlasFileName(file.name);
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      if (!content) {
        setFeedback({ type: 'error', message: `Could not read contents of ${file.name}` });
        return;
      }

      if (isGemini) {
        const extracted = extractGeminiKeyFromText(content);
        if (extracted) {
          setGeminiKey(extracted);
          setFeedback({
            type: 'success',
            message: `Extracted Gemini API key from "${file.name}"! Click "Save Gemini Key" to activate.`,
          });
        } else {
          setFeedback({
            type: 'error',
            message: `Could not find a valid Gemini API key in "${file.name}". Expected key starting with "AIzaSy..." or GEMINI_API_KEY.`,
          });
        }
      } else {
        const extracted = extractAtlasKeyFromText(content);
        if (extracted) {
          setAtlasKey(extracted);
          setFeedback({
            type: 'success',
            message: `Extracted AtlasCloud API key from "${file.name}"! Click "Save AtlasCloud Key" to activate.`,
          });
        } else {
          setFeedback({
            type: 'error',
            message: `Could not find a valid AtlasCloud key in "${file.name}". Expected ATLASCLOUD_API_KEY or Bearer token.`,
          });
        }
      }
    };
    reader.onerror = () => {
      setFeedback({ type: 'error', message: `Failed to read file ${file.name}` });
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileProcess(e.dataTransfer.files[0]);
    }
  };

  const handlePasteClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (!text || !text.trim()) return;

      if (activeTab === 'gemini') {
        const extracted = extractGeminiKeyFromText(text) || text.trim();
        setGeminiKey(extracted);
        setFeedback({ type: 'info', message: 'Gemini API key pasted from clipboard' });
      } else {
        const extracted = extractAtlasKeyFromText(text) || text.trim();
        setAtlasKey(extracted);
        setFeedback({ type: 'info', message: 'AtlasCloud API key pasted from clipboard' });
      }
    } catch {
      setFeedback({ type: 'error', message: 'Clipboard permission denied. Please paste directly into the input.' });
    }
  };

  // Test Gemini Key Connection
  const handleTestGeminiKey = async () => {
    const cleanKey = geminiKey.trim();
    if (!cleanKey && !geminiStatus?.configured) {
      setFeedback({ type: 'error', message: 'Please enter or upload a Gemini API key first to test' });
      return;
    }

    setIsTestingGemini(true);
    setFeedback(null);

    try {
      const storedKey = getStoredGeminiApiKey();
      const payloadKey = cleanKey || storedKey || undefined;
      const res = await safeFetchJson<{ success: boolean; message: string; error?: string }>('/api/gemini/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey: payloadKey }),
      });

      if (res?.success) {
        setFeedback({
          type: 'success',
          message: cleanKey
            ? '✓ Google Gemini connection test passed! Key is operational with Google AI Studio.'
            : '✓ Active Google Gemini API key verified! Connection is operational with Google AI Studio.',
        });
      } else {
        setFeedback({
          type: 'error',
          message: res?.error || 'Gemini key validation failed.',
        });
      }
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: err?.message || 'Gemini connection test failed. Please verify the key.',
      });
    } finally {
      setIsTestingGemini(false);
    }
  };

  // Test AtlasCloud Key Connection
  const handleTestAtlasKey = async () => {
    const cleanKey = atlasKey.trim();
    if (!cleanKey && !atlasStatus?.configured) {
      setFeedback({ type: 'error', message: 'Please enter or upload an AtlasCloud API key first to test' });
      return;
    }

    setIsTestingAtlas(true);
    setFeedback(null);

    try {
      const storedKey = getStoredAtlasCloudApiKey();
      const payloadKey = cleanKey || storedKey || undefined;
      const res = await safeFetchJson<{ success: boolean; message: string; error?: string }>('/api/atlascloud/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey: payloadKey }),
      });

      if (res?.success) {
        setFeedback({
          type: 'success',
          message: cleanKey
            ? '✓ AtlasCloud connection test passed! Key is authorized for Seedream 5.0 Pro image editing.'
            : '✓ Active AtlasCloud API key verified! Authorized for Seedream 5.0 Pro image editing.',
        });
      } else {
        setFeedback({
          type: 'error',
          message: res?.error || 'AtlasCloud key test failed.',
        });
      }
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: err?.message || 'AtlasCloud connection test failed. Please verify your key from console.atlascloud.ai.',
      });
    } finally {
      setIsTestingAtlas(false);
    }
  };

  // Save Gemini Key
  const handleSaveGeminiKey = async () => {
    const cleanKey = geminiKey.trim();
    if (!cleanKey) {
      setFeedback({ type: 'error', message: 'Please enter or upload a Gemini API key first' });
      return;
    }

    setIsSavingGemini(true);
    setFeedback(null);

    try {
      let maskedKey = cleanKey.length > 8 ? `${cleanKey.slice(0, 6)}••••••••${cleanKey.slice(-4)}` : '••••••••';
      try {
        const res = await safeFetchJson<{ success: boolean; maskedKey: string; isCustom: boolean; message?: string }>(
          '/api/gemini/key',
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ apiKey: cleanKey }),
          }
        );
        if (res?.maskedKey) {
          maskedKey = res.maskedKey;
        }
      } catch (apiErr: any) {
        if (!apiErr?.message?.includes('404')) {
          throw apiErr;
        }
      }

      setStoredGeminiApiKey(cleanKey);

      const newStatus: GeminiKeyStatus = {
        configured: true,
        isCustom: true,
        source: 'uploaded',
        maskedKey,
      };
      setGeminiStatus(newStatus);
      if (onKeyUpdated) onKeyUpdated(newStatus);

      setFeedback({
        type: 'success',
        message: '✓ Gemini API key successfully saved and verified! Enhancer and Nano Banana 2 are ready.',
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: err.message || 'Failed to validate Gemini API key. Please check that the key is valid.',
      });
    } finally {
      setIsSavingGemini(false);
    }
  };

  // Reset Gemini Key
  const handleResetGemini = async () => {
    setIsResettingGemini(true);
    setFeedback(null);

    try {
      const res = await safeFetchJson<{ success: boolean; maskedKey: string | null; configured: boolean }>(
        '/api/gemini/key',
        { method: 'DELETE' }
      );

      setStoredGeminiApiKey('');
      setGeminiKey('');
      setGeminiFileName(null);

      const newStatus: GeminiKeyStatus = {
        configured: res.configured,
        isCustom: false,
        source: res.configured ? 'server_env' : 'none',
        maskedKey: res.maskedKey,
      };
      setGeminiStatus(newStatus);
      if (onKeyUpdated) onKeyUpdated(newStatus);

      setFeedback({
        type: 'info',
        message: res.configured
          ? 'Custom Gemini key removed. Reverted to server environment key.'
          : 'Custom Gemini key removed. No server environment key found.',
      });
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to reset Gemini key' });
    } finally {
      setIsResettingGemini(false);
    }
  };

  // Save AtlasCloud Key
  const handleSaveAtlasKey = async () => {
    const cleanKey = atlasKey.trim();
    if (!cleanKey) {
      setFeedback({ type: 'error', message: 'Please enter or upload an AtlasCloud API key first' });
      return;
    }

    setIsSavingAtlas(true);
    setFeedback(null);

    try {
      let maskedKey = cleanKey.length > 8 ? `${cleanKey.slice(0, 6)}••••••••${cleanKey.slice(-4)}` : '••••••••';
      try {
        const res = await safeFetchJson<{ success: boolean; maskedKey: string; configured: boolean; message?: string }>(
          '/api/atlascloud/key',
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ apiKey: cleanKey }),
          }
        );
        if (res?.maskedKey) {
          maskedKey = res.maskedKey;
        }
      } catch (apiErr: any) {
        if (!apiErr?.message?.includes('404')) {
          throw apiErr;
        }
      }

      setStoredAtlasCloudApiKey(cleanKey);

      const newStatus: AtlasCloudKeyStatus = {
        configured: true,
        isCustom: true,
        source: 'uploaded',
        maskedKey,
      };
      setAtlasStatus(newStatus);
      if (onAtlasKeyUpdated) onAtlasKeyUpdated(newStatus);

      setFeedback({
        type: 'success',
        message: '✓ AtlasCloud API key saved! ByteDance Seedream 5.0 Pro image editing is now active.',
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: err.message || 'Failed to configure AtlasCloud key.',
      });
    } finally {
      setIsSavingAtlas(false);
    }
  };

  // Reset AtlasCloud Key
  const handleResetAtlas = async () => {
    setIsResettingAtlas(true);
    setFeedback(null);

    try {
      const res = await safeFetchJson<{ success: boolean; maskedKey: string | null; configured: boolean }>(
        '/api/atlascloud/key',
        { method: 'DELETE' }
      );

      setStoredAtlasCloudApiKey('');
      setAtlasKey('');
      setAtlasFileName(null);

      const newStatus: AtlasCloudKeyStatus = {
        configured: res.configured,
        isCustom: false,
        source: res.configured ? 'server_env' : 'none',
        maskedKey: res.maskedKey,
      };
      setAtlasStatus(newStatus);
      if (onAtlasKeyUpdated) onAtlasKeyUpdated(newStatus);

      setFeedback({
        type: 'info',
        message: res.configured
          ? 'Custom AtlasCloud key removed. Reverted to server environment key.'
          : 'Custom AtlasCloud key removed. No server environment key found.',
      });
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to reset AtlasCloud key' });
    } finally {
      setIsResettingAtlas(false);
    }
  };

  if (!isOpen) return null;

  const isGeminiConfigured = geminiStatus?.configured || false;
  const isGeminiCustom = geminiStatus?.isCustom || Boolean(getStoredGeminiApiKey());

  const isAtlasConfigured = atlasStatus?.configured || false;
  const isAtlasCustom = atlasStatus?.isCustom || Boolean(getStoredAtlasCloudApiKey());

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-xl bg-[#0e0e16] border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glow accent */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500" />

        {/* Modal Header */}
        <div className="flex items-start justify-between p-5 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500/20 to-purple-600/20 border border-pink-500/30 flex items-center justify-center text-pink-400 flex-shrink-0 shadow-inner">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">API Key Manager</h2>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-pink-500/10 text-pink-300 border border-pink-500/20 font-semibold">
                  Dual Providers
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                Configure your Gemini and AtlasCloud credentials in one unified control panel
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-white/5 transition"
            title="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Provider Switcher Tabs */}
        <div className="px-5 pt-4">
          <div className="flex items-center bg-[#13131f] p-1 rounded-xl border border-white/10 shadow-inner">
            <button
              type="button"
              onClick={() => {
                setActiveTab('gemini');
                setFeedback(null);
              }}
              className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-2 ${
                activeTab === 'gemini'
                  ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md shadow-pink-500/25 font-bold'
                  : 'text-neutral-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Google Gemini</span>
              <span
                className={`w-2 h-2 rounded-full ${
                  isGeminiConfigured ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]' : 'bg-neutral-600'
                }`}
              />
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab('atlascloud');
                setFeedback(null);
              }}
              className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-2 ${
                activeTab === 'atlascloud'
                  ? 'bg-gradient-to-r from-indigo-500 to-pink-500 text-white shadow-md shadow-indigo-500/25 font-bold'
                  : 'text-neutral-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Wand2 className="w-3.5 h-3.5" />
              <span>AtlasCloud (Seedream 5.0)</span>
              <span
                className={`w-2 h-2 rounded-full ${
                  isAtlasConfigured ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]' : 'bg-neutral-600'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4 overflow-y-auto no-scrollbar">
          {/* Feedback alerts */}
          {feedback && (
            <div
              className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 animate-in fade-in duration-150 ${
                feedback.type === 'success'
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  : feedback.type === 'error'
                  ? 'bg-red-500/10 border-red-500/30 text-red-300'
                  : 'bg-blue-500/10 border-blue-500/30 text-blue-300'
              }`}
            >
              {feedback.type === 'success' ? (
                <Check className="w-4 h-4 flex-shrink-0 text-emerald-400 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              )}
              <div className="flex-1 leading-relaxed">{feedback.message}</div>
            </div>
          )}

          {/* TAB 1: GOOGLE GEMINI */}
          {activeTab === 'gemini' && (
            <div className="space-y-4">
              {/* Active Key Status Banner */}
              <div className="bg-[#141420] border border-white/10 rounded-xl p-3.5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-3 h-3 rounded-full flex-shrink-0 ${
                      isGeminiConfigured
                        ? 'bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)]'
                        : 'bg-amber-400 shadow-[0_0_10px_rgba(251,191,36,0.8)]'
                    }`}
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-white">
                        {isGeminiConfigured ? 'Gemini API Connected' : 'No Gemini Key Active'}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-white/10 text-neutral-300 font-mono">
                        {isGeminiCustom ? 'Custom Key' : isGeminiConfigured ? 'Server Default' : 'Unconfigured'}
                      </span>
                    </div>
                    <div className="text-[11px] font-mono text-neutral-400 truncate mt-0.5">
                      {geminiStatus?.maskedKey ? geminiStatus.maskedKey : 'Enter or upload a key below to connect'}
                    </div>
                  </div>
                </div>

                {isGeminiCustom && (
                  <button
                    type="button"
                    onClick={handleResetGemini}
                    disabled={isResettingGemini}
                    className="px-2.5 py-1 text-xs text-neutral-400 hover:text-red-400 hover:bg-red-500/10 border border-white/5 hover:border-red-500/20 rounded-lg transition flex items-center gap-1.5 flex-shrink-0"
                    title="Reset to default server key"
                  >
                    {isResettingGemini ? <Loader2 className="w-3 h-3 animate-spin" /> : <Trash2 className="w-3 h-3" />}
                    <span className="hidden sm:inline">Reset</span>
                  </button>
                )}
              </div>

              {/* Upload File Dropzone */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Upload className="w-3.5 h-3.5 text-pink-400" />
                    Upload Gemini Key File
                  </span>
                  <span className="text-[11px] font-normal text-neutral-500">Supports .env, .txt, .json</span>
                </label>

                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleFileProcess(e.target.files[0]);
                    }
                  }}
                  accept=".env,.txt,.json,text/plain,application/json"
                  className="hidden"
                />

                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDragOver(true);
                  }}
                  onDragLeave={() => setIsDragOver(false)}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`cursor-pointer border-2 border-dashed rounded-xl p-4 text-center transition flex flex-col items-center justify-center gap-2 group ${
                    isDragOver
                      ? 'border-pink-500 bg-pink-500/10 scale-[0.99]'
                      : 'border-white/10 hover:border-pink-500/40 bg-[#12121c]/60 hover:bg-[#141422]'
                  }`}
                >
                  <div className="w-9 h-9 rounded-full bg-white/5 group-hover:bg-pink-500/10 flex items-center justify-center text-neutral-400 group-hover:text-pink-400 transition">
                    {geminiFileName ? <FileText className="w-4 h-4 text-pink-400" /> : <Upload className="w-4 h-4" />}
                  </div>

                  <div>
                    <p className="text-xs font-semibold text-neutral-200 group-hover:text-white transition">
                      {geminiFileName ? (
                        <span className="text-pink-400 font-mono">Loaded: {geminiFileName}</span>
                      ) : (
                        <>
                          Drop your <span className="text-pink-400">.env</span> file here, or{' '}
                          <span className="underline decoration-pink-500 underline-offset-2">browse</span>
                        </>
                      )}
                    </p>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      Automatically detects <code className="text-neutral-400">GEMINI_API_KEY</code> or{' '}
                      <code className="text-neutral-400">AIzaSy...</code>
                    </p>
                  </div>
                </div>
              </div>

              {/* Manual Input Field */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-pink-400" />
                    Gemini API Key
                  </label>
                  <button
                    type="button"
                    onClick={handlePasteClipboard}
                    className="text-[11px] text-neutral-400 hover:text-pink-400 flex items-center gap-1 transition"
                    title="Paste from clipboard"
                  >
                    <ClipboardPaste className="w-3 h-3" />
                    <span>Paste clipboard</span>
                  </button>
                </div>

                <div className="relative flex items-center">
                  <input
                    type={showGeminiKey ? 'text' : 'password'}
                    value={geminiKey}
                    onChange={(e) => setGeminiKey(e.target.value)}
                    placeholder="AIzaSy..."
                    className="w-full bg-[#12121c] border border-white/15 focus:border-pink-500/70 rounded-xl px-3.5 py-2.5 pr-20 text-xs sm:text-sm text-white placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring-pink-500/50 font-mono tracking-wide transition shadow-inner"
                  />

                  <div className="absolute right-2 flex items-center gap-1">
                    {geminiKey && (
                      <button
                        type="button"
                        onClick={() => setGeminiKey('')}
                        className="p-1 text-neutral-400 hover:text-white rounded transition"
                        title="Clear input"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setShowGeminiKey(!showGeminiKey)}
                      className="p-1.5 text-neutral-400 hover:text-white rounded hover:bg-white/5 transition"
                      title={showGeminiKey ? 'Hide key' : 'Show key'}
                    >
                      {showGeminiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Google AI Studio Helper & Dashboard Links */}
              <div className="bg-pink-500/5 border border-pink-500/20 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
                <div className="flex items-center gap-2 text-neutral-300">
                  <Sparkles className="w-4 h-4 text-pink-400 flex-shrink-0" />
                  <span>Google AI Studio · Gemini API & Quotas</span>
                </div>
                <div className="flex items-center gap-3">
                  <a
                    href="https://aistudio.google.com/app/apikey"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-pink-400 hover:text-pink-300 flex items-center gap-1 font-semibold whitespace-nowrap text-xs transition"
                  >
                    Get Key
                    <ExternalLink className="w-3 h-3" />
                  </a>
                  <span className="text-neutral-600">·</span>
                  <a
                    href="https://aistudio.google.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-neutral-400 hover:text-white flex items-center gap-1 font-medium whitespace-nowrap text-xs transition"
                  >
                    Console & Quota
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ATLASCLOUD (SEEDREAM 5.0 PRO) */}
          {activeTab === 'atlascloud' && (
            <div className="space-y-4">
              {/* Active Key Status Banner */}
              <div className="bg-[#141420] border border-white/10 rounded-xl p-3.5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-3 h-3 rounded-full flex-shrink-0 ${
                      isAtlasConfigured
                        ? 'bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)]'
                        : 'bg-amber-400 shadow-[0_0_10px_rgba(251,191,36,0.8)]'
                    }`}
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-white">
                        {isAtlasConfigured ? 'AtlasCloud Connected' : 'No AtlasCloud Key Active'}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-white/10 text-neutral-300 font-mono">
                        {isAtlasCustom ? 'Custom Key' : isAtlasConfigured ? 'Server Default' : 'Unconfigured'}
                      </span>
                    </div>
                    <div className="text-[11px] font-mono text-neutral-400 truncate mt-0.5">
                      {atlasStatus?.maskedKey ? atlasStatus.maskedKey : 'Enter or upload your AtlasCloud API key below'}
                    </div>
                  </div>
                </div>

                {isAtlasCustom && (
                  <button
                    type="button"
                    onClick={handleResetAtlas}
                    disabled={isResettingAtlas}
                    className="px-2.5 py-1 text-xs text-neutral-400 hover:text-red-400 hover:bg-red-500/10 border border-white/5 hover:border-red-500/20 rounded-lg transition flex items-center gap-1.5 flex-shrink-0"
                    title="Reset to default server key"
                  >
                    {isResettingAtlas ? <Loader2 className="w-3 h-3 animate-spin" /> : <Trash2 className="w-3 h-3" />}
                    <span className="hidden sm:inline">Reset</span>
                  </button>
                )}
              </div>

              {/* Seedream Model Badge / Specs Info */}
              <div className="bg-gradient-to-r from-indigo-500/10 to-pink-500/10 border border-indigo-500/20 rounded-xl p-3 text-xs flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <Layers className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-neutral-200">
                      ByteDance Seedream 5.0 Pro Edit
                    </div>
                    <div className="text-[11px] text-neutral-400 mt-0.5">
                      Flagship model preserving character identity, lighting, & 2K resolution
                    </div>
                  </div>
                </div>
                <span className="text-[10px] font-mono bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded border border-indigo-500/30 whitespace-nowrap">
                  v5.0-pro
                </span>
              </div>

              {/* Upload File Dropzone */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Upload className="w-3.5 h-3.5 text-indigo-400" />
                    Upload AtlasCloud Key File
                  </span>
                  <span className="text-[11px] font-normal text-neutral-500">Supports .env, .txt, .json</span>
                </label>

                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleFileProcess(e.target.files[0]);
                    }
                  }}
                  accept=".env,.txt,.json,text/plain,application/json"
                  className="hidden"
                />

                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDragOver(true);
                  }}
                  onDragLeave={() => setIsDragOver(false)}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`cursor-pointer border-2 border-dashed rounded-xl p-4 text-center transition flex flex-col items-center justify-center gap-2 group ${
                    isDragOver
                      ? 'border-indigo-500 bg-indigo-500/10 scale-[0.99]'
                      : 'border-white/10 hover:border-indigo-500/40 bg-[#12121c]/60 hover:bg-[#141422]'
                  }`}
                >
                  <div className="w-9 h-9 rounded-full bg-white/5 group-hover:bg-indigo-500/10 flex items-center justify-center text-neutral-400 group-hover:text-indigo-400 transition">
                    {atlasFileName ? <FileText className="w-4 h-4 text-indigo-400" /> : <Upload className="w-4 h-4" />}
                  </div>

                  <div>
                    <p className="text-xs font-semibold text-neutral-200 group-hover:text-white transition">
                      {atlasFileName ? (
                        <span className="text-indigo-400 font-mono">Loaded: {atlasFileName}</span>
                      ) : (
                        <>
                          Drop your <span className="text-indigo-400">.env</span> file here, or{' '}
                          <span className="underline decoration-indigo-500 underline-offset-2">browse</span>
                        </>
                      )}
                    </p>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      Automatically detects <code className="text-neutral-400">ATLASCLOUD_API_KEY</code>
                    </p>
                  </div>
                </div>
              </div>

              {/* Manual Input Field */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-indigo-400" />
                    AtlasCloud API Key
                  </label>
                  <button
                    type="button"
                    onClick={handlePasteClipboard}
                    className="text-[11px] text-neutral-400 hover:text-indigo-400 flex items-center gap-1 transition"
                    title="Paste from clipboard"
                  >
                    <ClipboardPaste className="w-3 h-3" />
                    <span>Paste clipboard</span>
                  </button>
                </div>

                <div className="relative flex items-center">
                  <input
                    type={showAtlasKey ? 'text' : 'password'}
                    value={atlasKey}
                    onChange={(e) => setAtlasKey(e.target.value)}
                    placeholder="Enter AtlasCloud API key or Bearer token..."
                    className="w-full bg-[#12121c] border border-white/15 focus:border-indigo-500/70 rounded-xl px-3.5 py-2.5 pr-20 text-xs sm:text-sm text-white placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 font-mono tracking-wide transition shadow-inner"
                  />

                  <div className="absolute right-2 flex items-center gap-1">
                    {atlasKey && (
                      <button
                        type="button"
                        onClick={() => setAtlasKey('')}
                        className="p-1 text-neutral-400 hover:text-white rounded transition"
                        title="Clear input"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setShowAtlasKey(!showAtlasKey)}
                      className="p-1.5 text-neutral-400 hover:text-white rounded hover:bg-white/5 transition"
                      title={showAtlasKey ? 'Hide key' : 'Show key'}
                    >
                      {showAtlasKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>

              {/* AtlasCloud Console Helper & Links */}
              <div className="bg-indigo-500/5 border border-indigo-500/20 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
                <div className="flex items-center gap-2 text-neutral-300">
                  <Sparkles className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                  <span>AtlasCloud Console · ByteDance Seedream 5.0</span>
                </div>
                <div className="flex items-center gap-3">
                  <a
                    href="https://console.atlascloud.ai/api-keys"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-semibold whitespace-nowrap text-xs transition"
                  >
                    Get API Key
                    <ExternalLink className="w-3 h-3" />
                  </a>
                  <span className="text-neutral-600">·</span>
                  <a
                    href="https://console.atlascloud.ai"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-neutral-400 hover:text-white flex items-center gap-1 font-medium whitespace-nowrap text-xs transition"
                  >
                    Console & Credits
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 border-t border-white/10 bg-[#0a0a10] flex items-center justify-between gap-2.5">
          <div className="text-[11px] text-neutral-500 font-mono hidden sm:block">
            {activeTab === 'gemini' ? 'Google AI Studio · gemini-3.1' : 'AtlasCloud · seedream-v5.0-pro'}
          </div>

          <div className="flex items-center gap-2.5 ml-auto flex-wrap justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-neutral-300 hover:text-white hover:bg-white/5 rounded-xl border border-white/10 transition"
            >
              Close
            </button>

            {activeTab === 'gemini' ? (
              <>
                <button
                  type="button"
                  onClick={handleTestGeminiKey}
                  disabled={isTestingGemini || isSavingGemini || (!geminiKey.trim() && !geminiStatus?.configured)}
                  className="px-3.5 py-2 text-xs font-semibold text-pink-300 hover:text-white bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/30 rounded-xl transition flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                  title={
                    geminiKey.trim()
                      ? 'Test entered Gemini API key'
                      : geminiStatus?.configured
                      ? 'Test currently active Gemini API key'
                      : 'Enter or upload a Gemini API key to test'
                  }
                >
                  {isTestingGemini ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-pink-400" />
                  ) : (
                    <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                  )}
                  <span>{geminiKey.trim() ? 'Test Connection' : 'Test Active Key'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveGeminiKey}
                  disabled={isSavingGemini || isTestingGemini || !geminiKey.trim()}
                  className="px-4 py-2 text-xs font-bold text-white bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-lg shadow-pink-500/25 transition flex items-center gap-2 cursor-pointer"
                >
                  {isSavingGemini ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Saving…</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>Save Gemini Key</span>
                    </>
                  )}
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={handleTestAtlasKey}
                  disabled={isTestingAtlas || isSavingAtlas || (!atlasKey.trim() && !atlasStatus?.configured)}
                  className="px-3.5 py-2 text-xs font-semibold text-indigo-300 hover:text-white bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 rounded-xl transition flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                  title={
                    atlasKey.trim()
                      ? 'Test entered AtlasCloud API key'
                      : atlasStatus?.configured
                      ? 'Test currently active AtlasCloud API key'
                      : 'Enter or upload an AtlasCloud API key to test'
                  }
                >
                  {isTestingAtlas ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-400" />
                  ) : (
                    <Wand2 className="w-3.5 h-3.5 text-indigo-400" />
                  )}
                  <span>{atlasKey.trim() ? 'Test Connection' : 'Test Active Key'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveAtlasKey}
                  disabled={isSavingAtlas || isTestingAtlas || !atlasKey.trim()}
                  className="px-4 py-2 text-xs font-bold text-white bg-gradient-to-r from-indigo-500 to-pink-500 hover:from-indigo-400 hover:to-pink-400 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-lg shadow-indigo-500/25 transition flex items-center gap-2 cursor-pointer"
                >
                  {isSavingAtlas ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Saving…</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>Save AtlasCloud Key</span>
                    </>
                  )}
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export { GeminiKeyModal as ApiKeyModal };
