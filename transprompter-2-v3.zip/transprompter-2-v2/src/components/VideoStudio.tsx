import React, { useState, useEffect, useRef } from 'react';
import {
  Film,
  Video,
  Play,
  RotateCcw,
  Sparkles,
  Download,
  Copy,
  Check,
  Trash2,
  Upload,
  ArrowRightLeft,
  Settings,
  Volume2,
  VolumeX,
  Sliders,
  Clock,
  Maximize2,
  ExternalLink,
  Loader2,
  AlertCircle,
  Eye,
  Key,
  Layers,
  ChevronDown,
} from 'lucide-react';
import type {
  KeyframeImage,
  VideoResolution,
  VideoHistoryItem,
} from '../types';
import { safeFetchJson, getStoredAtlasCloudApiKey } from '../utils/safeApi';
import { saveVideoHistory, loadVideoHistory } from '../utils/persistentStorage';

interface VideoStudioProps {
  initialPrompt?: string;
  initialStartFrame?: KeyframeImage | null;
  initialEndFrame?: KeyframeImage | null;
  enhancerStartFrame?: KeyframeImage | null;
  enhancerEndFrame?: KeyframeImage | null;
  studioImage?: string | null;
  studioMime?: string;
  videoHistory?: VideoHistoryItem[];
  onUpdateVideoHistory?: (
    updater: VideoHistoryItem[] | ((prev: VideoHistoryItem[]) => VideoHistoryItem[])
  ) => void;
  onShowToast: (msg: string) => void;
  onOpenKeyModal?: () => void;
}

const RESOLUTION_OPTIONS: { id: VideoResolution; label: string; badge?: string }[] = [
  { id: '1080p', label: '1080p (Default)', badge: 'FHD' },
  { id: '720p', label: '720p', badge: 'HD' },
  { id: '480p', label: '480p (Fast)', badge: 'SD' },
  { id: '720p-esr', label: '720p ESR', badge: 'Enhanced' },
  { id: '1080p-esr', label: '1080p ESR', badge: 'Super-Res' },
  { id: '1440p-esr', label: '1440p ESR', badge: '2K ESR' },
  { id: '4k-esr', label: '4K ESR', badge: 'UHD' },
];


export const VideoStudio: React.FC<VideoStudioProps> = ({
  initialPrompt = '',
  initialStartFrame = null,
  initialEndFrame = null,
  enhancerStartFrame = null,
  enhancerEndFrame = null,
  studioImage = null,
  studioMime = 'image/png',
  videoHistory,
  onUpdateVideoHistory,
  onShowToast,
  onOpenKeyModal,
}) => {
  // Input Keyframes
  const [startFrame, setStartFrame] = useState<KeyframeImage | null>(initialStartFrame);
  const [endFrame, setEndFrame] = useState<KeyframeImage | null>(initialEndFrame);

  // Sync when props change (e.g. sent from I2V Enhancer)
  useEffect(() => {
    if (initialPrompt) {
      setPrompt(initialPrompt);
    }
  }, [initialPrompt]);

  useEffect(() => {
    if (initialStartFrame) {
      setStartFrame(initialStartFrame);
    }
  }, [initialStartFrame]);

  useEffect(() => {
    if (initialEndFrame) {
      setEndFrame(initialEndFrame);
    }
  }, [initialEndFrame]);

  // Motion Prompt
  const [prompt, setPrompt] = useState<string>(initialPrompt);

  // Settings
  const [resolution, setResolution] = useState<VideoResolution>('1080p');
  const [duration, setDuration] = useState<number>(5);
  const [isSmartDuration, setIsSmartDuration] = useState<boolean>(false);
  const [includeAudio, setIncludeAudio] = useState<boolean>(true);
  const [seed, setSeed] = useState<number>(-1);

  // Generation & Polling State
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [predictionId, setPredictionId] = useState<string | null>(null);
  const [pollStatus, setPollStatus] = useState<string>('idle');
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [activeVideoUrl, setActiveVideoUrl] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Video History Management (lifted to App.tsx when provided, with local fallback)
  const [internalHistory, setInternalHistory] = useState<VideoHistoryItem[]>([]);
  const history = videoHistory !== undefined ? videoHistory : internalHistory;

  const updateHistory = (
    updater: VideoHistoryItem[] | ((prev: VideoHistoryItem[]) => VideoHistoryItem[])
  ) => {
    if (onUpdateVideoHistory) {
      onUpdateVideoHistory(updater);
    } else {
      setInternalHistory((prev) => {
        const next = typeof updater === 'function' ? updater(prev) : updater;
        saveVideoHistory(next).catch(() => {});
        return next;
      });
    }
  };

  const [checkingItemId, setCheckingItemId] = useState<string | null>(null);
  const [copiedUrl, setCopiedUrl] = useState<boolean>(false);

  // Polling ref to safely cancel
  const pollingRef = useRef<NodeJS.Timeout | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const fileInputRefA = useRef<HTMLInputElement>(null);
  const fileInputRefB = useRef<HTMLInputElement>(null);
  const videoPlayerRef = useRef<HTMLVideoElement>(null);

  // Restore history on initial mount if not supplied by parent
  useEffect(() => {
    if (videoHistory === undefined) {
      loadVideoHistory()
        .then((items) => {
          if (Array.isArray(items)) {
            setInternalHistory(items);
          }
        })
        .catch((e) => console.warn('Failed to load video history:', e));
    }
  }, [videoHistory]);

  // Background check for pending 'generating' items on mount
  useEffect(() => {
    const pendingItems = history.filter((h) => h.status === 'generating' && h.predictionId);
    if (pendingItems.length === 0) return;

    let isMounted = true;
    pendingItems.forEach(async (item) => {
      try {
        const pollData = await safeFetchJson<{
          success: boolean;
          status: string;
          outputUrl?: string | null;
          outputs?: string[];
          error?: string;
        }>(`/api/video/status/${encodeURIComponent(item.predictionId!)}`);

        if (!isMounted) return;
        const status = (pollData.status || '').toLowerCase();
        if (status === 'completed' || status === 'succeeded') {
          const videoUrl =
            pollData.outputUrl ||
            (pollData.outputs && typeof pollData.outputs[0] === 'string'
              ? pollData.outputs[0]
              : (pollData.outputs?.[0] as any)?.url);
          if (videoUrl) {
            updateHistory((prev) =>
              prev.map((h) =>
                h.id === item.id ? { ...h, status: 'completed', videoUrl, error: undefined } : h
              )
            );
          }
        } else if (status === 'failed') {
          updateHistory((prev) =>
            prev.map((h) =>
              h.id === item.id ? { ...h, status: 'failed', error: pollData.error || 'Generation failed' } : h
            )
          );
        }
      } catch {
        // Silently ignore background poll errors
      }
    });

    return () => {
      isMounted = false;
    };
  }, []);

  // Cleanup timers on unmount
  useEffect(() => {
    return () => {
      if (pollingRef.current) clearInterval(pollingRef.current);
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // Handle Image Upload
  const handleUploadFile = (file: File, which: 'start' | 'end') => {
    const allowed = ['image/png', 'image/jpeg', 'image/webp'];
    if (!allowed.includes(file.type)) {
      onShowToast('Only PNG, JPG, or WEBP images are supported');
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      onShowToast('Image must be under 20MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const resultStr = reader.result as string;
      const base64 = resultStr.split(',')[1];
      const keyframe: KeyframeImage = {
        data: base64,
        mimeType: file.type,
        previewUrl: URL.createObjectURL(file),
        name: file.name,
      };
      if (which === 'start') {
        setStartFrame(keyframe);
        onShowToast('Start Frame (A) loaded');
      } else {
        setEndFrame(keyframe);
        onShowToast('End Frame (B) loaded');
      }
    };
    reader.readAsDataURL(file);
  };

  // Swap Keyframes
  const handleSwapFrames = () => {
    if (!startFrame && !endFrame) {
      onShowToast('No keyframes to swap');
      return;
    }
    const temp = startFrame;
    setStartFrame(endFrame);
    setEndFrame(temp);
    onShowToast('⇄ Swapped Start (A) & End (B) Frames');
  };

  // Sync Frames from Enhancer
  const handleSyncFromEnhancer = () => {
    if (!enhancerStartFrame && !enhancerEndFrame) {
      onShowToast('No keyframes active in I2V Enhancer');
      return;
    }
    if (enhancerStartFrame) setStartFrame(enhancerStartFrame);
    if (enhancerEndFrame) setEndFrame(enhancerEndFrame);
    onShowToast('✓ Synced keyframes from I2V Enhancer');
  };

  // Import active image from Keyframe Studio
  const handleImportFromStudio = (which: 'start' | 'end') => {
    if (!studioImage) {
      onShowToast('No active image in Keyframe Studio');
      return;
    }
    const base64 = studioImage.includes(',') ? studioImage.split(',')[1] : studioImage;
    const keyframe: KeyframeImage = {
      data: base64,
      mimeType: studioMime || 'image/png',
      previewUrl: studioImage.startsWith('data:') ? studioImage : `data:${studioMime};base64,${base64}`,
      name: `studio-frame-${Date.now()}.png`,
    };
    if (which === 'start') {
      setStartFrame(keyframe);
      onShowToast('Loaded into Start Frame (A)');
    } else {
      setEndFrame(keyframe);
      onShowToast('Loaded into End Frame (B)');
    }
  };

  // Start Generation
  const handleGenerate = async () => {
    if (!startFrame) {
      setErrorMessage('Start Frame (Image A) is required to generate video with WAN 3.0.');
      onShowToast('⚠️ Start Frame (Image A) required');
      return;
    }

    if (!prompt.trim()) {
      setErrorMessage('Please enter a video prompt describing the motion and transformation.');
      onShowToast('⚠️ Motion prompt required');
      return;
    }

    setErrorMessage(null);
    setIsGenerating(true);
    setPollStatus('Submitting to AtlasCloud…');
    setElapsedSeconds(0);
    setActiveVideoUrl(null);

    // Start elapsed counter
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setElapsedSeconds((s) => s + 1);
    }, 1000);

    const effectiveDuration = isSmartDuration ? -1 : duration;
    let currentHistoryId: string | null = null;
    let pId: string | null = null;

    try {
      // 1. Build payload
      const payload: Record<string, any> = {
        model: 'alibaba/wan-3.0/image-to-video',
        prompt: prompt.trim(),
        image: {
          data: startFrame.data,
          mimeType: startFrame.mimeType,
        },
        resolution,
        duration: effectiveDuration,
        audio: includeAudio,
        seed: seed === -1 ? -1 : Math.round(seed),
      };

      if (endFrame) {
        payload.last_image = {
          data: endFrame.data,
          mimeType: endFrame.mimeType,
        };
      }

      // 2. Submit video generation job
      const submitData = await safeFetchJson<{
        success: boolean;
        id?: string;
        predictionId?: string;
        error?: string;
      }>('/api/video/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!submitData.success || (!submitData.id && !submitData.predictionId)) {
        throw new Error(submitData.error || 'Failed to submit video generation request to AtlasCloud');
      }

      pId = submitData.id || submitData.predictionId!;
      setPredictionId(pId);
      setPollStatus('Processing on GPU cluster (interpolating frames & synthesizing audio)…');
      onShowToast(`🚀 Video job queued (ID: ${pId.slice(0, 8)}…)`);

      // 3. IMMEDIATELY create and persist history entry with 'generating' status
      currentHistoryId = `vid-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const pendingItem: VideoHistoryItem = {
        id: currentHistoryId,
        timestamp: Date.now(),
        prompt: prompt.trim(),
        startFrame: startFrame ? { ...startFrame } : null,
        endFrame: endFrame ? { ...endFrame } : null,
        resolution,
        duration: effectiveDuration,
        audio: includeAudio,
        seed: seed === -1 ? -1 : seed,
        predictionId: pId,
        status: 'generating',
      };

      updateHistory((prev) => [pendingItem, ...prev.filter((i) => i.id !== currentHistoryId)].slice(0, 50));

      // 4. Poll for results
      let pollAttempts = 0;
      const maxAttempts = 180; // 180 * 3s = 9 minutes max

      if (pollingRef.current) clearInterval(pollingRef.current);
      pollingRef.current = setInterval(async () => {
        pollAttempts++;
        if (pollAttempts > maxAttempts) {
          if (pollingRef.current) clearInterval(pollingRef.current);
          if (timerRef.current) clearInterval(timerRef.current);
          setIsGenerating(false);
          setErrorMessage('Video generation timed out after 9 minutes.');
          if (currentHistoryId) {
            updateHistory((prev) =>
              prev.map((i) =>
                i.id === currentHistoryId || (pId && i.predictionId === pId)
                  ? { ...i, status: 'failed', error: 'Timed out after 9 minutes' }
                  : i
              )
            );
          }
          return;
        }

        try {
          const pollData = await safeFetchJson<{
            success: boolean;
            status: string;
            outputUrl?: string | null;
            outputs?: string[];
            error?: string;
          }>(`/api/video/status/${encodeURIComponent(pId!)}`);

          const status = (pollData.status || '').toLowerCase();

          if (status === 'completed' || status === 'succeeded') {
            if (pollingRef.current) clearInterval(pollingRef.current);
            if (timerRef.current) clearInterval(timerRef.current);

            const videoUrl =
              pollData.outputUrl ||
              (pollData.outputs && typeof pollData.outputs[0] === 'string'
                ? pollData.outputs[0]
                : (pollData.outputs?.[0] as any)?.url);

            if (!videoUrl) {
              throw new Error('AtlasCloud indicated completion but returned no video output URL');
            }

            setActiveVideoUrl(videoUrl);
            setPollStatus('Completed!');
            setIsGenerating(false);
            onShowToast('🎉 WAN 3.0 Video rendered successfully!');

            // Update item in persistent history to 'completed'
            updateHistory((prev) =>
              prev.map((i) =>
                i.id === currentHistoryId || (pId && i.predictionId === pId)
                  ? { ...i, status: 'completed', videoUrl, error: undefined }
                  : i
              )
            );

            // Smooth scroll down to player
            setTimeout(() => {
              document.getElementById('video-player-container')?.scrollIntoView({ behavior: 'smooth' });
            }, 100);
          } else if (status === 'failed') {
            if (pollingRef.current) clearInterval(pollingRef.current);
            if (timerRef.current) clearInterval(timerRef.current);
            setIsGenerating(false);
            const err = pollData.error || 'Video generation failed on AtlasCloud cluster.';
            setErrorMessage(err);
            onShowToast(`Generation error: ${err}`);

            // Mark item as failed in persistent history
            updateHistory((prev) =>
              prev.map((i) =>
                i.id === currentHistoryId || (pId && i.predictionId === pId)
                  ? { ...i, status: 'failed', error: err }
                  : i
              )
            );
          } else {
            setPollStatus(
              status === 'in_queue'
                ? 'In GPU Queue…'
                : `Rendering WAN 3.0 clip (${status})…`
            );
          }
        } catch (pollErr: any) {
          console.warn('Polling error attempt:', pollErr);
        }
      }, 3000);
    } catch (err: any) {
      console.error('Error starting video generation:', err);
      if (timerRef.current) clearInterval(timerRef.current);
      if (pollingRef.current) clearInterval(pollingRef.current);
      setIsGenerating(false);
      setErrorMessage(err.message || 'Failed to submit video generation request');
      onShowToast(`Error: ${err.message || 'Generation failed'}`);
      if (currentHistoryId) {
        updateHistory((prev) =>
          prev.map((i) =>
            i.id === currentHistoryId
              ? { ...i, status: 'failed', error: err.message || 'Generation failed' }
              : i
          )
        );
      }
    }
  };

  const handleCancelGeneration = () => {
    if (pollingRef.current) clearInterval(pollingRef.current);
    if (timerRef.current) clearInterval(timerRef.current);
    setIsGenerating(false);
    setPollStatus('Generation stopped');
    if (predictionId) {
      updateHistory((prev) =>
        prev.map((i) =>
          i.predictionId === predictionId && i.status === 'generating'
            ? { ...i, status: 'failed', error: 'Stopped by user' }
            : i
        )
      );
    }
    onShowToast('Stopped waiting for video');
  };

  const handleCheckItemStatus = async (item: VideoHistoryItem) => {
    if (!item.predictionId) {
      onShowToast('No prediction ID associated with this item');
      return;
    }

    setCheckingItemId(item.id);
    try {
      const pollData = await safeFetchJson<{
        success: boolean;
        status: string;
        outputUrl?: string | null;
        outputs?: string[];
        error?: string;
      }>(`/api/video/status/${encodeURIComponent(item.predictionId)}`);

      const status = (pollData.status || '').toLowerCase();
      if (status === 'completed' || status === 'succeeded') {
        const videoUrl =
          pollData.outputUrl ||
          (pollData.outputs && typeof pollData.outputs[0] === 'string'
            ? pollData.outputs[0]
            : (pollData.outputs?.[0] as any)?.url);

        if (videoUrl) {
          updateHistory((prev) =>
            prev.map((h) =>
              h.id === item.id ? { ...h, status: 'completed', videoUrl, error: undefined } : h
            )
          );
          setActiveVideoUrl(videoUrl);
          onShowToast('🎉 Video render completed!');
        } else {
          onShowToast('Video completed on cluster; output URL retrieved');
        }
      } else if (status === 'failed') {
        const err = pollData.error || 'Video generation failed';
        updateHistory((prev) =>
          prev.map((h) => (h.id === item.id ? { ...h, status: 'failed', error: err } : h))
        );
        onShowToast(`Job failed: ${err}`);
      } else {
        onShowToast(`Status: ${status || 'Processing on GPU cluster'}`);
      }
    } catch (e: any) {
      onShowToast(`Error checking status: ${e.message || 'Network error'}`);
    } finally {
      setCheckingItemId(null);
    }
  };

  const handleDownloadVideo = (url: string) => {
    try {
      const a = document.createElement('a');
      a.href = url;
      a.download = `wan3-video-${Date.now()}.mp4`;
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      onShowToast('✓ Video download initiated');
    } catch {
      window.open(url, '_blank');
    }
  };

  const handleCopyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedUrl(true);
    onShowToast('Video URL copied to clipboard');
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleRestoreFromHistory = (item: VideoHistoryItem) => {
    setPrompt(item.prompt);
    if (item.startFrame) setStartFrame(item.startFrame);
    if (item.endFrame) setEndFrame(item.endFrame);
    if (item.resolution) setResolution(item.resolution);
    if (item.duration) {
      if (item.duration === -1) {
        setIsSmartDuration(true);
      } else {
        setIsSmartDuration(false);
        setDuration(item.duration);
      }
    }
    if (typeof item.audio === 'boolean') setIncludeAudio(item.audio);
    if (typeof item.seed === 'number') setSeed(item.seed);
    if (item.videoUrl) setActiveVideoUrl(item.videoUrl);
    onShowToast('✓ Loaded video settings and preview from history');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteHistory = (id: string) => {
    updateHistory((prev) => prev.filter((i) => i.id !== id));
    onShowToast('Removed from history');
  };

  const handleClearHistory = () => {
    if (window.confirm('Clear all video generation history?')) {
      updateHistory([]);
      onShowToast('Video history cleared');
    }
  };

  return (
    <div className="flex flex-col gap-7 max-w-7xl mx-auto">
      {/* Studio Header Card */}
      <div className="trans-card p-6 border-purple-500/30 bg-gradient-to-r from-[#121124] via-[#0e0e18] to-[#141026] shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-pink-500/20 to-purple-600/30 border border-pink-500/40 flex items-center justify-center text-pink-400 shadow-lg shadow-pink-500/20 flex-shrink-0">
              <Video className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                  WAN 3.0 Video Studio
                </h1>
                <span className="text-[10px] font-mono bg-purple-500/20 text-purple-300 border border-purple-500/30 px-2 py-0.5 rounded-full">
                  alibaba/wan-3.0/image-to-video
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                Generate cinematic Image-to-Video clips with native audio &amp; smart duration up to 30s via AtlasCloud.
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleSyncFromEnhancer}
              className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-neutral-300 hover:text-white transition flex items-center gap-1.5"
              title="Sync keyframes currently loaded in I2V Enhancer"
            >
              <RotateCcw className="w-3.5 h-3.5 text-pink-400" />
              <span>Sync from I2V Enhancer</span>
            </button>

            {onOpenKeyModal && (
              <button
                type="button"
                onClick={onOpenKeyModal}
                className="px-3 py-1.5 rounded-xl bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-xs font-semibold text-purple-300 hover:text-white transition flex items-center gap-1.5"
                title="Verify AtlasCloud API key"
              >
                <Key className="w-3.5 h-3.5 text-purple-400" />
                <span>API Keys</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Frame Selection Section: Frame A (Start) & Frame B (End) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
        {/* Frame A (Required Start Frame) */}
        <div className="trans-card p-5 border-pink-500/30 flex flex-col justify-between min-h-[340px]">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-pink-400" />
                <h3 className="text-sm font-bold text-white">Start Frame (Frame A)</h3>
                <span className="text-[10px] bg-pink-500/20 text-pink-300 border border-pink-500/30 px-1.5 py-0.5 rounded font-mono font-semibold">
                  Required
                </span>
              </div>

              {startFrame && (
                <button
                  type="button"
                  onClick={() => setStartFrame(null)}
                  className="text-xs text-neutral-400 hover:text-red-400 flex items-center gap-1"
                  title="Remove start frame"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Remove</span>
                </button>
              )}
            </div>

            {startFrame ? (
              <div className="relative group rounded-xl overflow-hidden border border-white/10 bg-black/50 aspect-video flex items-center justify-center">
                <img
                  src={startFrame.previewUrl}
                  alt="Start Frame"
                  className="w-full h-full object-contain"
                />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-2 p-3">
                  <button
                    type="button"
                    onClick={() => fileInputRefA.current?.click()}
                    className="px-3 py-1.5 rounded-lg bg-black/80 hover:bg-black text-xs font-medium text-white border border-white/20 transition flex items-center gap-1"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Change</span>
                  </button>
                </div>
              </div>
            ) : (
              <div
                onClick={() => fileInputRefA.current?.click()}
                className="border-2 border-dashed border-white/15 hover:border-pink-500/50 rounded-xl p-8 aspect-video flex flex-col items-center justify-center text-center cursor-pointer transition bg-white/[0.02] hover:bg-pink-500/[0.03] group"
              >
                <div className="w-12 h-12 rounded-xl bg-pink-500/10 border border-pink-500/20 flex items-center justify-center text-pink-400 mb-3 group-hover:scale-105 transition-transform">
                  <Upload className="w-5 h-5" />
                </div>
                <p className="text-xs font-semibold text-white mb-1">Click to upload Start Frame</p>
                <p className="text-[11px] text-neutral-500">PNG, JPG, or WEBP (Max 20MB)</p>
              </div>
            )}

            <input
              ref={fileInputRefA}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleUploadFile(file, 'start');
              }}
            />
          </div>

          <div className="mt-3 pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
            <span className="text-[11px] text-neutral-500">Fast shortcuts:</span>
            <div className="flex items-center gap-1.5">
              {enhancerStartFrame && (
                <button
                  type="button"
                  onClick={() => {
                    setStartFrame(enhancerStartFrame);
                    onShowToast('Loaded Enhancer Frame A');
                  }}
                  className="text-[11px] px-2 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 hover:text-white transition"
                >
                  From Enhancer A
                </button>
              )}
              {studioImage && (
                <button
                  type="button"
                  onClick={() => handleImportFromStudio('start')}
                  className="text-[11px] px-2 py-1 rounded-lg bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/30 text-pink-300 hover:text-white transition"
                >
                  From Keyframe Studio
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Frame B (Optional Interpolation Target) */}
        <div className="trans-card p-5 border-purple-500/30 flex flex-col justify-between min-h-[340px]">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-400" />
                <h3 className="text-sm font-bold text-white">End Frame (Frame B)</h3>
                <span className="text-[10px] bg-purple-500/20 text-purple-300 border border-purple-500/30 px-1.5 py-0.5 rounded font-mono">
                  Optional (Interpolation)
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSwapFrames}
                  className="text-xs text-neutral-400 hover:text-pink-300 flex items-center gap-1 px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 transition"
                  title="Swap Frame A and Frame B"
                >
                  <ArrowRightLeft className="w-3 h-3" />
                  <span>Swap A ⇄ B</span>
                </button>

                {endFrame && (
                  <button
                    type="button"
                    onClick={() => setEndFrame(null)}
                    className="text-xs text-neutral-400 hover:text-red-400 flex items-center gap-1"
                    title="Remove end frame"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Remove</span>
                  </button>
                )}
              </div>
            </div>

            {endFrame ? (
              <div className="relative group rounded-xl overflow-hidden border border-white/10 bg-black/50 aspect-video flex items-center justify-center">
                <img
                  src={endFrame.previewUrl}
                  alt="End Frame"
                  className="w-full h-full object-contain"
                />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-2 p-3">
                  <button
                    type="button"
                    onClick={() => fileInputRefB.current?.click()}
                    className="px-3 py-1.5 rounded-lg bg-black/80 hover:bg-black text-xs font-medium text-white border border-white/20 transition flex items-center gap-1"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Change</span>
                  </button>
                </div>
              </div>
            ) : (
              <div
                onClick={() => fileInputRefB.current?.click()}
                className="border-2 border-dashed border-white/15 hover:border-purple-500/50 rounded-xl p-8 aspect-video flex flex-col items-center justify-center text-center cursor-pointer transition bg-white/[0.02] hover:bg-purple-500/[0.03] group"
              >
                <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 mb-3 group-hover:scale-105 transition-transform">
                  <Upload className="w-5 h-5" />
                </div>
                <p className="text-xs font-semibold text-white mb-1">Click to upload End Frame</p>
                <p className="text-[11px] text-neutral-500">Optional: WAN 3.0 interpolates A → B</p>
              </div>
            )}

            <input
              ref={fileInputRefB}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleUploadFile(file, 'end');
              }}
            />
          </div>

          <div className="mt-3 pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
            <span className="text-[11px] text-neutral-500">Fast shortcuts:</span>
            <div className="flex items-center gap-1.5">
              {enhancerEndFrame && (
                <button
                  type="button"
                  onClick={() => {
                    setEndFrame(enhancerEndFrame);
                    onShowToast('Loaded Enhancer Frame B');
                  }}
                  className="text-[11px] px-2 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 hover:text-white transition"
                >
                  From Enhancer B
                </button>
              )}
              {studioImage && (
                <button
                  type="button"
                  onClick={() => handleImportFromStudio('end')}
                  className="text-[11px] px-2 py-1 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-purple-300 hover:text-white transition"
                >
                  From Keyframe Studio
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Workspace: Motion Prompt (Left) & Render Settings / Controls (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Motion Prompt Editor (7 cols) */}
        <div className="lg:col-span-7 trans-card p-6 border-pink-500/25 flex flex-col shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Film className="w-4 h-4 text-pink-400" />
              <h2 className="text-sm font-bold text-white">Motion &amp; Video Prompt</h2>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-[11px] font-mono text-neutral-400">
                {prompt.length.toLocaleString()} / 20,000 chars
              </span>

              {prompt && (
                <button
                  type="button"
                  onClick={() => setPrompt('')}
                  className="text-xs text-neutral-400 hover:text-red-400 transition"
                  title="Clear prompt"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={10}
            maxLength={20000}
            placeholder="Describe the cinematic action, camera motion, transformation kinematics, character delivery, and sound foley cues for WAN 3.0..."
            className="w-full bg-[#0e0e17] border border-white/10 rounded-xl p-4 text-xs font-mono leading-relaxed text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500/60 focus:ring-1 focus:ring-pink-500/20 transition resize-y min-h-[220px]"
          />

          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-neutral-500 text-[11px]">Quick idea seeds:</span>
              <button
                type="button"
                onClick={() =>
                  setPrompt(
                    'Fluid, continuous anatomical and textile transformation bridging Frame A to Frame B. Camera slowly dollys in with anamorphic rack focus. Subtle fabric stretching and organic phase shift, settling smoothly into final pose.'
                  )
                }
                className="text-[11px] px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/5 transition"
              >
                Morph &amp; Dolly In
              </button>
              <button
                type="button"
                onClick={() =>
                  setPrompt(
                    'Dynamic 360-degree orbit around the subject as glowing energy ribbons initiate immediate wardrobe and secondary sex characteristic transformation. Synchronized low-frequency hum, rising pitch, and startled gasp.'
                  )
                }
                className="text-[11px] px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/5 transition"
              >
                Orbit &amp; Energy
              </button>
            </div>

            <button
              type="button"
              onClick={() => {
                navigator.clipboard.writeText(prompt);
                onShowToast('Prompt copied to clipboard');
              }}
              disabled={!prompt.trim()}
              className="text-neutral-400 hover:text-white transition flex items-center gap-1 text-[11px] disabled:opacity-30"
            >
              <Copy className="w-3 h-3" />
              <span>Copy</span>
            </button>
          </div>
        </div>

        {/* Right Column: Generation Settings & Submit (5 cols) */}
        <div className="lg:col-span-5 trans-card p-6 border-purple-500/25 flex flex-col justify-between shadow-xl space-y-6">
          <div className="space-y-5">
            <div className="flex items-center gap-2 pb-3 border-b border-white/10">
              <Settings className="w-4 h-4 text-purple-400" />
              <h2 className="text-sm font-bold text-white">Generation Settings</h2>
            </div>

            {/* Resolution Drop Down Menu */}
            <div>
              <label className="text-xs font-semibold text-neutral-300 flex items-center justify-between mb-2">
                <span>Output Resolution</span>
                <span className="text-[10px] font-mono text-pink-400 bg-pink-500/10 px-2 py-0.5 rounded border border-pink-500/20">
                  {resolution}
                </span>
              </label>
              <div className="relative">
                <select
                  value={resolution}
                  onChange={(e) => setResolution(e.target.value as VideoResolution)}
                  className="w-full bg-[#12121c] border border-white/10 hover:border-pink-500/40 focus:border-pink-500/80 rounded-xl px-4 py-3 text-xs font-semibold text-white focus:outline-none focus:ring-2 focus:ring-pink-500/20 transition appearance-none cursor-pointer pr-10 shadow-inner"
                >
                  <optgroup label="Native Tiers">
                    <option value="1080p">1080p (Full HD · Default)</option>
                    <option value="720p">720p (High Definition)</option>
                    <option value="480p">480p (Standard Definition · Fast)</option>
                  </optgroup>
                  <optgroup label="ESR Super-Resolution Tiers">
                    <option value="720p-esr">720p-esr (ESR Enhanced)</option>
                    <option value="1080p-esr">1080p-esr (Super Resolution)</option>
                    <option value="1440p-esr">1440p-esr (2K ESR Enhanced)</option>
                    <option value="4k-esr">4k-esr (4K Ultra HD ESR)</option>
                  </optgroup>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3.5 text-neutral-400">
                  <ChevronDown className="w-4 h-4 text-pink-400" />
                </div>
              </div>
              <p className="text-[11px] text-neutral-500 mt-1.5">
                Aspect ratio automatically matches your uploaded keyframes.
              </p>
            </div>

            {/* Duration Slider & Smart Duration */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-pink-400" />
                  <span>Video Duration</span>
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsSmartDuration(!isSmartDuration)}
                    className={`text-[10px] px-2 py-0.5 rounded-full border transition font-mono ${
                      isSmartDuration
                        ? 'bg-pink-500/20 border-pink-500 text-pink-300 font-bold'
                        : 'bg-white/5 border-white/10 text-neutral-400 hover:text-white'
                    }`}
                  >
                    Smart Duration (-1)
                  </button>
                  <span className="text-xs font-mono font-bold text-pink-300">
                    {isSmartDuration ? 'Auto' : `${duration}s`}
                  </span>
                </div>
              </div>

              {!isSmartDuration && (
                <div className="space-y-2">
                  <input
                    type="range"
                    min={2}
                    max={30}
                    step={1}
                    value={duration}
                    onChange={(e) => setDuration(Number(e.target.value))}
                    className="w-full accent-pink-500 bg-white/10 h-1.5 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between items-center text-[10px] font-mono text-neutral-500">
                    <span>2s</span>
                    <span>5s (Default)</span>
                    <span>15s</span>
                    <span>30s (Max)</span>
                  </div>
                </div>
              )}
            </div>

            {/* Audio Toggle & Seed Controls */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {/* Native Audio Toggle */}
              <div className="p-3 rounded-xl bg-[#12121c] border border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {includeAudio ? (
                    <Volume2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <VolumeX className="w-4 h-4 text-neutral-500" />
                  )}
                  <div>
                    <span className="text-xs font-semibold text-white block">Native Audio</span>
                    <span className="text-[10px] text-neutral-400 block">SFX &amp; voices</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIncludeAudio(!includeAudio)}
                  className={`w-10 h-5 rounded-full transition p-0.5 flex items-center ${
                    includeAudio ? 'bg-emerald-500 justify-end' : 'bg-neutral-700 justify-start'
                  }`}
                >
                  <span className="w-4 h-4 rounded-full bg-white shadow-sm" />
                </button>
              </div>

              {/* Random Seed */}
              <div className="p-3 rounded-xl bg-[#12121c] border border-white/10 flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-white block">Seed</span>
                  <span className="text-[10px] text-neutral-400 font-mono block">
                    {seed === -1 ? 'Random (-1)' : seed}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setSeed(-1)}
                    className={`text-[10px] px-2 py-1 rounded transition font-mono ${
                      seed === -1
                        ? 'bg-pink-500/20 text-pink-300 border border-pink-500/30'
                        : 'bg-white/5 text-neutral-400 hover:text-white'
                    }`}
                    title="Random seed"
                  >
                    🎲 Rand
                  </button>
                  <button
                    type="button"
                    onClick={() => setSeed(Math.floor(Math.random() * 9999999))}
                    className="text-[10px] px-2 py-1 rounded bg-white/5 text-neutral-400 hover:text-white transition font-mono"
                    title="Generate fixed seed"
                  >
                    Pick
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Error Banner */}
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">{errorMessage}</div>
            </div>
          )}

          {/* Primary Action Button */}
          <div>
            {!isGenerating ? (
              <button
                type="button"
                onClick={handleGenerate}
                className="w-full py-4 rounded-2xl font-bold text-sm text-white bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 hover:from-pink-400 hover:via-purple-500 hover:to-indigo-500 transition shadow-xl shadow-pink-600/30 flex items-center justify-center gap-2 group cursor-pointer active:scale-[0.99]"
              >
                <Play className="w-4 h-4 text-pink-200 group-hover:scale-110 transition-transform fill-white" />
                <span>Generate WAN 3.0 Video</span>
                <Sparkles className="w-4 h-4 text-yellow-300 animate-pulse" />
              </button>
            ) : (
              <div className="space-y-3">
                <div className="w-full p-4 rounded-2xl bg-[#121124] border border-pink-500/40 text-center flex flex-col items-center justify-center gap-2">
                  <div className="flex items-center gap-2 text-pink-300 font-bold text-sm">
                    <Loader2 className="w-4 h-4 animate-spin text-pink-400" />
                    <span>{pollStatus}</span>
                  </div>
                  <div className="text-[11px] font-mono text-neutral-400 flex items-center gap-2">
                    <span>Elapsed: {elapsedSeconds}s</span>
                    {predictionId && (
                      <span className="text-neutral-500 truncate max-w-[180px]">
                        ID: {predictionId}
                      </span>
                    )}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleCancelGeneration}
                  className="w-full py-2 rounded-xl bg-white/5 hover:bg-red-500/10 hover:text-red-400 text-neutral-400 text-xs transition border border-white/10"
                >
                  Cancel / Stop Waiting
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Video Output Player Section (Shown when active video is ready) */}
      {activeVideoUrl && (
        <div id="video-player-container" className="trans-card p-6 border-emerald-500/40 shadow-2xl space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
            <div className="flex items-center gap-2.5">
              <span className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse" />
              <h2 className="text-base font-bold text-white">Generated Video Output</h2>
              <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                Ready · {resolution}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => handleCopyUrl(activeVideoUrl)}
                className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-neutral-300 hover:text-white transition flex items-center gap-1.5"
                title="Copy MP4 direct link"
              >
                {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedUrl ? 'Copied URL' : 'Copy Link'}</span>
              </button>

              <button
                type="button"
                onClick={() => handleDownloadVideo(activeVideoUrl)}
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs transition flex items-center gap-1.5 shadow-md shadow-emerald-600/20"
                title="Download video as MP4"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download MP4</span>
              </button>

              <a
                href={activeVideoUrl}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white border border-white/10 transition"
                title="Open in new window"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* HTML5 Video Player */}
          <div className="relative rounded-2xl overflow-hidden bg-black border border-white/15 flex items-center justify-center max-h-[640px]">
            <video
              ref={videoPlayerRef}
              src={activeVideoUrl}
              controls
              autoPlay
              loop
              playsInline
              className="w-full h-full max-h-[640px] object-contain shadow-2xl"
            />
          </div>
        </div>
      )}

      {/* Video Generation History & Gallery */}
      <div className="trans-card p-6 border-white/10 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-purple-400" />
            <h2 className="text-sm font-bold text-white">Video Generation History</h2>
            <span className="text-[10px] font-mono text-neutral-400 bg-white/5 px-2 py-0.5 rounded-full">
              {history.length}
            </span>
          </div>

          {history.length > 0 && (
            <button
              type="button"
              onClick={handleClearHistory}
              className="text-xs text-neutral-400 hover:text-red-400 flex items-center gap-1 transition"
              title="Clear all generated video history"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear History</span>
            </button>
          )}
        </div>

        {history.length === 0 ? (
          <div className="py-12 px-4 text-center rounded-2xl bg-[#0f0e1a]/60 border border-dashed border-white/10 flex flex-col items-center justify-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-500/20 to-pink-500/20 border border-purple-500/30 flex items-center justify-center text-purple-300 shadow-inner">
              <Film className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-white">No Generated Videos Yet</h3>
              <p className="text-xs text-neutral-400 max-w-md mx-auto leading-relaxed">
                Clips you render with WAN 3.0 will be preserved here across sessions with preview playback, instant re-load into the studio, and direct MP4 downloads.
              </p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {history.map((item) => {
              if (item.status === 'generating') {
                return (
                  <div
                    key={item.id}
                    className="rounded-2xl p-4 bg-[#141026] border border-pink-500/40 shadow-lg shadow-pink-500/5 flex flex-col justify-between gap-3"
                  >
                    <div className="space-y-2.5">
                      <div className="relative rounded-xl overflow-hidden aspect-video bg-[#0b0a14] border border-pink-500/30 flex flex-col items-center justify-center gap-2 p-4 text-center">
                        <Loader2 className="w-7 h-7 text-pink-400 animate-spin" />
                        <div className="space-y-0.5">
                          <span className="text-xs font-bold text-pink-200 block">Rendering WAN 3.0 Video</span>
                          <span className="text-[10px] text-pink-300/70 block">Processing on GPU cluster…</span>
                        </div>
                        {item.predictionId && (
                          <span className="text-[9px] font-mono text-neutral-400 bg-white/5 px-2 py-0.5 rounded border border-white/10 max-w-[170px] truncate">
                            ID: {item.predictionId}
                          </span>
                        )}
                        <div className="absolute top-2 right-2 bg-pink-500/20 backdrop-blur-md px-2 py-0.5 rounded-md text-[10px] font-mono text-pink-300 border border-pink-500/30">
                          {item.resolution}
                        </div>
                      </div>

                      <p className="text-xs text-neutral-300 line-clamp-2 leading-relaxed">
                        {item.prompt}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-neutral-400">
                      <span className="font-mono text-[10px]">
                        {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleCheckItemStatus(item)}
                          disabled={checkingItemId === item.id}
                          className="px-2.5 py-1 rounded-lg bg-pink-500/20 hover:bg-pink-500/30 text-pink-300 transition text-[10px] font-semibold flex items-center gap-1"
                          title="Check current status from AtlasCloud"
                        >
                          <RotateCcw className={`w-3 h-3 ${checkingItemId === item.id ? 'animate-spin' : ''}`} />
                          <span>Check</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteHistory(item.id)}
                          className="p-1 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-red-400 transition"
                          title="Cancel / Remove"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              }

              if (item.status === 'failed') {
                return (
                  <div
                    key={item.id}
                    className="rounded-2xl p-4 bg-[#180f14] border border-red-500/30 flex flex-col justify-between gap-3"
                  >
                    <div className="space-y-2.5">
                      <div className="relative rounded-xl overflow-hidden aspect-video bg-[#10080d] border border-red-500/20 flex flex-col items-center justify-center gap-1.5 p-3 text-center">
                        <AlertCircle className="w-6 h-6 text-red-400" />
                        <span className="text-xs font-bold text-red-300">Generation Failed</span>
                        <p className="text-[10px] text-red-400/80 line-clamp-2 px-2">
                          {item.error || 'Failed on GPU cluster'}
                        </p>
                        <div className="absolute top-2 right-2 bg-red-500/20 px-2 py-0.5 rounded-md text-[10px] font-mono text-red-300 border border-red-500/30">
                          {item.resolution}
                        </div>
                      </div>

                      <p className="text-xs text-neutral-300 line-clamp-2 leading-relaxed">
                        {item.prompt}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-neutral-400">
                      <span className="font-mono text-[10px]">
                        {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleRestoreFromHistory(item)}
                          className="px-2 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-neutral-300 transition text-[10px] font-semibold"
                          title="Load prompt & settings"
                        >
                          Load
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteHistory(item.id)}
                          className="p-1 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-red-400 transition"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              }

              return (
                <div
                  key={item.id}
                  className="rounded-2xl p-4 bg-[#10101a] border border-white/10 hover:border-purple-500/40 transition flex flex-col justify-between gap-3 group"
                >
                  <div className="space-y-2">
                    <div className="relative rounded-xl overflow-hidden aspect-video bg-black border border-white/10 flex items-center justify-center">
                      {item.videoUrl ? (
                        <video
                          src={item.videoUrl}
                          className="w-full h-full object-cover"
                          muted
                          playsInline
                          onMouseEnter={(e) => e.currentTarget.play().catch(() => {})}
                          onMouseLeave={(e) => {
                            e.currentTarget.pause();
                            e.currentTarget.currentTime = 0;
                          }}
                        />
                      ) : (
                        <div className="text-neutral-500 text-xs">No video URL</div>
                      )}
                      <div className="absolute top-2 right-2 bg-black/70 backdrop-blur-md px-2 py-0.5 rounded-md text-[10px] font-mono text-white border border-white/10">
                        {item.resolution}
                      </div>

                      {/* Keyframe Badges */}
                      <div className="absolute bottom-2 left-2 flex items-center gap-1">
                        {item.startFrame?.previewUrl && (
                          <img
                            src={item.startFrame.previewUrl}
                            alt="Frame A"
                            className="w-5 h-5 rounded-md object-cover border border-white/30 shadow"
                            title="Start Frame A"
                          />
                        )}
                        {item.endFrame?.previewUrl && (
                          <img
                            src={item.endFrame.previewUrl}
                            alt="Frame B"
                            className="w-5 h-5 rounded-md object-cover border border-white/30 shadow"
                            title="End Frame B"
                          />
                        )}
                        <span className="text-[9px] font-mono bg-black/60 backdrop-blur text-neutral-300 px-1.5 py-0.5 rounded">
                          {item.duration === -1 ? 'Smart' : `${item.duration}s`}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-neutral-300 line-clamp-2 leading-relaxed">
                      {item.prompt}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-neutral-400">
                    <span className="font-mono text-[10px]">
                      {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleRestoreFromHistory(item)}
                        className="px-2 py-1 rounded-lg bg-purple-500/15 hover:bg-purple-500/30 text-purple-300 transition text-[10px] font-semibold"
                        title="Load into Studio"
                      >
                        Load
                      </button>

                      {item.videoUrl && (
                        <button
                          type="button"
                          onClick={() => handleDownloadVideo(item.videoUrl!)}
                          className="p-1 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-white transition"
                          title="Download MP4"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => handleDeleteHistory(item.id)}
                        className="p-1 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-red-400 transition"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
