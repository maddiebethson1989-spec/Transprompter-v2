import React, { useState, useRef, useEffect } from 'react';
import { GeminiChatModel } from '../../types';
import { safeFetchJson } from '../../utils/safeApi';
import { Sparkles, Wand2, Copy, Check, Play, ArrowRight } from 'lucide-react';
import { QuickIdea } from './types';
import { ChatMsg } from './chatMsg';
import { INITIAL_MESSAGES, DIRECTOR_TITLE } from './initialMessages';
import type { KeyframeChatbotProps } from './types';


export function useKeyframeChatbot({
  currentPrompt,
  currentEditPrompt,
  activeImage,
  activeImageMime = 'image/png',
  imageSize,
  aspectRatio,
  onApplyInitialPrompt,
  onApplyEditPrompt,
  onShowToast,
  onClose,
  isEmbedded = false,
  initialQuery,
  onClearInitialQuery,
  onUploadImage,
}: KeyframeChatbotProps) {
  // Single unified Keyframe Director thread (v5). The legacy per-role sessions (v4) are discarded.
  const KEYFRAME_COPILOT_STORAGE_KEY = 'transprompter_keyframe_director_thread_v5';
  const LEGACY_COPILOT_STORAGE_KEY = 'transprompter_keyframe_copilot_session_v4';
  const copilotFileInputRef = useRef<HTMLInputElement>(null);

  const [selectedModel, setSelectedModel] = useState<GeminiChatModel>('gemini-3.8-flash');

  const [messages, setMessages] = useState<ChatMsg[]>(() => {
    try {
      localStorage.removeItem(LEGACY_COPILOT_STORAGE_KEY);
      const saved = localStorage.getItem(KEYFRAME_COPILOT_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Failed to restore Keyframe Director thread:', e);
    }
    return INITIAL_MESSAGES;
  });

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showMethodologyGuide, setShowMethodologyGuide] = useState(false);
  const [showQuickIdeas, setShowQuickIdeas] = useState(false);

  // Saved Quick Ideas state persisted in localStorage
  const KEYFRAME_QUICK_IDEAS_STORAGE_KEY = 'transprompter_keyframe_quick_ideas_v1';
  const [quickIdeas, setQuickIdeas] = useState<QuickIdea[]>(() => {
    try {
      const saved = localStorage.getItem(KEYFRAME_QUICK_IDEAS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.warn('Failed to load Quick Ideas:', e);
    }
    return [];
  });


  // States for Prompt Editing & Answer Reloading
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingContent, setEditingContent] = useState('');
  const [reloadingMessageId, setReloadingMessageId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  // Persist the thread to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem(KEYFRAME_COPILOT_STORAGE_KEY, JSON.stringify(messages));
    } catch (err) {
      console.warn('Failed to cache Keyframe Director messages:', err);
    }
  }, [messages]);


  // Auto-send initial query if triggered externally (e.g. from 3 New Ideas button in studio)
  useEffect(() => {
    if (initialQuery && initialQuery.trim()) {
      handleSendMessage(initialQuery);
      onClearInitialQuery?.();
    }
  }, [initialQuery]);

  const copyText = (text: string, id: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    onShowToast(`✓ Copied ${label}`);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearChat = () => {
    setMessages(INITIAL_MESSAGES);
    setEditingMessageId(null);
    try {
      localStorage.setItem(KEYFRAME_COPILOT_STORAGE_KEY, JSON.stringify(INITIAL_MESSAGES));
    } catch {}
    onShowToast(`Thread cleared for ${DIRECTOR_TITLE}`);
  };

  const handleSendMessage = async (textToSend?: string | unknown) => {
    const raw = typeof textToSend === 'string' ? textToSend : input;
    const text = (raw || '').trim();
    if (!text || loading) return;

    const userMsg: ChatMsg = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const payload = {
        messages: [...messages, userMsg].map((m) => ({
          role: m.role,
          content: m.content,
        })),
        activeImage: activeImage || null,
        activeImageMime,
        currentPrompt,
        currentEditPrompt,
        model: selectedModel,
      };

      const data = await safeFetchJson<{
        success: boolean;
        reply: string;
        searchQueries?: string[];
        error?: string;
      }>('/api/keyframe-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!data.success) {
        throw new Error(data.error || 'Failed to get copilot response');
      }

      const assistantMsg: ChatMsg = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: data.reply,
        timestamp: Date.now(),
        modelUsed: selectedModel,
        searchQueries: data.searchQueries,
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || 'Error communicating with prompt copilot');
      setMessages((prev) => [
        ...prev,
        {
          id: `error-${Date.now()}`,
          role: 'assistant',
          content: `⚠️ Error: ${err.message || 'Failed to connect to the assistant'}. Please try again.`,
          timestamp: Date.now(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  // Quick Ideas Handlers
  const handleSaveQuickIdea = (idea: {
    title?: string;
    prompt: string;
    type?: 'initial' | 'edit' | 'custom';
  }) => {
    const trimmedPrompt = idea.prompt.trim();
    if (!trimmedPrompt) return;

    const existing = quickIdeas.find((q) => q.prompt.trim() === trimmedPrompt);
    if (existing) {
      onShowToast('💡 Prompt is already in Quick Ideas');
      return;
    }

    const defaultTitle =
      idea.title?.trim() ||
      (idea.type === 'initial'
        ? 'End Frame B Prompt'
        : idea.type === 'edit'
        ? 'Start Frame Reverse Edit'
        : trimmedPrompt.length > 40
        ? trimmedPrompt.slice(0, 40) + '…'
        : trimmedPrompt);

    const newIdea: QuickIdea = {
      id: `${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      title: defaultTitle,
      prompt: trimmedPrompt,
      type: idea.type || 'custom',
      timestamp: Date.now(),
    };

    const updated = [newIdea, ...quickIdeas];
    setQuickIdeas(updated);
    try {
      localStorage.setItem(KEYFRAME_QUICK_IDEAS_STORAGE_KEY, JSON.stringify(updated));
    } catch (err) {
      console.warn('Failed to persist Quick Ideas:', err);
    }
    onShowToast('⭐ Saved to Quick Ideas!');
  };

  const handleDeleteQuickIdea = (id: string) => {
    const updated = quickIdeas.filter((q) => q.id !== id);
    setQuickIdeas(updated);
    try {
      localStorage.setItem(KEYFRAME_QUICK_IDEAS_STORAGE_KEY, JSON.stringify(updated));
    } catch (err) {
      console.warn('Failed to update Quick Ideas:', err);
    }
    onShowToast('✓ Idea removed from Quick Ideas');
  };

  const handleClearQuickIdeas = () => {
    setQuickIdeas([]);
    try {
      localStorage.removeItem(KEYFRAME_QUICK_IDEAS_STORAGE_KEY);
    } catch {}
    onShowToast('✓ Cleared all Quick Ideas');
  };

  const handleApplyQuickIdea = (idea: QuickIdea, target: 'initial' | 'edit' | 'chat') => {
    if (target === 'initial') {
      onApplyInitialPrompt(idea.prompt, false);
      onShowToast('✓ Loaded into Studio Prompt');
    } else if (target === 'edit') {
      onApplyEditPrompt(idea.prompt, false);
      onShowToast('✓ Loaded into Edit Prompt');
    } else if (target === 'chat') {
      setInput(idea.prompt);
      onShowToast('✓ Loaded into Copilot input');
    }
  };


  // Edit user prompt & regenerate answer
  const handleStartEdit = (msg: ChatMsg) => {
    setEditingMessageId(msg.id);
    setEditingContent(msg.content);
  };

  const handleCancelEdit = () => {
    setEditingMessageId(null);
    setEditingContent('');
  };

  const handleSaveEditedMessage = async (msgId: string) => {
    const trimmed = editingContent.trim();
    if (!trimmed || loading) return;

    const targetIndex = messages.findIndex((m) => m.id === msgId);
    if (targetIndex === -1) return;

    const updatedUserMsg: ChatMsg = {
      ...messages[targetIndex],
      content: trimmed,
      timestamp: Date.now(),
    };

    // Slice history up to and including the updated user message
    const truncatedHistory = [...messages.slice(0, targetIndex), updatedUserMsg];
    setMessages(truncatedHistory);
    setEditingMessageId(null);
    setEditingContent('');
    setLoading(true);

    try {
      const payload = {
        messages: truncatedHistory.map((m) => ({
          role: m.role,
          content: m.content,
        })),
        activeImage: activeImage || null,
        activeImageMime,
        currentPrompt,
        currentEditPrompt,
        model: selectedModel,
      };

      const data = await safeFetchJson<{
        success: boolean;
        reply: string;
        searchQueries?: string[];
        error?: string;
      }>('/api/keyframe-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!data.success) {
        throw new Error(data.error || 'Failed to get copilot response');
      }

      const assistantMsg: ChatMsg = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: data.reply,
        timestamp: Date.now(),
        modelUsed: selectedModel,
        searchQueries: data.searchQueries,
      };

      setMessages((prev) => [...prev, assistantMsg]);
      onShowToast('✓ Prompt updated & response regenerated');
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || 'Error communicating with prompt copilot');
      setMessages((prev) => [
        ...prev,
        {
          id: `error-${Date.now()}`,
          role: 'assistant',
          content: `⚠️ Error: ${err.message || 'Failed to connect to the assistant'}. Please try again.`,
          timestamp: Date.now(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  // Reload an individual assistant response
  const handleReloadAnswer = async (assistantMsgId: string) => {
    if (loading || reloadingMessageId) return;

    const targetIndex = messages.findIndex((m) => m.id === assistantMsgId);
    if (targetIndex === -1) return;

    const historyBefore = messages.slice(0, targetIndex);
    if (historyBefore.length === 0) return;

    setReloadingMessageId(assistantMsgId);

    try {
      const payload = {
        messages: historyBefore.map((m) => ({
          role: m.role,
          content: m.content,
        })),
        activeImage: activeImage || null,
        activeImageMime,
        currentPrompt,
        currentEditPrompt,
        model: selectedModel,
      };

      const data = await safeFetchJson<{
        success: boolean;
        reply: string;
        searchQueries?: string[];
        error?: string;
      }>('/api/keyframe-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!data.success) {
        throw new Error(data.error || 'Failed to reload copilot response');
      }

      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === assistantMsgId
            ? {
                ...msg,
                content: data.reply,
                timestamp: Date.now(),
                modelUsed: selectedModel,
                searchQueries: data.searchQueries,
              }
            : msg
        )
      );
      onShowToast('✓ Copilot answer reloaded');
    } catch (err: any) {
      console.error('Reload error:', err);
      onShowToast(`Failed to reload: ${err.message || 'Server error'}`);
    } finally {
      setReloadingMessageId(null);
    }
  };

  // Helper to trigger active image analysis
  const handleAskForReverseEdit = () => {
    if (!activeImage) {
      onShowToast('Please generate or upload an End Frame image in the studio first!');
      return;
    }
    const query = currentPrompt.trim()
      ? `I have generated the End Frame in the studio with the prompt: "${currentPrompt}". Look at the attached image and write the exact reverse Start Frame edit prompt to show them as young adult men before the transformation, matching their outfit colors, body types, and hair texture!`
      : `Look at the attached End Frame image I generated in the studio. Write the exact matching Start Frame edit prompt to show them as young adult men before being transformed, matching their outfit colors, hair, and location!`;
    handleSendMessage(query);
  };

  return {
    currentPrompt,
    currentEditPrompt,
    activeImage,
    activeImageMime,
    imageSize,
    aspectRatio,
    onApplyInitialPrompt,
    onApplyEditPrompt,
    onShowToast,
    onClose,
    isEmbedded,
    initialQuery,
    onClearInitialQuery,
    onUploadImage,
    KEYFRAME_COPILOT_STORAGE_KEY,
    copilotFileInputRef,
    selectedModel,
    setSelectedModel,
    messages,
    setMessages,
    input,
    setInput,
    loading,
    setLoading,
    copiedId,
    setCopiedId,
    showMethodologyGuide,
    setShowMethodologyGuide,
    showQuickIdeas,
    setShowQuickIdeas,
    quickIdeas,
    setQuickIdeas,
    handleSaveQuickIdea,
    handleDeleteQuickIdea,
    handleClearQuickIdeas,
    handleApplyQuickIdea,
    editingMessageId,
    setEditingMessageId,
    editingContent,
    setEditingContent,
    reloadingMessageId,
    setReloadingMessageId,
    messagesEndRef,
    directorTitle: DIRECTOR_TITLE,
    scrollToBottom,
    copyText,
    handleClearChat,
    handleSendMessage,
    handleStartEdit,
    handleCancelEdit,
    handleSaveEditedMessage,
    handleReloadAnswer,
    handleAskForReverseEdit,
  };
}


export type KeyframeChatbotState = ReturnType<typeof useKeyframeChatbot>;
