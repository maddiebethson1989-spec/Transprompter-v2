import { Send, Loader2, Upload } from 'lucide-react';
import type { KeyframeChatbotState } from './useKeyframeChatbot';

interface ChatInputBarProps {
  studio: KeyframeChatbotState;
}

export function ChatInputBar({ studio }: ChatInputBarProps) {
  const { copilotFileInputRef, input, setInput, loading, handleSendMessage } = studio;

  return (
    <div className="p-4 bg-[#0a0a0f] border-t border-white/10">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage(input);
        }}
        className="flex items-center gap-2"
      >
        <button
          type="button"
          onClick={() => copilotFileInputRef.current?.click()}
          disabled={loading}
          className="p-3 rounded-xl bg-[#16161f] hover:bg-white/10 text-neutral-400 hover:text-pink-300 border border-white/10 transition flex items-center justify-center flex-shrink-0"
          title="Upload an End Frame image for reverse edit prompt crafting"
        >
          <Upload className="w-4 h-4" />
        </button>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask for scenario ideas, outfits, poses & reactions, or reverse edit prompts for Nano Banana 2..."
          disabled={loading}
          className="flex-1 bg-[#16161f] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500/60 focus:ring-2 focus:ring-pink-500/20 transition disabled:opacity-50"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="p-3 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-medium transition disabled:opacity-50 disabled:cursor-not-allowed shadow-md shadow-pink-600/30 flex items-center justify-center flex-shrink-0"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
        </button>
      </form>
    </div>
  );
}
