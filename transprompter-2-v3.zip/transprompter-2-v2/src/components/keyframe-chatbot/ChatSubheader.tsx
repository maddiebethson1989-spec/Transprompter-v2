import { Trash2 } from 'lucide-react';
import type { KeyframeChatbotState } from './useKeyframeChatbot';

interface ChatSubheaderProps {
  studio: KeyframeChatbotState;
}

export function ChatSubheader({ studio }: ChatSubheaderProps) {
  const { selectedModel, directorTitle, handleClearChat } = studio;

  return (
    <div className="px-5 sm:px-6 py-3 bg-black/40 border-b border-white/10 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
        <span className="text-xs font-semibold text-neutral-300">{directorTitle}</span>
        <span className="text-xs text-neutral-500 font-mono">({selectedModel})</span>
      </div>

      <button
        onClick={handleClearChat}
        className="text-xs text-neutral-400 hover:text-red-400 flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-white/5 transition"
        title="Reset conversation"
      >
        <Trash2 className="w-3.5 h-3.5" />
        <span>Clear Thread</span>
      </button>
    </div>
  );
}
