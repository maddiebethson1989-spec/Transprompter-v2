// Dynamic pools for un-formulaic, unpredictable, and highly varied scenario prompts
const RANDOM_AESTHETICS = [
  'High Society Gala & Starlit Rooftop Champagne Lounge',
  'Retro 1980s Neon Synthwave Roller Rink & Arcade',
  'Victorian Botanical Glasshouse & Alchemical Conservatory',
  'Contemporary Streetwear Loft & Rainy Cityscape',
  'Mediterranean Coastal Sailing Yacht & Private Beach Cabana',
  'Dark Academia Historic Stone Library & Secret Archive',
  'Vintage 1950s Chrome Rockabilly Diner & Jukebox',
  'Moonlit Venetian Masquerade Ballroom & Palace Courtyard',
  'Gymnastics Training Center & Performance Arena',
  'Haute Couture Fashion Week Runway & Backstage Green Room',
  'Equestrian Country Club Stables & Manicured Paddock',
  'Art Museum Restoration Lab & Gilded Portrait Gallery',
  'Luxury Alpine Thermal Spa & Cedar Hot Springs',
  'Sun-drenched Pottery Studio & Artisan Espresso Cafe',
  'Cozy Domestic Living Room with a Mysterious Inherited Chest',
];

const RANDOM_TRIGGERS = [
  'an ornate antique clockwork music box chiming an intoxicating, hypnotic melody',
  'stepping across an enchanted gilded vanity mirror threshold that pulls them into reflection',
  'spilling an experimental alchemical perfume vial emitting violet vapor',
  'a cursed vintage stage costume or thrifted couture jacket with latent magic',
  'a glowing celestial comet passing overhead during a toast',
  'an ancient wishing coin cast into a starlit marble fountain',
  'an eccentric avant-garde fashion designer testing a reality-bending holographic prism',
  'an enchanted family heirloom locket that suddenly snaps open',
  'an accidental laboratory surge during an optical laser restoration',
  'a mysterious alchemical tea brew infused with rare moonflower pollen',
];

const RANDOM_WARDROBE_METAMORPHOSES = [
  'Tailored tuxedos & suits transforming into floor-length scarlet satin slit gowns & high heels',
  'Flannel shirts & work jeans shifting into pastel floral sundresses, cardigans & strappy sandals',
  'Athletic tracksuits & sneakers morphing into metallic gymnastics singlets & ballet tights',
  'Vintage biker leather & jeans transitioning into 50s polka-dot swing dresses & Mary Janes',
  'Summer board shorts & linen shirts transforming into strappy designer bikinis & sheer sarongs',
  'Crisp office button-downs shifting into high-waisted pencil skirts & silk pussy-bow blouses',
  'Cotton lounge henleys & sweatpants softening into delicate silk camisole and ruffled boy-short sets',
  'Casual oversized graphic tees & denim turning into cropped halter tops & pleated skater skirts',
  'Urban techwear & cargo pants shifting into backless metallic mini-dresses & platform boots',
];

export function generateRandomizedIdeaPrompt(): string {
  const aesthetic = RANDOM_AESTHETICS[Math.floor(Math.random() * RANDOM_AESTHETICS.length)];
  const trigger = RANDOM_TRIGGERS[Math.floor(Math.random() * RANDOM_TRIGGERS.length)];
  const wardrobe = RANDOM_WARDROBE_METAMORPHOSES[Math.floor(Math.random() * RANDOM_WARDROBE_METAMORPHOSES.length)];
  const counts = [
    '1 solo protagonist',
    'a duo of 2 companions/friends',
    'a trio of 3 characters',
    'a dynamic group of 4',
  ];
  const characterCount = counts[Math.floor(Math.random() * counts.length)];

  return `Generate 3 completely unique, inventive, and non-formulaic male-to-female transformation scenario ideas.

MANDATORY ANTI-FORMULAIC VARIETY RULES:
- Maximize randomness, creativity, and unpredictability! Break completely away from repetitive formulas, tired clichés, or predictable templates.
- Do NOT repeat the same settings, triggers, or poses across the 3 ideas.
- Infuse surprising cinematic flavor (for inspiration, draw from fresh worlds like "${aesthetic}").
- Feature inventive, non-cliché catalysts (such as ${trigger}).
- Showcase diverse wardrobes (such as ${wardrobe}).
- Incorporate diverse character counts across the batch (including ${characterCount}).
- Dynamic staging of shock, disbelief, and dismay (stumbling off-balance in heels, breathless freeze before mirrors, frantically clutching altered hemlines or waistbands, gasping at delicate hands, onlookers smirking/giggling).
- For each idea, provide complete paired Nano Banana 2 prompts (End Frame B initial prompt ending with "4k, hdr, photorealistic", and Start Frame A reverse edit prompt).`;
}
