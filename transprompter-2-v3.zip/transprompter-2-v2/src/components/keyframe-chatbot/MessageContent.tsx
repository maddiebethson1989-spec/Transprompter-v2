import React from 'react';
import { Sparkles, Wand2, Copy, Check, Play, ArrowRight, Lightbulb } from 'lucide-react';
import type { KeyframeChatbotState } from './useKeyframeChatbot';
import type { ChatMsg } from './chatMsg';

// Helper to parse message text into markdown sections and interactive prompt action cards
export function renderMessageContent(studio: KeyframeChatbotState, msg: ChatMsg) {
  const {
    activeImage,
    onApplyInitialPrompt,
    onApplyEditPrompt,
    onShowToast,
    copiedId,
    copyText,
    handleSaveQuickIdea,
  } = studio;


  const content = msg.content;

  // Extract all code blocks with their positions
  const codeBlockRegex = /```(?:initial-end-frame|initial_end_frame|edit-start-frame|edit_start_frame)([\s\S]*?)```/gi;
  const matches: { type: 'initial' | 'edit'; prompt: string; start: number; end: number }[] = [];

  let m: RegExpExecArray | null;
  while ((m = codeBlockRegex.exec(content)) !== null) {
    const matchedTag = m[0].split('\n')[0].toLowerCase();
    const type = matchedTag.includes('initial') ? 'initial' : 'edit';
    matches.push({
      type,
      prompt: m[1].trim(),
      start: m.index,
      end: codeBlockRegex.lastIndex,
    });
  }

  // If no code blocks found, render plain text
  if (matches.length === 0) {
    return <div className="text-xs leading-relaxed text-neutral-200 whitespace-pre-wrap space-y-2">{content}</div>;
  }

  // Build alternating text chunks and paired prompt cards
  const elements: React.ReactNode[] = [];
  let cursor = 0;
  let pairIdx = 0;

  for (let i = 0; i < matches.length; i++) {
    const block = matches[i];

    // Any text prior to this block
    if (block.start > cursor) {
      const textChunk = content.slice(cursor, block.start).trim();
      if (textChunk) {
        elements.push(
          <div
            key={`text-${cursor}`}
            className="text-xs leading-relaxed text-neutral-200 whitespace-pre-wrap space-y-1.5"
          >
            {textChunk}
          </div>
        );
      }
    }

    // Check if this initial block is followed by an edit block to pair them
    const nextBlock = matches[i + 1];
    const isPaired = block.type === 'initial' && nextBlock && nextBlock.type === 'edit';

    const initialPrompt = block.type === 'initial' ? block.prompt : null;
    const editPrompt = isPaired ? nextBlock.prompt : block.type === 'edit' ? block.prompt : null;

    if (isPaired) {
      cursor = nextBlock.end;
      i++; // skip next block since it's paired
    } else {
      cursor = block.end;
    }

    pairIdx++;
    const currentPairNum = pairIdx;
    const initialId = `${msg.id}-p${currentPairNum}-init`;
    const editId = `${msg.id}-p${currentPairNum}-edit`;

    elements.push(
      <div key={`pair-${currentPairNum}`} className="flex flex-col gap-2.5 my-2">
        {/* Step 1: Initial Prompt (End Frame B) */}
        {initialPrompt && (
          <div className="p-3.5 rounded-xl bg-pink-950/20 border border-pink-500/40 shadow-sm flex flex-col gap-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-pink-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                <span>
                  {matches.length > 2
                    ? `Idea ${currentPairNum} · Step 1: End Frame B Prompt`
                    : 'Step 1: Initial Prompt (End Frame B)'}
                </span>
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 font-mono">
                Generate First
              </span>
            </div>

            <p className="text-xs font-mono text-neutral-200 bg-black/40 p-2.5 rounded-lg border border-white/5 leading-relaxed selection:bg-pink-500/30">
              {initialPrompt}
            </p>

            <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-pink-500/20">
              <button
                type="button"
                onClick={() => {
                  onApplyInitialPrompt(initialPrompt, false);
                  onShowToast('✓ Loaded into Text-to-Image input');
                }}
                className="px-2.5 py-1.5 rounded-lg bg-pink-500/20 hover:bg-pink-500/30 text-pink-200 text-[11px] font-semibold flex items-center gap-1.5 transition border border-pink-500/30"
              >
                <ArrowRight className="w-3 h-3 text-pink-400" />
                <span>Set as Studio Prompt</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onApplyInitialPrompt(initialPrompt, true);
                }}
                className="px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white text-[11px] font-bold flex items-center gap-1.5 transition shadow shadow-pink-600/20"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>Generate End Frame Now</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  handleSaveQuickIdea({
                    title: matches.length > 2 ? `End Frame B (Idea ${currentPairNum})` : 'End Frame B Prompt',
                    prompt: initialPrompt,
                    type: 'initial',
                  });
                }}
                className="px-2.5 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-200 text-[11px] font-semibold flex items-center gap-1.5 transition border border-amber-500/30"
                title="Save this prompt to Quick Ideas list"
              >
                <Lightbulb className="w-3 h-3 text-amber-400" />
                <span>Save to Quick Ideas</span>
              </button>

              <button
                type="button"
                onClick={() => copyText(initialPrompt, initialId, 'End Frame Prompt')}
                className="ml-auto px-2 py-1 rounded-md bg-white/5 hover:bg-white/10 text-neutral-300 text-[10px] flex items-center gap-1 transition"
              >
                {copiedId === initialId ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>Copy</span>
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Reverse Edit Prompt (Start Frame A) */}
        {editPrompt && (
          <div className="p-3.5 rounded-xl bg-purple-950/20 border border-purple-500/40 shadow-sm flex flex-col gap-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                <Wand2 className="w-3.5 h-3.5 text-purple-400" />
                <span>
                  {matches.length > 2
                    ? `Idea ${currentPairNum} · Step 2: Start Frame A Edit`
                    : 'Step 2: Reverse Edit Prompt (Start Frame A)'}
                </span>
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-mono">
                Applied to End Frame
              </span>
            </div>

            <p className="text-xs font-mono text-neutral-200 bg-black/40 p-2.5 rounded-lg border border-white/5 leading-relaxed selection:bg-purple-500/30">
              {editPrompt}
            </p>

            <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-purple-500/20">
              <button
                type="button"
                onClick={() => {
                  onApplyEditPrompt(editPrompt, false);
                  onShowToast('✓ Loaded into Edit Prompt input');
                }}
                className="px-2.5 py-1.5 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 text-[11px] font-semibold flex items-center gap-1.5 transition border border-purple-500/30"
              >
                <ArrowRight className="w-3 h-3 text-purple-400" />
                <span>Set as Edit Prompt</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onApplyEditPrompt(editPrompt, true);
                }}
                disabled={!activeImage}
                title={!activeImage ? 'Generate or upload an image first to apply edit' : 'Run edit on active frame'}
                className="px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-[11px] font-bold flex items-center gap-1.5 transition shadow shadow-purple-600/20"
              >
                <Wand2 className="w-3 h-3" />
                <span>Run Edit on Active Frame</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  handleSaveQuickIdea({
                    title: matches.length > 2 ? `Reverse Edit A (Idea ${currentPairNum})` : 'Reverse Edit Prompt',
                    prompt: editPrompt,
                    type: 'edit',
                  });
                }}
                className="px-2.5 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-200 text-[11px] font-semibold flex items-center gap-1.5 transition border border-amber-500/30"
                title="Save this prompt to Quick Ideas list"
              >
                <Lightbulb className="w-3 h-3 text-amber-400" />
                <span>Save to Quick Ideas</span>
              </button>

              <button
                type="button"
                onClick={() => copyText(editPrompt, editId, 'Start Frame Edit Prompt')}
                className="ml-auto px-2 py-1 rounded-md bg-white/5 hover:bg-white/10 text-neutral-300 text-[10px] flex items-center gap-1 transition"
              >
                {copiedId === editId ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>Copy</span>
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Trailing text after last block
  if (cursor < content.length) {
    const trailing = content.slice(cursor).trim();
    if (trailing) {
      elements.push(
        <div
          key={`text-${cursor}`}
          className="text-xs leading-relaxed text-neutral-200 whitespace-pre-wrap space-y-1.5"
        >
          {trailing}
        </div>
      );
    }
  }

  return <div className="flex flex-col gap-3">{elements}</div>;
}
