import { Wand2, Dices, Upload } from 'lucide-react';
import type { KeyframeChatbotState } from './useKeyframeChatbot';
import { generateRandomizedIdeaPrompt } from './randomIdeas';

interface SuggestionPillsProps {
  studio: KeyframeChatbotState;
}

export function SuggestionPills({ studio }: SuggestionPillsProps) {
  const {
    currentPrompt,
    activeImage,
    onShowToast,
    onUploadImage,
    copilotFileInputRef,
    input,
    handleSendMessage,
    handleAskForReverseEdit,
  } = studio;

  return (
    <div className="px-6 py-2.5 bg-black/20 border-t border-white/5 overflow-x-auto flex items-center gap-2 no-scrollbar">
      <span className="text-[11px] text-neutral-500 flex-shrink-0 font-medium">Suggestions:</span>
      <button
        type="button"
        onClick={() => {
          const prompt = generateRandomizedIdeaPrompt();
          handleSendMessage(prompt);
          onShowToast('🎲 Rolled fresh random scenario idea prompt');
        }}
        className="text-[11px] text-pink-300 hover:text-white bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-pink-500/20 hover:from-pink-500/35 hover:to-purple-500/35 border border-pink-500/40 hover:border-pink-300 px-3 py-1 rounded-full whitespace-nowrap transition flex-shrink-0 font-semibold shadow-sm flex items-center gap-1.5"
        title="Roll a completely random, non-formulaic batch of 3 transformation scenarios"
      >
        <Dices className="w-3.5 h-3.5 text-pink-400" />
        <span>🎲 3 Random Ideas (Fresh Roll)</span>
      </button>
      <button
        type="button"
        onClick={() =>
          handleSendMessage(
            'Suggest 3 creative male-to-female transformation scenario ideas with maximum variety across settings, genres, wardrobe metamorphoses, and triggers. Avoid repetitive formulas or tropes. Provide paired Nano Banana 2 prompts for each.'
          )
        }
        className="text-[11px] text-neutral-300 hover:text-pink-300 bg-white/5 hover:bg-pink-500/10 border border-white/10 hover:border-pink-500/30 px-3 py-1 rounded-full whitespace-nowrap transition flex-shrink-0"
      >
        💡 3 Ideas (Diverse Variety)
      </button>
      {/* Hidden file input for uploading an image to copilot */}
      <input
        ref={copilotFileInputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) {
            if (onUploadImage) {
              onUploadImage(file);
            } else {
              handleAskForReverseEdit();
            }
          }
          e.target.value = '';
        }}
      />

      <button
        type="button"
        onClick={() => copilotFileInputRef.current?.click()}
        className="text-[11px] text-purple-300 hover:text-purple-200 bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/30 px-3 py-1 rounded-full whitespace-nowrap transition flex items-center gap-1.5 flex-shrink-0"
        title="Upload an image to studio to craft a matching Start Frame reverse prompt"
      >
        <Upload className="w-3 h-3 text-purple-400" />
        <span>Upload Image for Reverse Prompt</span>
      </button>

      {activeImage && (
        <button
          type="button"
          onClick={handleAskForReverseEdit}
          className="text-[11px] text-purple-300 hover:text-purple-200 bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/30 px-3 py-1 rounded-full whitespace-nowrap transition flex items-center gap-1.5 flex-shrink-0"
        >
          <Wand2 className="w-3 h-3 text-purple-400" />
          <span>Reverse Edit for Active Frame</span>
        </button>
      )}
      {currentPrompt.trim() && (
        <button
          type="button"
          onClick={() =>
            handleSendMessage(
              `Please improve my current studio prompt for Nano Banana 2 keyframe generation:\n"${currentPrompt}"`
            )
          }
          className="text-[11px] text-neutral-400 hover:text-pink-300 bg-white/5 hover:bg-pink-500/10 border border-white/5 hover:border-pink-500/30 px-3 py-1 rounded-full whitespace-nowrap transition flex-shrink-0"
        >
          ✨ Polish Current Studio Prompt
        </button>
      )}
      <button
        type="button"
        onClick={() =>
          handleSendMessage(
            'Use Google Image Search to search across all outfit examples (casual styles, athletic leotards, delicate lingerie, loungewear, uniforms, or formal gowns) and suggest 3 diverse wardrobe transformation concepts with matching pre-transformation male clothing.'
          )
        }
        className="text-[11px] text-pink-300 hover:text-pink-200 bg-pink-500/15 hover:bg-pink-500/25 border border-pink-500/30 px-3 py-1 rounded-full whitespace-nowrap transition flex-shrink-0"
      >
        👗 Search All Outfit Examples
      </button>
      <button
        type="button"
        onClick={() =>
          handleSendMessage(
            currentPrompt.trim()
              ? `Choreograph the shock, disbelief and humiliation reactions (poses, facial expressions, body language, onlooker reactions) for this scene and return an upgraded End Frame B prompt with matching Start Frame A reverse edit:\n"${currentPrompt}"`
              : 'Choreograph 3 distinct, visceral shock, disbelief and humiliation reaction setups for the transformed characters (crawling, trembling, clutching tight clothing, staring at new bodies) with onlooker reactions, and give a paired End Frame B prompt and Start Frame A reverse edit for each.'
          )
        }
        className="text-[11px] text-amber-300 hover:text-amber-200 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 px-3 py-1 rounded-full whitespace-nowrap transition flex-shrink-0"
        title="Choreograph poses, reactions and onlookers (uses your current studio prompt if present)"
      >
        🎭 Choreograph Reactions
      </button>
    </div>
  );
}
