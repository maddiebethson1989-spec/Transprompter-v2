import { ImageSize, AspectRatio } from '../../types';

export interface KeyframeChatbotProps {
  currentPrompt: string;
  currentEditPrompt: string;
  activeImage: string | null;
  activeImageMime?: string;
  imageSize: ImageSize;
  aspectRatio: AspectRatio;
  onApplyInitialPrompt: (promptText: string, autoGenerate?: boolean) => void;
  onApplyEditPrompt: (editPromptText: string, autoRunEdit?: boolean) => void;
  onShowToast: (msg: string) => void;
  onClose?: () => void;
  isEmbedded?: boolean;
  initialQuery?: string | null;
  onClearInitialQuery?: () => void;
  onUploadImage?: (file: File) => void;
}

export interface QuickIdea {
  id: string;
  title: string;
  prompt: string;
  type: 'initial' | 'edit' | 'custom';
  timestamp: number;
}


