import { Info } from 'lucide-react';
import type { KeyframeChatbotState } from './useKeyframeChatbot';

interface MethodologyGuideProps {
  studio: KeyframeChatbotState;
}

export function MethodologyGuide({ studio }: MethodologyGuideProps) {
  return (
    <div className="p-3.5 bg-black/60 border-b border-pink-500/20 text-xs text-neutral-300 space-y-2 animate-in fade-in duration-200">
      <div className="flex items-start gap-2 text-pink-300 font-semibold">
        <Info className="w-4 h-4 flex-shrink-0 text-pink-400 mt-0.5" />
        <span>Golden Rules for Consistent Keyframe Generation:</span>
      </div>
      <ul className="list-disc pl-5 space-y-1 text-[11px] text-neutral-300">
        <li>
          <strong>Always Male to Female:</strong> Transformations focus on men turning into women.
        </li>
        <li>
          <strong>Always Shock, Disbelief &amp; Humiliation:</strong> Transformed characters react with extreme shock,
          horror, crawling on the ground, or freaking out over tight underwear and female anatomy, while bystanders or a
          sorceress giggle/smirk.
        </li>
        <li>
          <strong>Prompt End Frame First:</strong> Synthesize the rich, colorful, feminine End Frame first with{' '}
          <code className="text-pink-300">4k, hdr, photorealistic</code>.
        </li>
        <li>
          <strong>Start Frame as Reverse Edit:</strong> Apply an edit prompt to the generated image:{' '}
          <em className="text-purple-300">
            "Show [them/her] as young adult men before being transformed. Standing in same location, matching male
            outfits in color, slightly taller/larger, same hair color/texture, background characters talking
            casually..."
          </em>
        </li>
        <li>
          <strong>Characteristics That Stay The Same:</strong> The following characteristics ALWAYS stay the same when
          transforming: age, ethnicity, skin tone, hair color, and hair texture.
        </li>
        <li>
          <strong>Height &amp; Build Morphology:</strong> Male versions are typically taller and broader than their
          female versions (when transitioning into women, characters become shorter and more petite/feminine).
        </li>
        <li>
          <strong>Uniformed Matching Outfits:</strong> If multiple characters transform into uniformed women (like
          ballerinas or gymnasts), the women wear matching outfits. Pre-transformation male clothing does not have to
          match in color and pattern (casual gym clothes).
        </li>
        <li>
          <strong>Clothing Transformation Rule:</strong> Male clothing almost always transforms into a female equivalent
          with the same color/pattern (e.g. black shorts → black skirt, white male t-shirt with logo → white female
          tanktop with same logo, blue boxer briefs → blue bra and panty set, red swim trunks → red swimsuit/bikini).
          Uniform-type outfits like ballerina leotards or gymnastics uniforms are the exception: If multiple characters
          transform into uniformed women (like ballerinas or gymnasts), the women wear matching outfits.
          Pre-transformation male clothing does not have to match in color and pattern (casual gym clothes).
        </li>
        <li>
          <strong>Character-Attributed Dialogue:</strong> Whenever dialogue is included, always specify which character
          is speaking.
        </li>
      </ul>
    </div>
  );
}
