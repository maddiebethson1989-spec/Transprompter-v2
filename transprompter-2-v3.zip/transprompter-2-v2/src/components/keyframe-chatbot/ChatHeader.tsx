import { Sparkles, Wand2, HelpCircle, ChevronDown, ChevronUp, Zap, X, Bot, Lightbulb } from 'lucide-react';
import type { KeyframeChatbotState } from './useKeyframeChatbot';

interface ChatHeaderProps {
  studio: KeyframeChatbotState;
}

export function ChatHeader({ studio }: ChatHeaderProps) {
  const {
    activeImage,
    imageSize,
    aspectRatio,
    onClose,
    selectedModel,
    setSelectedModel,
    showMethodologyGuide,
    setShowMethodologyGuide,
    showQuickIdeas,
    setShowQuickIdeas,
    quickIdeas,
    handleAskForReverseEdit,
  } = studio;


  return (
    <div className="p-5 sm:p-6 bg-gradient-to-b from-[#131220] to-[#0e0e17] border-b border-white/10">
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400 flex-shrink-0">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight flex items-center gap-2">
              Keyframe Director
            </h2>
            <p className="text-xs text-neutral-400">
              One assistant for scenarios, wardrobe, reactions &amp; reverse edit prompts for Nano Banana 2.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
          {/* Model Selector Affordance: 3.8 Flash and 3.5 Flash matching VFX Director */}
          <div className="flex items-center gap-2 bg-[#09090f] p-1.5 rounded-xl border border-white/10 w-full sm:w-auto">
            <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-neutral-400 px-2 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-pink-400" />
              Model:
            </span>

            <div className="flex items-center gap-1.5 flex-1 sm:flex-initial">
              <button
                type="button"
                onClick={() => setSelectedModel('gemini-3.8-flash')}
                className={`flex-1 sm:flex-initial px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
                  selectedModel === 'gemini-3.8-flash'
                    ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-md shadow-pink-600/30'
                    : 'text-neutral-400 hover:text-white hover:bg-white/5'
                }`}
                title="Latest frontier flash model (default) with advanced multimodal vision and directing capability"
              >
                <Sparkles className="w-3.5 h-3.5 text-pink-300 flex-shrink-0" />
                <span>3.8 Flash</span>
                <span className="text-[9px] bg-white/20 px-1 rounded flex-shrink-0 font-mono">Latest</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedModel('gemini-3.5-flash')}
                className={`flex-1 sm:flex-initial px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
                  selectedModel === 'gemini-3.5-flash'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'text-neutral-400 hover:text-white hover:bg-white/5'
                }`}
                title="Gemini 3.5 Flash: Standard production flash baseline"
              >
                <Zap className="w-3.5 h-3.5 text-indigo-300 flex-shrink-0" />
                <span>3.5 Flash</span>
              </button>
            </div>
          </div>

          {/* Quick Action Controls in Header */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowQuickIdeas(!showQuickIdeas)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 border ${
                showQuickIdeas
                  ? 'bg-gradient-to-r from-amber-500/25 to-pink-500/25 text-amber-300 border-amber-500/50 shadow-md shadow-amber-500/10'
                  : 'text-neutral-300 hover:text-white hover:bg-white/5 bg-[#09090f] border-white/10'
              }`}
              title="Open saved Quick Ideas"
            >
              <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
              <span>Quick Ideas</span>
              {quickIdeas.length > 0 && (
                <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-amber-400/20 text-amber-300 border border-amber-400/30 font-mono font-bold leading-none">
                  {quickIdeas.length}
                </span>
              )}
              {showQuickIdeas ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>

            <button
              type="button"
              onClick={() => setShowMethodologyGuide(!showMethodologyGuide)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 border ${
                showMethodologyGuide
                  ? 'bg-purple-500/25 text-purple-300 border-purple-500/30'
                  : 'text-neutral-400 hover:text-white hover:bg-white/5 bg-[#09090f] border-white/10'
              }`}
              title="Toggle methodology instructions"
            >
              <HelpCircle className="w-3.5 h-3.5 text-purple-400" />
              <span className="hidden sm:inline">Rules</span>
              {showMethodologyGuide ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>

            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition ml-auto bg-[#09090f] border border-white/10"
                title="Close copilot"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Studio Active Status Ribbon */}
      {activeImage && (
        <div className="mt-3.5 pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-emerald-300 font-mono text-[11px]">
              Active Studio Frame Synced ({imageSize} · {aspectRatio})
            </span>
          </div>
          <button
            type="button"
            onClick={handleAskForReverseEdit}
            className="px-3 py-1 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/40 text-[11px] font-semibold transition flex items-center gap-1.5 shadow"
            title="Inspect active image in studio and write matching male pre-transformation edit prompt"
          >
            <Wand2 className="w-3 h-3 text-purple-300" />
            <span>Generate Reverse Edit for Active Frame</span>
          </button>
        </div>
      )}
    </div>
  );
}
