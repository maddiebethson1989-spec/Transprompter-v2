import { Sparkles, Loader2, Copy, Check, RotateCcw, X, Pencil, Bot, User, Lightbulb } from 'lucide-react';
import { renderMessageContent } from './MessageContent';
import type { KeyframeChatbotState } from './useKeyframeChatbot';

interface MessageThreadProps {
  studio: KeyframeChatbotState;
}

export function MessageThread({ studio }: MessageThreadProps) {
  const {
    selectedModel,
    messages,
    loading,
    copiedId,
    editingMessageId,
    editingContent,
    setEditingContent,
    reloadingMessageId,
    messagesEndRef,
    directorTitle,
    copyText,
    handleSaveQuickIdea,
    handleStartEdit,
    handleCancelEdit,
    handleSaveEditedMessage,
    handleReloadAnswer,
  } = studio;


  return (
    <div ref={messagesEndRef} className="flex-1 max-h-[500px] overflow-y-auto p-4 sm:p-6 space-y-4">
      {messages.map((m) => {
        const isUser = m.role === 'user';
        return (
          <div key={m.id} className={`flex gap-3 max-w-3xl ${isUser ? 'ml-auto flex-row-reverse' : 'mr-auto w-full'}`}>
            {/* Avatar */}
            <div
              className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 text-xs font-bold ${
                isUser
                  ? 'bg-gradient-to-tr from-pink-500 to-purple-600 text-white'
                  : 'bg-[#1a1a28] border border-white/10 text-pink-400'
              }`}
            >
              {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>

            {/* Message Bubble */}
            <div
              className={`rounded-2xl p-4 text-sm leading-relaxed ${
                isUser
                  ? 'bg-gradient-to-r from-pink-600/90 to-purple-700/90 text-white shadow-lg shadow-pink-900/20 w-full sm:w-auto'
                  : 'bg-[#0e0e17] border border-white/10 text-neutral-200 w-full'
              }`}
            >
              {/* Header for User Messages with Quick Ideas & Edit Button */}
              {isUser && (
                <div className="flex items-center justify-between gap-3 mb-2 pb-1.5 border-b border-white/15 text-[11px] text-pink-200">
                  <span className="font-semibold flex items-center gap-1">
                    <span>Your Prompt</span>
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() =>
                        handleSaveQuickIdea({
                          title: 'User Prompt',
                          prompt: m.content,
                          type: 'custom',
                        })
                      }
                      className="opacity-85 hover:opacity-100 hover:text-white transition flex items-center gap-1 text-[10px] bg-black/30 hover:bg-black/50 px-2 py-0.5 rounded-md border border-white/10 text-amber-300 hover:text-amber-200"
                      title="Save your prompt to Quick Ideas list"
                    >
                      <Lightbulb className="w-2.5 h-2.5 text-amber-400" />
                      <span>Save to Quick Ideas</span>
                    </button>
                    {editingMessageId !== m.id && (
                      <button
                        type="button"
                        onClick={() => handleStartEdit(m)}
                        disabled={loading || reloadingMessageId !== null}
                        className="opacity-80 hover:opacity-100 hover:text-white transition flex items-center gap-1 text-[10px] bg-black/30 hover:bg-black/50 px-2 py-0.5 rounded-md border border-white/10"
                        title="Edit prompt and regenerate answer"
                      >
                        <Pencil className="w-2.5 h-2.5" />
                        <span>Edit Prompt</span>
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Header for Assistant Messages */}
              {!isUser && (
                <div className="flex items-center justify-between gap-4 mb-2 pb-2 border-b border-white/5">
                  <span className="text-[11px] font-semibold text-pink-300 flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3" />
                    {directorTitle}
                  </span>
                  <span className="text-[10px] font-mono text-neutral-500">{m.modelUsed || selectedModel}</span>
                </div>
              )}

              {/* User message inline edit form vs normal text display */}
              {isUser && editingMessageId === m.id ? (
                <div className="space-y-2 mt-1">
                  <textarea
                    value={editingContent}
                    onChange={(e) => setEditingContent(e.target.value)}
                    onKeyDown={(e) => {
                      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
                        e.preventDefault();
                        handleSaveEditedMessage(m.id);
                      }
                    }}
                    rows={3}
                    className="w-full bg-black/50 border border-white/20 rounded-xl p-2.5 text-xs text-white placeholder-neutral-400 focus:outline-none focus:border-pink-300 focus:ring-1 focus:ring-pink-300 font-sans leading-relaxed"
                    autoFocus
                  />
                  <div className="flex items-center justify-end gap-2 text-xs">
                    <button
                      type="button"
                      onClick={handleCancelEdit}
                      className="px-2.5 py-1 rounded-lg text-[10px] text-neutral-300 hover:text-white bg-black/40 hover:bg-black/60 transition flex items-center gap-1 border border-white/10"
                    >
                      <X className="w-3 h-3" />
                      <span>Cancel</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSaveEditedMessage(m.id)}
                      disabled={!editingContent.trim() || loading}
                      className="px-3 py-1 rounded-lg text-[10px] font-bold text-white bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 transition shadow flex items-center gap-1 disabled:opacity-50"
                    >
                      <Check className="w-3 h-3" />
                      <span>Save &amp; Resubmit</span>
                    </button>
                  </div>
                </div>
              ) : isUser ? (
                <div className="whitespace-pre-wrap font-sans break-words">{m.content}</div>
              ) : (
                <>
                  {renderMessageContent(studio, m)}
                  {/* Visual & Image Search Grounding Badges */}
                  {Array.isArray(m.searchQueries) && m.searchQueries.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-white/5 flex flex-wrap items-center gap-1.5">
                      <span className="text-[10px] text-pink-400 font-medium flex items-center gap-1">
                        <Sparkles className="w-2.5 h-2.5" />
                        Visual / Image Search Grounding:
                      </span>
                      {m.searchQueries.filter(Boolean).map((q, qIdx) => (
                        <span
                          key={qIdx}
                          className="text-[10px] font-mono bg-pink-500/10 text-pink-300 border border-pink-500/20 px-2 py-0.5 rounded-full"
                        >
                          "{typeof q === 'string' ? q : String(q)}"
                        </span>
                      ))}
                    </div>
                  )}
                </>
              )}

              {/* Actions for Assistant Messages: Reload & Copy */}
              {!isUser && m.id !== 'welcome' && (
                <div className="mt-3 pt-2 border-t border-white/5 flex flex-wrap items-center gap-2 justify-end">
                  <button
                    onClick={() => handleReloadAnswer(m.id)}
                    disabled={loading || reloadingMessageId !== null}
                    className="text-[11px] font-medium text-neutral-400 hover:text-pink-300 px-2 py-1 rounded bg-white/5 hover:bg-white/10 transition flex items-center gap-1 disabled:opacity-40"
                    title="Reload this answer with a fresh response from Gemini"
                  >
                    <RotateCcw
                      className={`w-3 h-3 ${reloadingMessageId === m.id ? 'animate-spin text-pink-400' : ''}`}
                    />
                    <span>{reloadingMessageId === m.id ? 'Reloading…' : 'Reload Answer'}</span>
                  </button>

                  <button
                    onClick={() => copyText(m.content, m.id, 'Response')}
                    className="text-[11px] font-medium text-neutral-400 hover:text-white px-2 py-1 rounded bg-white/5 hover:bg-white/10 transition flex items-center gap-1"
                    title="Copy response"
                  >
                    {copiedId === m.id ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
          </div>
        );
      })}

      {loading && (
        <div className="flex gap-3 max-w-xl mr-auto">
          <div className="w-8 h-8 rounded-lg bg-[#1a1a28] border border-white/10 text-pink-400 flex items-center justify-center">
            <Loader2 className="w-4 h-4 animate-spin text-pink-400" />
          </div>
          <div className="rounded-2xl p-4 bg-[#0e0e17] border border-white/10 text-neutral-400 text-xs flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-pink-400 animate-ping" />
            <span>
              {selectedModel} ({directorTitle}) is directing…
            </span>
          </div>
        </div>
      )}

      <div ref={messagesEndRef} />
    </div>
  );
}
