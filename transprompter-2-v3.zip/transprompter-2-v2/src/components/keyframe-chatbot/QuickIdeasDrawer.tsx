import React, { useState } from 'react';
import {
  Lightbulb,
  X,
  Plus,
  Trash2,
  Copy,
  Check,
  ArrowRight,
  Wand2,
  MessageSquare,
  Search,
  Sparkles,
  Bookmark,
  Calendar,
} from 'lucide-react';
import type { KeyframeChatbotState } from './useKeyframeChatbot';
import type { QuickIdea } from './types';

interface QuickIdeasDrawerProps {
  studio: KeyframeChatbotState;
}

export function QuickIdeasDrawer({ studio }: QuickIdeasDrawerProps) {
  const {
    setShowQuickIdeas,
    quickIdeas,
    handleSaveQuickIdea,
    handleDeleteQuickIdea,
    handleClearQuickIdeas,
    handleApplyQuickIdea,
    copyText,
    copiedId,
    onShowToast,
  } = studio;

  const [searchQuery, setSearchQuery] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newPrompt, setNewPrompt] = useState('');
  const [newType, setNewType] = useState<'initial' | 'edit' | 'custom'>('custom');
  const [confirmClear, setConfirmClear] = useState(false);

  // Filter ideas
  const filteredIdeas = quickIdeas.filter((idea) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return idea.title.toLowerCase().includes(q) || idea.prompt.toLowerCase().includes(q);
  });

  const handleAddNew = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPrompt.trim()) return;

    handleSaveQuickIdea({
      title: newTitle.trim() || undefined,
      prompt: newPrompt.trim(),
      type: newType,
    });

    setNewTitle('');
    setNewPrompt('');
    setShowAddForm(false);
  };

  const handlePreloadStarters = () => {
    const starters: { title: string; prompt: string; type: 'initial' | 'edit' | 'custom' }[] = [
      {
        title: 'Runway Gala Metamorphosis (End Frame)',
        prompt:
          '4k, hdr, photorealistic, cinematic lighting, an astonished elegant young woman with flowing caramel brown hair in a lavish shimmering rose-gold evening gown on a dazzling Paris fashion gala runway, trembling hands raised in disbelief at her new feminine curves, high heels, delicate crystal necklace, surrounding models and photographers cheering in background.',
        type: 'initial',
      },
      {
        title: 'Runway Gala Reverse Edit (Start Frame)',
        prompt:
          'Transform the woman back into a tall 24-year-old athletic male model with short textured brown hair in a tailored black tuxedo and white dress shirt, same runway setting, confident professional pose, matching warm color palette.',
        type: 'edit',
      },
      {
        title: 'Athletic Track Relay Shift',
        prompt:
          '4k, photorealistic, an athletic young woman with blonde high ponytail gasping in shock on a sunny stadium track, wearing a vibrant turquoise and white running leotard and sneakers, staring down at her slender arms and feminine frame in absolute disbelief as teammates watch.',
        type: 'initial',
      },
    ];

    starters.forEach((item) => handleSaveQuickIdea(item));
    onShowToast('✓ Added 3 starter Quick Ideas');
  };

  const formatTimestamp = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="p-4 sm:p-5 bg-gradient-to-b from-[#161224] to-[#0c0b16] border-b border-amber-500/30 max-h-[75vh] overflow-y-auto space-y-4 animate-in fade-in duration-200 scrollbar-thin">
      {/* Header */}
      <div className="flex items-start justify-between gap-3 pb-3 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-amber-500/30 via-pink-500/30 to-purple-600/30 border border-amber-500/40 text-amber-300 shadow-md shadow-amber-500/10">
            <Lightbulb className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                Saved Quick Ideas
              </h3>
              <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30">
                {quickIdeas.length} {quickIdeas.length === 1 ? 'Idea' : 'Ideas'} Saved
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-0.5">
              Saved user-generated prompts and copilot scenarios. 1-click apply to Studio, Edit, or Chat.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowAddForm(!showAddForm)}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 border ${
              showAddForm
                ? 'bg-amber-500/30 text-amber-200 border-amber-500/50'
                : 'bg-white/5 hover:bg-white/10 text-neutral-300 border-white/10'
            }`}
            title="Manually create a new quick idea"
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Add Idea</span>
          </button>

          {quickIdeas.length > 0 && (
            confirmClear ? (
              <div className="flex items-center gap-1 bg-red-950/60 p-1 rounded-lg border border-red-500/40">
                <span className="text-[10px] text-red-200 px-1 font-semibold">Delete all?</span>
                <button
                  type="button"
                  onClick={() => {
                    handleClearQuickIdeas();
                    setConfirmClear(false);
                  }}
                  className="px-2 py-0.5 rounded bg-red-600 hover:bg-red-500 text-white text-[10px] font-bold"
                >
                  Yes
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmClear(false)}
                  className="px-2 py-0.5 rounded bg-white/10 hover:bg-white/20 text-neutral-300 text-[10px]"
                >
                  No
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmClear(true)}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-red-400 hover:bg-red-500/10 border border-transparent hover:border-red-500/20 transition"
                title="Clear all saved quick ideas"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )
          )}

          <button
            type="button"
            onClick={() => setShowQuickIdeas(false)}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition ml-1"
            title="Close Quick Ideas drawer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Add Custom Idea Form */}
      {showAddForm && (
        <form
          onSubmit={handleAddNew}
          className="p-3.5 bg-black/40 rounded-xl border border-amber-500/30 space-y-3 animate-in fade-in duration-150"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
              <Bookmark className="w-3.5 h-3.5" />
              Create Custom Quick Idea
            </span>
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-[10px] text-neutral-400">Type:</span>
              <button
                type="button"
                onClick={() => setNewType('initial')}
                className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                  newType === 'initial'
                    ? 'bg-pink-500/30 text-pink-200 border-pink-500/50'
                    : 'bg-white/5 text-neutral-400 border-white/10'
                }`}
              >
                End Frame B
              </button>
              <button
                type="button"
                onClick={() => setNewType('edit')}
                className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                  newType === 'edit'
                    ? 'bg-purple-500/30 text-purple-200 border-purple-500/50'
                    : 'bg-white/5 text-neutral-400 border-white/10'
                }`}
              >
                Reverse Edit A
              </button>
              <button
                type="button"
                onClick={() => setNewType('custom')}
                className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                  newType === 'custom'
                    ? 'bg-amber-500/30 text-amber-200 border-amber-500/50'
                    : 'bg-white/5 text-neutral-400 border-white/10'
                }`}
              >
                Custom
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <div className="sm:col-span-1">
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Title (optional, e.g. Cyberpunk Gala)"
                className="w-full bg-[#12111d] border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400/60"
              />
            </div>
            <div className="sm:col-span-2">
              <textarea
                value={newPrompt}
                onChange={(e) => setNewPrompt(e.target.value)}
                placeholder="Prompt text (e.g. 4k, photorealistic, young woman in elegant gown...)"
                rows={2}
                className="w-full bg-[#12111d] border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400/60 font-mono"
                required
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-2.5 py-1 rounded-lg text-xs text-neutral-400 hover:text-white hover:bg-white/5"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!newPrompt.trim()}
              className="px-3.5 py-1 rounded-lg text-xs font-bold text-black bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 transition shadow disabled:opacity-50"
            >
              Save Idea
            </button>
          </div>
        </form>
      )}

      {/* Search / Filter Bar (if 2+ ideas) */}
      {quickIdeas.length > 2 && (
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search saved ideas by title or prompt keyword..."
            className="w-full bg-black/40 border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400/50"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2 text-xs text-neutral-400 hover:text-white"
            >
              Clear
            </button>
          )}
        </div>
      )}

      {/* Ideas List or Empty State */}
      {quickIdeas.length === 0 ? (
        <div className="py-8 px-4 rounded-2xl bg-white/[0.02] border border-dashed border-white/10 text-center flex flex-col items-center justify-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-300">
            <Lightbulb className="w-6 h-6" />
          </div>
          <div className="max-w-md">
            <h4 className="text-sm font-bold text-white mb-1">No Quick Ideas Saved Yet</h4>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Whenever you or the Copilot generate prompts in chat, click{' '}
              <span className="text-amber-300 font-semibold">"Save to Quick Ideas"</span> on any prompt block to store
              it here for fast 1-click loading!
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
            <button
              type="button"
              onClick={() => setShowAddForm(true)}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-200 text-xs font-semibold transition flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create New Idea</span>
            </button>
            <button
              type="button"
              onClick={handlePreloadStarters}
              className="px-3.5 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/40 text-purple-200 text-xs font-semibold transition flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-300" />
              <span>Load 3 Sample Starter Ideas</span>
            </button>
          </div>
        </div>
      ) : filteredIdeas.length === 0 ? (
        <div className="py-6 text-center text-xs text-neutral-400">
          No ideas matching <span className="text-white">"{searchQuery}"</span>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredIdeas.map((idea) => {
            const isInitial = idea.type === 'initial';
            const isEdit = idea.type === 'edit';

            return (
              <div
                key={idea.id}
                className={`p-3.5 rounded-xl border transition flex flex-col gap-2.5 ${
                  isInitial
                    ? 'bg-pink-950/15 border-pink-500/30 hover:border-pink-500/50'
                    : isEdit
                    ? 'bg-purple-950/15 border-purple-500/30 hover:border-purple-500/50'
                    : 'bg-[#100f1c] border-white/10 hover:border-amber-500/40'
                }`}
              >
                {/* Item Top Bar */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-mono uppercase tracking-wider flex-shrink-0 ${
                        isInitial
                          ? 'bg-pink-500/20 text-pink-300 border border-pink-500/30'
                          : isEdit
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}
                    >
                      {isInitial ? 'End Frame B' : isEdit ? 'Reverse Edit A' : 'Quick Idea'}
                    </span>
                    <span className="text-xs font-bold text-white truncate" title={idea.title}>
                      {idea.title}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0 text-[10px] text-neutral-500">
                    <span className="flex items-center gap-1 font-mono">
                      <Calendar className="w-2.5 h-2.5" />
                      {formatTimestamp(idea.timestamp)}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleDeleteQuickIdea(idea.id)}
                      className="p-1 rounded text-neutral-400 hover:text-red-400 hover:bg-red-500/10 transition"
                      title="Delete idea"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {/* Prompt Text Preview */}
                <p className="text-xs font-mono text-neutral-200 bg-black/50 p-2.5 rounded-lg border border-white/5 leading-relaxed selection:bg-amber-500/30 whitespace-pre-wrap max-h-36 overflow-y-auto scrollbar-thin">
                  {idea.prompt}
                </p>

                {/* Action Buttons */}
                <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-white/5">
                  <button
                    type="button"
                    onClick={() => handleApplyQuickIdea(idea, 'initial')}
                    className="px-2.5 py-1 rounded-lg bg-pink-500/20 hover:bg-pink-500/30 text-pink-200 text-[11px] font-semibold flex items-center gap-1.5 transition border border-pink-500/30"
                    title="Load into Studio prompt (Text-to-Image / End Frame B)"
                  >
                    <ArrowRight className="w-3 h-3 text-pink-400" />
                    <span>Set as Studio Prompt</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleApplyQuickIdea(idea, 'edit')}
                    className="px-2.5 py-1 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 text-[11px] font-semibold flex items-center gap-1.5 transition border border-purple-500/30"
                    title="Load into Edit prompt (Image-to-Image / Start Frame A)"
                  >
                    <Wand2 className="w-3 h-3 text-purple-400" />
                    <span>Set as Edit Prompt</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleApplyQuickIdea(idea, 'chat')}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-neutral-300 text-[11px] font-semibold flex items-center gap-1.5 transition border border-white/10"
                    title="Load into Copilot chat input to expand or modify"
                  >
                    <MessageSquare className="w-3 h-3 text-amber-400" />
                    <span>Send to Chat</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => copyText(idea.prompt, idea.id, 'Prompt')}
                    className="ml-auto px-2 py-1 rounded-md bg-white/5 hover:bg-white/10 text-neutral-300 text-[10px] flex items-center gap-1 transition"
                  >
                    {copiedId === idea.id ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                    <span>Copy</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
