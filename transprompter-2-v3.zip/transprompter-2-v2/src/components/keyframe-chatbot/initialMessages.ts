import { ChatMsg } from './chatMsg';

export const DIRECTOR_TITLE = 'Keyframe Director';

export const INITIAL_MESSAGES: ChatMsg[] = [
  {
    id: 'init-director',
    role: 'assistant',
    content: `Welcome to the Keyframe Director! I'm one assistant for the whole workflow: original Male-to-Female transformation scenarios, wardrobe research (I search real outfit examples), shock-and-humiliation reaction choreography, and matching Start Frame reverse edit prompts — all tuned for Nano Banana 2.\n\nClick **"🎲 3 Random Ideas"** for a fresh, non-formulaic batch, ask for an outfit, a pose or a reaction tweak, or generate an End Frame and let me write the reverse edit for it.`,
    timestamp: Date.now(),
    modelUsed: 'gemini-3.8-flash',
  },
];
