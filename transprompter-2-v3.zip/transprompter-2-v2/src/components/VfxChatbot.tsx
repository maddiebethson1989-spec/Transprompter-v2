import React, { useState, useRef, useEffect } from 'react';
import {
  GeminiChatModel,
  ChatMessage,
  KeyframeImage,
  SplitPromptResult,
} from '../types';
import { safeFetchJson } from '../utils/safeApi';
import {
  Send,
  Bot,
  User,
  Sparkles,
  Zap,
  Copy,
  Check,
  Trash2,
  ArrowRight,
  Loader2,
  Film,
  Volume2,
  Layers,
  MessageSquareQuote,
  Pencil,
  RotateCcw,
  X,
} from 'lucide-react';

interface VfxChatbotProps {
  startImage?: KeyframeImage | null;
  endImage?: KeyframeImage | null;
  basePrompt?: string;
  enhancedResult?: SplitPromptResult | null;
  onInsertIntoPrompt: (text: string) => void;
  onShowToast: (msg: string) => void;
}

const DIRECTOR_TITLE = 'WAN 3.0 Video Director';

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'init-vfx-director',
    role: 'model',
    content: `Welcome to the WAN 3.0 Video Director! I'm your single copilot for the entire video generation workflow: cinematic camera blocking & lighting, fluid morph kinematics, dialogue delivery & micro-expressions, timestamped audio foley cues, and prompt optimization.\n\nUse the quick direct pills below to focus on a specific aspect, or ask me anything about bridging Frame A to Frame B!`,
    timestamp: Date.now(),
    modelUsed: 'gemini-3.8-flash',
  },
];

export const VfxChatbot: React.FC<VfxChatbotProps> = ({
  startImage,
  endImage,
  basePrompt,
  enhancedResult,
  onInsertIntoPrompt,
  onShowToast,
}) => {
  // Single unified thread persisted under v4. Legacy per-role sessions (v3) are cleared.
  const VFX_STORAGE_KEY = 'transprompter_vfx_director_thread_v4';
  const LEGACY_VFX_STORAGE_KEY = 'transprompter_vfx_director_sessions_v3';

  const [selectedModel, setSelectedModel] = useState<GeminiChatModel>('gemini-3.8-flash');
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      localStorage.removeItem(LEGACY_VFX_STORAGE_KEY);
      const saved = localStorage.getItem(VFX_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Failed to restore VFX Director thread:', e);
    }
    return INITIAL_MESSAGES;
  });

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // States for Prompt Editing & Answer Reloading
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingContent, setEditingContent] = useState('');
  const [reloadingMessageId, setReloadingMessageId] = useState<string | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll on new messages or loading
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  // Persist single thread to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem(VFX_STORAGE_KEY, JSON.stringify(messages));
    } catch (err) {
      console.warn('Failed to cache VFX Director thread:', err);
    }
  }, [messages]);

  const handleSend = async (customText?: string) => {
    const textToSend = (customText || input).trim();
    if (!textToSend || loading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: textToSend,
      timestamp: Date.now(),
    };

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInput('');
    setLoading(true);

    try {
      // Format history for multi-turn chat
      const payloadMessages = newHistory.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      // Assemble pipeline context for the model to inspect
      const pipelineContext = {
        hasStartImage: Boolean(startImage),
        hasEndImage: Boolean(endImage),
        startImage: startImage ? { data: startImage.data, mimeType: startImage.mimeType } : null,
        endImage: endImage ? { data: endImage.data, mimeType: endImage.mimeType } : null,
        basePrompt: basePrompt || '',
        enhancedPrompt: enhancedResult?.full || '',
      };

      const data = await safeFetchJson<{
        success: boolean;
        reply: string;
        modelUsed?: string;
        searchQueries?: string[];
        error?: string;
      }>('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: payloadMessages,
          model: selectedModel,
          pipelineContext,
        }),
      });

      if (!data.success) {
        throw new Error(data.error || 'Failed to get response from Gemini');
      }

      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        role: 'model',
        content: data.reply,
        timestamp: Date.now(),
        modelUsed: data.modelUsed || selectedModel,
        searchQueries: data.searchQueries,
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'model',
        content: `Error: ${err.message || 'Unable to connect to Gemini API'}. Please try again.`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  // Edit user prompt and regenerate answer
  const handleStartEdit = (msg: ChatMessage) => {
    setEditingMessageId(msg.id);
    setEditingContent(msg.content);
  };

  const handleCancelEdit = () => {
    setEditingMessageId(null);
    setEditingContent('');
  };

  const handleSaveEditedMessage = async (msgId: string) => {
    const trimmed = editingContent.trim();
    if (!trimmed || loading) return;

    const targetIndex = messages.findIndex((m) => m.id === msgId);
    if (targetIndex === -1) return;

    const updatedUserMsg: ChatMessage = {
      ...messages[targetIndex],
      content: trimmed,
      timestamp: Date.now(),
    };

    // Slice history up to and including the updated user message
    const truncatedHistory = [...messages.slice(0, targetIndex), updatedUserMsg];
    setMessages(truncatedHistory);
    setEditingMessageId(null);
    setEditingContent('');
    setLoading(true);

    try {
      const payloadMessages = truncatedHistory.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const pipelineContext = {
        hasStartImage: Boolean(startImage),
        hasEndImage: Boolean(endImage),
        startImage: startImage ? { data: startImage.data, mimeType: startImage.mimeType } : null,
        endImage: endImage ? { data: endImage.data, mimeType: endImage.mimeType } : null,
        basePrompt: basePrompt || '',
        enhancedPrompt: enhancedResult?.full || '',
      };

      const data = await safeFetchJson<{
        success: boolean;
        reply: string;
        modelUsed?: string;
        searchQueries?: string[];
        error?: string;
      }>('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: payloadMessages,
          model: selectedModel,
          pipelineContext,
        }),
      });

      if (!data.success) {
        throw new Error(data.error || 'Failed to get response from Gemini');
      }

      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        role: 'model',
        content: data.reply,
        timestamp: Date.now(),
        modelUsed: data.modelUsed || selectedModel,
        searchQueries: data.searchQueries,
      };

      setMessages((prev) => [...prev, botMsg]);
      onShowToast('✓ Prompt updated & response regenerated');
    } catch (err: any) {
      console.error('Chat edit error:', err);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'model',
        content: `Error: ${err.message || 'Unable to connect to Gemini API'}. Please try again.`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMsg]);
      onShowToast('Error regenerating response');
    } finally {
      setLoading(false);
    }
  };

  // Reload an individual answer with a fresh model reply
  const handleReloadAnswer = async (assistantMsgId: string) => {
    if (loading || reloadingMessageId) return;

    const targetIndex = messages.findIndex((m) => m.id === assistantMsgId);
    if (targetIndex === -1) return;

    const historyBefore = messages.slice(0, targetIndex);
    if (historyBefore.length === 0) return;

    setReloadingMessageId(assistantMsgId);

    try {
      const payloadMessages = historyBefore.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const pipelineContext = {
        hasStartImage: Boolean(startImage),
        hasEndImage: Boolean(endImage),
        startImage: startImage ? { data: startImage.data, mimeType: startImage.mimeType } : null,
        endImage: endImage ? { data: endImage.data, mimeType: endImage.mimeType } : null,
        basePrompt: basePrompt || '',
        enhancedPrompt: enhancedResult?.full || '',
      };

      const data = await safeFetchJson<{
        success: boolean;
        reply: string;
        modelUsed?: string;
        searchQueries?: string[];
        error?: string;
      }>('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: payloadMessages,
          model: selectedModel,
          pipelineContext,
        }),
      });

      if (!data.success) {
        throw new Error(data.error || 'Failed to reload response from Gemini');
      }

      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === assistantMsgId
            ? {
                ...msg,
                content: data.reply,
                timestamp: Date.now(),
                modelUsed: data.modelUsed || selectedModel,
                searchQueries: data.searchQueries,
              }
            : msg
        )
      );
      onShowToast('✓ Answer reloaded with fresh take');
    } catch (err: any) {
      console.error('Reload error:', err);
      onShowToast(`Failed to reload: ${err.message || 'Server error'}`);
    } finally {
      setReloadingMessageId(null);
    }
  };

  const handleCopy = (content: string, id: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    onShowToast('Copied to clipboard');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearHistory = () => {
    setMessages(INITIAL_MESSAGES);
    setEditingMessageId(null);
    try {
      localStorage.setItem(VFX_STORAGE_KEY, JSON.stringify(INITIAL_MESSAGES));
    } catch {}
    onShowToast(`Thread cleared for ${DIRECTOR_TITLE}`);
  };

  return (
    <div className="trans-card border-purple-500/25 overflow-hidden flex flex-col shadow-2xl">
      {/* Header: Title, Description & Model Selector */}
      <div className="p-5 sm:p-6 bg-gradient-to-b from-[#131220] to-[#0e0e17] border-b border-white/10">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400 flex-shrink-0">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight flex items-center gap-2">
                {DIRECTOR_TITLE}
              </h2>
              <p className="text-xs text-neutral-400">
                Cinematic camera blocking, morph kinematics, dialogue beats, audio foley &amp; prompt optimization for WAN 3.0.
              </p>
            </div>
          </div>

          {/* Model Selector Affordance: 3.8 Flash and 3.5 Flash */}
          <div className="flex items-center gap-2 bg-[#09090f] p-1.5 rounded-xl border border-white/10 w-full lg:w-auto">
            <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-neutral-400 px-2 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-pink-400" />
              Model:
            </span>

            <div className="flex items-center gap-1.5 flex-1 lg:flex-initial">
              <button
                type="button"
                onClick={() => setSelectedModel('gemini-3.8-flash')}
                className={`flex-1 lg:flex-initial px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
                  selectedModel === 'gemini-3.8-flash'
                    ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-md shadow-pink-600/30'
                    : 'text-neutral-400 hover:text-white hover:bg-white/5'
                }`}
                title="Latest frontier flash model (default) with advanced multimodal vision and directing capability"
              >
                <Sparkles className="w-3.5 h-3.5 text-pink-300 flex-shrink-0" />
                <span>3.8 Flash</span>
                <span className="text-[9px] bg-white/20 px-1 rounded flex-shrink-0 font-mono">Latest</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedModel('gemini-3.5-flash')}
                className={`flex-1 lg:flex-initial px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
                  selectedModel === 'gemini-3.5-flash'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'text-neutral-400 hover:text-white hover:bg-white/5'
                }`}
                title="Gemini 3.5 Flash: Standard production flash baseline"
              >
                <Zap className="w-3.5 h-3.5 text-indigo-300 flex-shrink-0" />
                <span>3.5 Flash</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Frame Body: Integrated Chat Section */}
      <div className="flex flex-col flex-1 min-h-[520px]">
        {/* Chat Subheader Bar */}
        <div className="px-5 sm:px-6 py-3 bg-black/40 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-semibold text-neutral-300">{DIRECTOR_TITLE}</span>
            <span className="text-xs text-neutral-500 font-mono">({selectedModel})</span>
          </div>

          <button
            onClick={handleClearHistory}
            className="text-xs text-neutral-400 hover:text-red-400 flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-white/5 transition"
            title="Reset conversation"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Thread</span>
          </button>
        </div>

        {/* Scrollable Message Thread */}
        <div ref={scrollRef} className="flex-1 max-h-[500px] overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-3xl ${isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}
              >
                {/* Avatar */}
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 text-xs font-bold ${
                    isUser
                      ? 'bg-gradient-to-tr from-pink-500 to-purple-600 text-white'
                      : 'bg-[#1a1a28] border border-white/10 text-pink-400'
                  }`}
                >
                  {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                {/* Message Bubble */}
                <div
                  className={`rounded-2xl p-4 text-sm leading-relaxed ${
                    isUser
                      ? 'bg-gradient-to-r from-pink-600/90 to-purple-700/90 text-white shadow-lg shadow-pink-900/20 w-full sm:w-auto'
                      : 'bg-[#0e0e17] border border-white/10 text-neutral-200'
                  }`}
                >
                  {/* Header for User Messages with Edit Button */}
                  {isUser && (
                    <div className="flex items-center justify-between gap-4 mb-2 pb-1.5 border-b border-white/15 text-[11px] text-pink-200">
                      <span className="font-semibold flex items-center gap-1">
                        <span>Your Prompt</span>
                      </span>
                      {editingMessageId !== msg.id && (
                        <button
                          type="button"
                          onClick={() => handleStartEdit(msg)}
                          disabled={loading || reloadingMessageId !== null}
                          className="opacity-80 hover:opacity-100 hover:text-white transition flex items-center gap-1 text-[10px] bg-black/30 hover:bg-black/50 px-2 py-0.5 rounded-md border border-white/10"
                          title="Edit this prompt and regenerate answer"
                        >
                          <Pencil className="w-2.5 h-2.5" />
                          <span>Edit Prompt</span>
                        </button>
                      )}
                    </div>
                  )}

                  {/* Header for Assistant Messages */}
                  {!isUser && (
                    <div className="flex items-center justify-between gap-4 mb-2 pb-2 border-b border-white/5">
                      <span className="text-[11px] font-semibold text-pink-300 flex items-center gap-1.5">
                        <Sparkles className="w-3 h-3" />
                        {DIRECTOR_TITLE}
                      </span>
                      {msg.modelUsed && (
                        <span className="text-[10px] font-mono text-neutral-500">
                          {msg.modelUsed}
                        </span>
                      )}
                    </div>
                  )}

                  {/* User message inline edit form vs normal text display */}
                  {isUser && editingMessageId === msg.id ? (
                    <div className="space-y-2 mt-1">
                      <textarea
                        value={editingContent}
                        onChange={(e) => setEditingContent(e.target.value)}
                        onKeyDown={(e) => {
                          if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
                            e.preventDefault();
                            handleSaveEditedMessage(msg.id);
                          }
                        }}
                        rows={3}
                        className="w-full bg-black/50 border border-white/20 rounded-xl p-2.5 text-xs text-white placeholder-neutral-400 focus:outline-none focus:border-pink-300 focus:ring-1 focus:ring-pink-300 font-sans leading-relaxed"
                        autoFocus
                      />
                      <div className="flex items-center justify-end gap-2 text-xs">
                        <button
                          type="button"
                          onClick={handleCancelEdit}
                          className="px-2.5 py-1 rounded-lg text-[10px] text-neutral-300 hover:text-white bg-black/40 hover:bg-black/60 transition flex items-center gap-1 border border-white/10"
                        >
                          <X className="w-3 h-3" />
                          <span>Cancel</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSaveEditedMessage(msg.id)}
                          disabled={!editingContent.trim() || loading}
                          className="px-3 py-1 rounded-lg text-[10px] font-bold text-white bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 transition shadow flex items-center gap-1 disabled:opacity-50"
                        >
                          <Check className="w-3 h-3" />
                          <span>Save &amp; Resubmit</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="whitespace-pre-wrap font-sans break-words">{msg.content}</div>
                  )}

                  {/* Visual & Web Search Grounding Badges */}
                  {!isUser && Array.isArray(msg.searchQueries) && msg.searchQueries.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-white/5 flex flex-wrap items-center gap-1.5">
                      <span className="text-[10px] text-pink-400 font-medium flex items-center gap-1">
                        <Sparkles className="w-2.5 h-2.5" />
                        Visual / Web Search Grounding:
                      </span>
                      {msg.searchQueries.filter(Boolean).map((q, qIdx) => (
                        <span
                          key={qIdx}
                          className="text-[10px] font-mono bg-pink-500/10 text-pink-300 border border-pink-500/20 px-2 py-0.5 rounded-full"
                        >
                          "{typeof q === 'string' ? q : String(q)}"
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Actions for Assistant Messages: Reload, Copy, Use in Enhancer */}
                  {!isUser && (
                    <div className="mt-3 pt-2 border-t border-white/5 flex flex-wrap items-center gap-2 justify-end">
                      <button
                        onClick={() => handleReloadAnswer(msg.id)}
                        disabled={loading || reloadingMessageId !== null}
                        className="text-[11px] font-medium text-neutral-400 hover:text-pink-300 px-2 py-1 rounded bg-white/5 hover:bg-white/10 transition flex items-center gap-1 disabled:opacity-40"
                        title="Reload this answer with a fresh response from Gemini"
                      >
                        <RotateCcw
                          className={`w-3 h-3 ${
                            reloadingMessageId === msg.id ? 'animate-spin text-pink-400' : ''
                          }`}
                        />
                        <span>{reloadingMessageId === msg.id ? 'Reloading…' : 'Reload Answer'}</span>
                      </button>

                      <button
                        onClick={() => handleCopy(msg.content, msg.id)}
                        className="text-[11px] font-medium text-neutral-400 hover:text-white px-2 py-1 rounded bg-white/5 hover:bg-white/10 transition flex items-center gap-1"
                        title="Copy text"
                      >
                        {copiedId === msg.id ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span>Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => {
                          onInsertIntoPrompt(msg.content);
                          onShowToast('Inserted into Base Prompt input');
                        }}
                        className="text-[11px] font-medium text-pink-300 hover:text-pink-200 px-2 py-1 rounded bg-pink-500/15 hover:bg-pink-500/25 border border-pink-500/30 transition flex items-center gap-1"
                        title="Use as base prompt"
                      >
                        <ArrowRight className="w-3 h-3" />
                        <span>Use in I2V Enhancer</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {loading && (
            <div className="flex gap-3 max-w-xl mr-auto">
              <div className="w-8 h-8 rounded-lg bg-[#1a1a28] border border-white/10 text-pink-400 flex items-center justify-center">
                <Loader2 className="w-4 h-4 animate-spin text-pink-400" />
              </div>
              <div className="rounded-2xl p-4 bg-[#0e0e17] border border-white/10 text-neutral-400 text-xs flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-pink-400 animate-ping" />
                <span>{selectedModel} ({DIRECTOR_TITLE}) is directing…</span>
              </div>
            </div>
          )}
        </div>

        {/* Quick Suggestion Action Pills */}
        <div className="px-6 py-2.5 bg-black/20 border-t border-white/5 overflow-x-auto flex items-center gap-2 no-scrollbar">
          <span className="text-[11px] text-neutral-500 flex-shrink-0 font-medium">Quick Direct:</span>

          <button
            type="button"
            onClick={() =>
              handleSend(
                'Provide a cinematic camera blocking, lens choice (focal length, depth of field), and lighting continuity plan to bridge Frame A to Frame B in WAN 3.0.'
              )
            }
            className="text-[11px] text-pink-300 hover:text-white bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/30 px-3 py-1 rounded-full whitespace-nowrap transition flex-shrink-0 flex items-center gap-1 font-semibold"
            title="Camera movement, blocking, lenses and lighting plan"
          >
            <Film className="w-3 h-3 text-pink-400" />
            <span>🎥 Camera &amp; Lighting Plan</span>
          </button>

          <button
            type="button"
            onClick={() =>
              handleSend(
                'How do I describe the anatomical shifts, cloth re-weaving, and momentum conservation between Frame A and Frame B to prevent morph glitches in WAN 3.0?'
              )
            }
            className="text-[11px] text-purple-300 hover:text-purple-200 bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 px-3 py-1 rounded-full whitespace-nowrap transition flex-shrink-0 flex items-center gap-1 font-semibold"
            title="Fluid morphing physics, weight conservation and seamless transitions"
          >
            <Layers className="w-3 h-3 text-purple-400" />
            <span>🧬 Morph Kinematics</span>
          </button>

          <button
            type="button"
            onClick={() =>
              handleSend(
                'Suggest 3 alternative dialogue lines with distinct delivery tones (subtext) and synchronized micro-expressions/reactions for the climax of this scene.'
              )
            }
            className="text-[11px] text-blue-300 hover:text-blue-200 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 px-3 py-1 rounded-full whitespace-nowrap transition flex-shrink-0 flex items-center gap-1 font-semibold"
            title="Dialogue lines, character subtext, vocal tone and facial reactions"
          >
            <MessageSquareQuote className="w-3 h-3 text-blue-400" />
            <span>💬 Dialogue &amp; Reactions</span>
          </button>

          <button
            type="button"
            onClick={() =>
              handleSend(
                'Write a timestamped audio foley cue and ambient acoustic track (5s to 15s) with synchronized SFX, low-frequency rumbles, and dialogue delivery.'
              )
            }
            className="text-[11px] text-emerald-300 hover:text-emerald-200 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 px-3 py-1 rounded-full whitespace-nowrap transition flex-shrink-0 flex items-center gap-1 font-semibold"
            title="Timestamped Foley audio cues and acoustic sound design"
          >
            <Volume2 className="w-3 h-3 text-emerald-400" />
            <span>🔊 Audio &amp; Foley Track</span>
          </button>

          <button
            type="button"
            onClick={() =>
              handleSend(
                basePrompt?.trim()
                  ? `Optimize and compress my base prompt into laser-focused, high-signal WAN 3.0 prompt syntax, cutting empty buzzwords:\n"${basePrompt}"`
                  : 'How do I optimize a video prompt into dense, high-signal WAN 3.0 syntax without buzzwords or fluff?'
              )
            }
            className="text-[11px] text-amber-300 hover:text-amber-200 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 px-3 py-1 rounded-full whitespace-nowrap transition flex-shrink-0 flex items-center gap-1 font-semibold shadow-sm"
            title={basePrompt?.trim() ? 'Compress and optimize current base prompt' : 'Prompt optimization guide'}
          >
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>✨ Optimize Base Prompt</span>
          </button>

          <button
            type="button"
            onClick={() =>
              handleSend(
                'Search real-world outfit and costume visual examples across casual, formal, athletic, and vintage categories to inspire high-contrast wardrobe transitions for this scene.'
              )
            }
            className="text-[11px] text-neutral-300 hover:text-pink-300 bg-white/5 hover:bg-pink-500/10 border border-white/10 hover:border-pink-500/30 px-3 py-1 rounded-full whitespace-nowrap transition flex-shrink-0"
            title="Use Google Image Search to explore real outfit and costume examples"
          >
            <span>👗 Search Outfits</span>
          </button>
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-[#0a0a0f] border-t border-white/10">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about camera motion, morph physics, dialogue, audio foley, or prompt optimization..."
              disabled={loading}
              className="flex-1 bg-[#16161f] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500/60 focus:ring-2 focus:ring-pink-500/20 transition disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="p-3 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-medium transition disabled:opacity-50 disabled:cursor-not-allowed shadow-md shadow-pink-600/30 flex items-center justify-center flex-shrink-0"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
