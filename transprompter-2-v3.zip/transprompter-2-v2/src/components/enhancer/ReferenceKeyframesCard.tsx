import React, { useRef } from 'react';
import { Layers, X, Sparkles, Download, Upload, ArrowRight, ArrowLeftRight } from 'lucide-react';
import type { KeyframeImage } from '../../types';

interface ReferenceKeyframesCardProps {
  startImage: KeyframeImage | null;
  endImage: KeyframeImage | null;
  onClearStart: () => void;
  onClearEnd: () => void;
  onSwapFrames: () => void;
  onOpenInStudio: (previewUrl: string, mimeType: string, label: string) => void;
  onDownloadFrame: (img: KeyframeImage | null, label: string) => void;
  onUploadFile: (file: File, which: 'start' | 'end') => void;
}

export function ReferenceKeyframesCard({
  startImage,
  endImage,
  onClearStart,
  onClearEnd,
  onSwapFrames,
  onOpenInStudio,
  onDownloadFrame,
  onUploadFile,
}: ReferenceKeyframesCardProps) {
  const startFileRef = useRef<HTMLInputElement>(null);
  const endFileRef = useRef<HTMLInputElement>(null);

  return (
    <div className="trans-card p-4 sm:p-6">
      <div className="flex items-center gap-2 mb-5">
        <Layers className="w-5 h-5 text-pink-400" />
        <h2 className="text-base font-bold text-white">Reference Keyframes</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-11 items-center gap-4">
        {/* Start Frame (A) */}
        <div className="md:col-span-5 flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className="text-neutral-300 flex items-center gap-1.5">
              <span className="w-5 h-5 rounded bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center font-bold">
                A
              </span>
              Start Frame (Initial State)
            </span>
            {startImage && (
              <button
                type="button"
                onClick={onClearStart}
                className="text-neutral-500 hover:text-red-400 transition"
                title="Remove Start Frame"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div
            onClick={() => !startImage && startFileRef.current?.click()}
            className={`relative aspect-video rounded-2xl border-2 transition overflow-hidden flex flex-col items-center justify-center cursor-pointer ${
              startImage
                ? 'border-indigo-500/40 bg-black/40'
                : 'border-dashed border-white/15 hover:border-pink-500/40 bg-[#0e0e17] hover:bg-pink-500/5'
            }`}
          >
            {startImage ? (
              <>
                <img
                  src={startImage.previewUrl}
                  alt="Start Keyframe"
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/70 backdrop-blur-md text-[10px] font-mono text-indigo-300 border border-white/10">
                  Frame A
                </div>
                <div className="absolute top-2 left-2 flex items-center gap-1.5 z-10">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenInStudio(startImage.previewUrl, startImage.mimeType, 'Frame A');
                    }}
                    className="px-2 py-1 rounded-md bg-black/70 hover:bg-black/90 text-indigo-300 text-[10px] font-semibold border border-indigo-500/30 flex items-center gap-1 transition shadow"
                    title="Edit this frame with prompts"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Edit in Studio</span>
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDownloadFrame(startImage, 'start-frame-A');
                    }}
                    className="px-2 py-1 rounded-md bg-black/70 hover:bg-black/90 text-white hover:text-indigo-300 text-[10px] font-semibold border border-white/20 flex items-center gap-1 transition shadow"
                    title="Download Start Frame A"
                  >
                    <Download className="w-3 h-3" />
                    <span>Download</span>
                  </button>
                </div>
              </>
            ) : (
              <div className="p-6 flex flex-col items-center gap-2 text-center">
                <Upload className="w-8 h-8 text-neutral-500" />
                <p className="text-xs font-medium text-neutral-300">
                  Drop Start Image or <span className="text-pink-400">browse</span>
                </p>
                <p className="text-[10px] text-neutral-500">PNG, JPG, WEBP (or Paste)</p>
              </div>
            )}
          </div>
          <input
            ref={startFileRef}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) onUploadFile(file, 'start');
            }}
          />
        </div>

        {/* Swap Frames Action (A ↔ B) */}
        <div className="md:col-span-1 flex flex-col items-center justify-center py-2 md:py-0 gap-1.5">
          <button
            type="button"
            onClick={onSwapFrames}
            disabled={!startImage && !endImage}
            className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all duration-200 cursor-pointer group shadow-lg ${
              startImage || endImage
                ? 'bg-gradient-to-br from-indigo-500/25 via-purple-500/25 to-pink-500/25 hover:from-indigo-500/40 hover:via-purple-500/40 hover:to-pink-500/40 border border-pink-500/40 hover:border-pink-400 text-pink-300 hover:text-white hover:scale-105 active:scale-95 shadow-pink-500/20'
                : 'bg-white/5 border border-white/10 text-neutral-600 cursor-not-allowed opacity-40'
            }`}
            title="Swap Keyframes (A ↔ B) — Reverse transformation order"
          >
            <ArrowLeftRight className="w-5 h-5 transition-transform duration-300 group-hover:rotate-180" />
          </button>
          <span className="text-[10px] font-mono text-neutral-400 font-medium select-none text-center">
            Swap A ↔ B
          </span>
        </div>

        {/* End Frame (B) */}
        <div className="md:col-span-5 flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className="text-neutral-300 flex items-center gap-1.5">
              <span className="w-5 h-5 rounded bg-pink-500/20 text-pink-400 border border-pink-500/30 flex items-center justify-center font-bold">
                B
              </span>
              End Frame (Final State)
            </span>
            {endImage && (
              <button
                type="button"
                onClick={onClearEnd}
                className="text-neutral-500 hover:text-red-400 transition"
                title="Remove End Frame"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div
            onClick={() => !endImage && endFileRef.current?.click()}
            className={`relative aspect-video rounded-2xl border-2 transition overflow-hidden flex flex-col items-center justify-center cursor-pointer ${
              endImage
                ? 'border-pink-500/40 bg-black/40'
                : 'border-dashed border-white/15 hover:border-pink-500/40 bg-[#0e0e17] hover:bg-pink-500/5'
            }`}
          >
            {endImage ? (
              <>
                <img
                  src={endImage.previewUrl}
                  alt="End Keyframe"
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/70 backdrop-blur-md text-[10px] font-mono text-pink-300 border border-white/10">
                  Frame B
                </div>
                <div className="absolute top-2 left-2 flex items-center gap-1.5 z-10">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenInStudio(endImage.previewUrl, endImage.mimeType, 'Frame B');
                    }}
                    className="px-2 py-1 rounded-md bg-black/70 hover:bg-black/90 text-pink-300 text-[10px] font-semibold border border-pink-500/30 flex items-center gap-1 transition shadow"
                    title="Edit this frame with prompts"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Edit in Studio</span>
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDownloadFrame(endImage, 'end-frame-B');
                    }}
                    className="px-2 py-1 rounded-md bg-black/70 hover:bg-black/90 text-white hover:text-pink-300 text-[10px] font-semibold border border-white/20 flex items-center gap-1 transition shadow"
                    title="Download End Frame B"
                  >
                    <Download className="w-3 h-3" />
                    <span>Download</span>
                  </button>
                </div>
              </>
            ) : (
              <div className="p-6 flex flex-col items-center gap-2 text-center">
                <Upload className="w-8 h-8 text-neutral-500" />
                <p className="text-xs font-medium text-neutral-300">
                  Drop End Image or <span className="text-pink-400">browse</span>
                </p>
                <p className="text-[10px] text-neutral-500">PNG, JPG, WEBP (or Paste)</p>
              </div>
            )}
          </div>
          <input
            ref={endFileRef}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) onUploadFile(file, 'end');
            }}
          />
        </div>
      </div>
    </div>
  );
}
