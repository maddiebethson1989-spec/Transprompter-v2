import { Sliders, Sparkles, AlertCircle, Wand2, Loader2 } from 'lucide-react';
import { PRESET_TEMPLATES, type PresetTemplate } from '../../constants/enhancer';

interface PromptInputCardProps {
  basePrompt: string;
  onBasePromptChange: (value: string) => void;
  duration: number;
  onDurationChange: (value: number) => void;
  model: string;
  onModelChange: (model: string) => void;
  errorMessage: string | null;
  isGenerating: boolean;
  isDraftingPrompt?: boolean;
  onAutoDraftPrompt?: () => void;
  hasKeyframes?: boolean;
  onClearBasePrompt?: () => void;
  onEnhance: () => void;
  onApplyPreset: (preset: PresetTemplate) => void;
}

export function PromptInputCard({
  basePrompt,
  onBasePromptChange,
  duration,
  onDurationChange,
  model,
  onModelChange,
  errorMessage,
  isGenerating,
  isDraftingPrompt = false,
  onAutoDraftPrompt,
  hasKeyframes = false,
  onClearBasePrompt,
  onEnhance,
  onApplyPreset,
}: PromptInputCardProps) {
  return (
                <div
                  id="base-prompt-frame"
                  className="trans-card p-6 flex flex-col justify-between gap-5"
                >
                  <div className="space-y-4">
                    <div>
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2.5">
                          <label className="text-sm font-semibold text-neutral-200">
                            Base Prompt
                          </label>
                          {onAutoDraftPrompt && (
                            <button
                              type="button"
                              onClick={onAutoDraftPrompt}
                              disabled={isDraftingPrompt || isGenerating}
                              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 shadow-sm active:scale-95 disabled:opacity-50 cursor-pointer ${
                                hasKeyframes
                                  ? 'bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-indigo-500/20 hover:from-pink-500/30 hover:via-purple-500/30 hover:to-indigo-500/30 border border-pink-500/40 text-pink-300 hover:text-white'
                                  : 'bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-400 hover:text-neutral-200'
                              }`}
                              title={
                                hasKeyframes
                                  ? 'Perform visual delta analysis on Keyframes A & B to auto-draft a transformation base prompt'
                                  : 'Upload or generate both Keyframe A and B to auto-draft a base prompt'
                              }
                            >
                              {isDraftingPrompt ? (
                                <>
                                  <Loader2 className="w-3.5 h-3.5 animate-spin text-pink-400" />
                                  <span>Drafting from Frames…</span>
                                </>
                              ) : (
                                <>
                                  <Wand2 className="w-3.5 h-3.5 text-pink-400" />
                                  <span>Auto-Draft from Frames</span>
                                </>
                              )}
                            </button>
                          )}
                        </div>

                        <div className="flex items-center gap-2">
                          {basePrompt.length > 0 && onClearBasePrompt && (
                            <button
                              type="button"
                              onClick={onClearBasePrompt}
                              disabled={isGenerating || isDraftingPrompt}
                              className="text-xs text-neutral-500 hover:text-red-400 transition"
                              title="Clear base prompt"
                            >
                              Clear
                            </button>
                          )}
                          <span className="text-xs text-neutral-500 font-mono">
                            {basePrompt.length.toLocaleString()} characters
                          </span>
                        </div>
                      </div>

                      <textarea
                        value={basePrompt}
                        onChange={(e) => onBasePromptChange(e.target.value)}
                        rows={6}
                        placeholder="Describe what triggers the transformation between Image A and Image B, any character motion or dialogue, physical morphing details, and environmental interaction..."
                        className="w-full bg-[#0e0e17] border border-white/10 rounded-xl p-4 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-pink-500/60 focus:ring-2 focus:ring-pink-500/20 transition resize-none leading-relaxed"
                      />
                    </div>

                    {/* Preset Chips */}
                    <div>
                      <span className="text-xs font-medium text-neutral-400 mb-2 block">
                        Quick Sample Transformation Scenarios:
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {PRESET_TEMPLATES.map((p, idx) => (
                          <button
                            key={idx}
                            onClick={() => onApplyPreset(p)}
                            className="text-xs bg-white/5 hover:bg-pink-500/10 border border-white/5 hover:border-pink-500/30 text-neutral-300 hover:text-pink-300 px-3 py-1.5 rounded-lg transition text-left"
                          >
                            {p.title}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Settings Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-white/10">
                      {/* Duration Slider */}
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                            <Sliders className="w-3.5 h-3.5 text-pink-400" />
                            Video Duration
                          </span>
                          <span className="text-lg font-bold font-mono gradient-text">{duration}s</span>
                        </div>

                        <input
                          type="range"
                          min={5}
                          max={30}
                          step={1}
                          value={duration}
                          onChange={(e) => onDurationChange(Number(e.target.value))}
                          className="slider-custom"
                          style={{
                            background: `linear-gradient(to right, #f472b6 0%, #a855f7 ${
                              ((duration - 5) / 25) * 100
                            }%, rgba(255,255,255,0.1) ${((duration - 5) / 25) * 100}%)`,
                          }}
                        />

                        <div className="flex justify-between text-[10px] text-neutral-500 font-mono mt-1 px-1">
                          <span>5s (Clip)</span>
                          <span>10s</span>
                          <span>20s</span>
                          <span>30s (Extended)</span>
                        </div>
                      </div>

                      {/* Model Selector for Prompt Engineering */}
                      <div>
                        <label className="block text-xs font-semibold text-neutral-300 mb-2">
                          Prompt Engineering Model
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            type="button"
                            onClick={() => onModelChange('gemini-3.8-flash')}
                            className={`p-2.5 rounded-xl border text-xs font-semibold transition text-left ${
                              model === 'gemini-3.8-flash'
                                ? 'bg-gradient-to-br from-pink-500/25 to-purple-600/25 border-pink-500 text-white shadow-sm shadow-pink-500/20'
                                : 'bg-[#0e0e17] border-white/10 text-neutral-400 hover:text-white'
                            }`}
                          >
                            <div className="font-bold flex items-center justify-between">
                              <span>3.8 Flash</span>
                              <span className="text-[9px] bg-pink-500/30 text-pink-300 px-1 rounded">Latest</span>
                            </div>
                            <div className="text-[10px] text-neutral-400 font-normal">
                              Frontier reasoning
                            </div>
                          </button>

                          <button
                            type="button"
                            onClick={() => onModelChange('gemini-3.5-flash')}
                            className={`p-2.5 rounded-xl border text-xs font-semibold transition text-left ${
                              model === 'gemini-3.5-flash'
                                ? 'bg-indigo-500/20 border-indigo-500/60 text-white'
                                : 'bg-[#0e0e17] border-white/10 text-neutral-400 hover:text-white'
                            }`}
                          >
                            <div className="font-bold">3.5 Flash</div>
                            <div className="text-[10px] text-neutral-400 font-normal">
                              Standard baseline
                            </div>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {errorMessage && (
                    <div className="p-3 bg-red-950/40 border border-red-500/40 rounded-xl text-xs text-red-300 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                      <span>{errorMessage}</span>
                    </div>
                  )}

                  {/* Enhance Action Button */}
                  <div className="pt-2">
                    <button
                      onClick={onEnhance}
                      disabled={isGenerating}
                      className="relative overflow-hidden w-full py-4 px-6 rounded-2xl font-bold text-base text-white bg-gradient-to-r from-pink-600 via-fuchsia-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 disabled:opacity-50 disabled:cursor-not-allowed shadow-xl shadow-pink-600/30 transition transform active:scale-[0.99]"
                    >
                      <div className="relative z-10 flex items-center justify-center gap-2">
                        <Sparkles className="w-5 h-5 text-white" />
                        <span>{isGenerating ? 'Analyzing Keyframes…' : 'Enhance Prompt with AI'}</span>
                      </div>
                      <div className="btn-shimmer" />
                    </button>
                  </div>
                </div>
  );
}
