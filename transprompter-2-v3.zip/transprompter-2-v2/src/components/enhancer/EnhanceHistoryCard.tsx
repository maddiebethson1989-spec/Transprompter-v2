import React, { useState, useRef, useEffect } from 'react';
import {
  History,
  Trash2,
  RotateCcw,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  Search,
  Sparkles,
  ArrowRight,
  Film,
  Music,
  ExternalLink,
  Layers,
} from 'lucide-react';
import type { EnhanceHistoryItem, KeyframeImage } from '../../types';

interface EnhanceHistoryCardProps {
  history: EnhanceHistoryItem[];
  onRestore: (item: EnhanceHistoryItem) => void;
  onDeleteItem: (id: string) => void;
  onClearHistory: () => void;
  onOpenInStudio?: (previewUrl: string, mimeType: string, label: string) => void;
  onShowToast: (msg: string) => void;
}

export function EnhanceHistoryCard({
  history,
  onRestore,
  onDeleteItem,
  onClearHistory,
  onOpenInStudio,
  onShowToast,
}: EnhanceHistoryCardProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedItemId, setExpandedItemId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeTabMap, setActiveTabMap] = useState<Record<string, 'full' | 'video' | 'audio'>>({});
  const listRef = useRef<HTMLDivElement>(null);
  const [maxHeightStyle, setMaxHeightStyle] = useState<string>('1075px');

  // Filter items by search query
  const filteredHistory = history.filter((item) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      item.basePrompt.toLowerCase().includes(q) ||
      item.enhancedResult.full.toLowerCase().includes(q) ||
      (item.model && item.model.toLowerCase().includes(q))
    );
  });

  // Compute dynamic height for 3 history items based on actual rendered item height
  useEffect(() => {
    if (!listRef.current) return;
    const updateHeight = () => {
      const items = listRef.current?.querySelectorAll<HTMLElement>('[data-history-item]');
      if (!items || items.length === 0) return;
      let sampleHeight = 350;
      for (let i = 0; i < items.length; i++) {
        const itemEl = items[i];
        if (itemEl.getAttribute('data-expanded') !== 'true' && itemEl.offsetHeight > 100) {
          sampleHeight = itemEl.offsetHeight;
          break;
        }
      }
      // Height of 3 items with 2 gaps of 12px (space-y-3 = 0.75rem = 12px)
      const threeItemsHeight = Math.round(sampleHeight * 3 + 24);
      setMaxHeightStyle(`${threeItemsHeight}px`);
    };

    updateHeight();
    const resizeObserver = new ResizeObserver(() => {
      updateHeight();
    });
    if (listRef.current) {
      resizeObserver.observe(listRef.current);
    }
    return () => resizeObserver.disconnect();
  }, [filteredHistory.length]);

  const formatTime = (ts: number): string => {
    const diff = Date.now() - ts;
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'Just now';
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    return new Date(ts).toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const handleCopy = async (id: string, text: string, label: string) => {
    try {
      await navigator.clipboard.readText ? null : null;
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      onShowToast(`✓ Copied ${label} to clipboard!`);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      onShowToast('Failed to copy to clipboard');
    }
  };

  return (
    <div id="enhancement-history-section" className="trans-card p-5 sm:p-6 flex flex-col gap-4 border-pink-500/20">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-pink-500/10 border border-pink-500/30 flex items-center justify-center text-pink-400 flex-shrink-0 shadow-inner">
            <History className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm sm:text-base font-bold text-white tracking-tight">Enhancement History</h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-pink-500/15 text-pink-300 border border-pink-500/30 font-semibold">
                {history.length} saved
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-0.5">
              Saved base prompts, enhanced WAN 3.0 scripts, and keyframe snapshots
            </p>
          </div>
        </div>

        {/* Right actions: Search + Clear All + Expand/Collapse */}
        <div className="flex items-center gap-2">
          {history.length > 0 && (
            <>
              <div className="relative flex items-center">
                <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-2.5 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter history…"
                  className="bg-[#0e0e17] border border-white/10 focus:border-pink-500/50 rounded-lg pl-8 pr-2.5 py-1 text-xs text-white placeholder-neutral-500 focus:outline-none w-32 sm:w-44 transition"
                />
              </div>

              <button
                type="button"
                onClick={onClearHistory}
                className="px-2.5 py-1 text-xs text-neutral-400 hover:text-red-400 hover:bg-red-500/10 border border-white/10 hover:border-red-500/20 rounded-lg transition flex items-center gap-1.5 flex-shrink-0"
                title="Clear all enhancement history"
              >
                <Trash2 className="w-3 h-3" />
                <span className="hidden sm:inline">Clear</span>
              </button>
            </>
          )}

          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-white/5 border border-white/10 transition"
            title={isExpanded ? 'Collapse history' : 'Expand history'}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Content Area */}
      {isExpanded && (
        <div className="space-y-3">
          {history.length === 0 ? (
            <div className="py-8 px-4 rounded-xl border border-dashed border-white/10 bg-[#0e0e17]/50 flex flex-col items-center justify-center text-center gap-2.5">
              <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-neutral-500">
                <Sparkles className="w-5 h-5 text-neutral-400" />
              </div>
              <div className="max-w-md">
                <p className="text-xs font-semibold text-neutral-300">No prompt enhancements saved yet</p>
                <p className="text-[11px] text-neutral-500 mt-1 leading-relaxed">
                  Whenever you enhance a cinematic prompt with Gemini AI, your base prompt, enhanced WAN 3.0 output,
                  and keyframes will be saved here automatically for 1-click restoring and editing.
                </p>
              </div>
            </div>
          ) : filteredHistory.length === 0 ? (
            <div className="py-6 text-center text-xs text-neutral-500">
              No history matches your search filter "{searchQuery}".
            </div>
          ) : (
            <div
              ref={listRef}
              style={{ maxHeight: maxHeightStyle }}
              className="space-y-3 overflow-y-auto pr-1.5 sm:pr-2 scrollbar-thin scroll-smooth"
            >
              {filteredHistory.map((item) => {
                const isItemExpanded = expandedItemId === item.id;
                const activeTab = activeTabMap[item.id] || 'full';

                return (
                  <div
                    key={item.id}
                    data-history-item="true"
                    data-expanded={isItemExpanded ? 'true' : 'false'}
                    className="p-4 rounded-xl border border-white/10 bg-[#0e0e17] hover:border-pink-500/30 transition flex flex-col gap-3 group shadow-md"
                  >
                    {/* Top Row: Meta info & Actions */}
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[11px] font-mono text-neutral-400 flex items-center gap-1">
                          <History className="w-3 h-3 text-pink-400" />
                          <span>{formatTime(item.timestamp)}</span>
                        </span>
                        {item.model && (
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-neutral-300 border border-white/10">
                            {item.model}
                          </span>
                        )}
                        {item.duration && (
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/20">
                            {item.duration}s Duration
                          </span>
                        )}
                      </div>

                      {/* Item Actions */}
                      <div className="flex items-center gap-1.5 ml-auto">
                        <button
                          type="button"
                          onClick={() => onRestore(item)}
                          className="px-2.5 py-1 text-xs font-bold text-white bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 rounded-lg shadow-sm transition flex items-center gap-1.5 active:scale-95 cursor-pointer"
                          title="Restore base prompt, keyframes, and enhanced prompt into the active editor"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>Restore</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleCopy(item.id, item.enhancedResult.full, 'Full Prompt')}
                          className="px-2 py-1 text-xs text-neutral-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-lg border border-white/10 transition flex items-center gap-1"
                          title="Copy full enhanced prompt"
                        >
                          {copiedId === item.id ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3 text-neutral-400" />
                          )}
                          <span className="hidden sm:inline">Copy</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onDeleteItem(item.id)}
                          className="p-1 text-neutral-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition"
                          title="Delete this history item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Middle Section: Keyframe Thumbnails + Base Prompt */}
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center pt-1 border-t border-white/5">
                      {/* Left: Keyframe Pair Thumbnails */}
                      <div className="md:col-span-4 flex items-center gap-2 bg-black/40 p-2 rounded-xl border border-white/5">
                        {/* Start Frame Thumbnail */}
                        <div className="flex-1 flex flex-col items-center gap-1">
                          <div className="w-full aspect-[4/3] rounded-lg overflow-hidden bg-neutral-900 border border-white/10 relative group/thumb">
                            {item.startFrame?.previewUrl ? (
                              <>
                                <img
                                  src={item.startFrame.previewUrl}
                                  alt="Start Frame"
                                  className="w-full h-full object-cover"
                                />
                                {onOpenInStudio && (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      onOpenInStudio(
                                        item.startFrame!.previewUrl,
                                        item.startFrame!.mimeType,
                                        'Start Frame'
                                      )
                                    }
                                    className="absolute inset-0 bg-black/60 opacity-0 group-hover/thumb:opacity-100 flex items-center justify-center text-[10px] text-pink-300 font-semibold transition"
                                    title="Open Start Frame in Keyframe Studio"
                                  >
                                    <ExternalLink className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </>
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-[9px] text-neutral-600 font-mono">
                                None
                              </div>
                            )}
                          </div>
                          <span className="text-[10px] font-mono text-neutral-400 truncate max-w-full">
                            Start (A)
                          </span>
                        </div>

                        {/* Transition Arrow */}
                        <div className="flex-shrink-0 text-pink-400/80 px-0.5">
                          <ArrowRight className="w-3.5 h-3.5" />
                        </div>

                        {/* End Frame Thumbnail */}
                        <div className="flex-1 flex flex-col items-center gap-1">
                          <div className="w-full aspect-[4/3] rounded-lg overflow-hidden bg-neutral-900 border border-white/10 relative group/thumb">
                            {item.endFrame?.previewUrl ? (
                              <>
                                <img
                                  src={item.endFrame.previewUrl}
                                  alt="End Frame"
                                  className="w-full h-full object-cover"
                                />
                                {onOpenInStudio && (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      onOpenInStudio(
                                        item.endFrame!.previewUrl,
                                        item.endFrame!.mimeType,
                                        'End Frame'
                                      )
                                    }
                                    className="absolute inset-0 bg-black/60 opacity-0 group-hover/thumb:opacity-100 flex items-center justify-center text-[10px] text-purple-300 font-semibold transition"
                                    title="Open End Frame in Keyframe Studio"
                                  >
                                    <ExternalLink className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </>
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-[9px] text-neutral-600 font-mono">
                                None
                              </div>
                            )}
                          </div>
                          <span className="text-[10px] font-mono text-neutral-400 truncate max-w-full">
                            End (B)
                          </span>
                        </div>
                      </div>

                      {/* Right: Base Prompt Preview */}
                      <div className="md:col-span-8 flex flex-col justify-center min-w-0">
                        <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-1 flex items-center gap-1">
                          <span>Original Base Prompt</span>
                        </div>
                        <p className="text-xs text-neutral-200 line-clamp-2 leading-relaxed bg-black/20 p-2.5 rounded-lg border border-white/5 font-mono">
                          "{item.basePrompt}"
                        </p>
                      </div>
                    </div>

                    {/* Bottom: Enhanced Prompt Snippet / Full Drawer */}
                    <div className="pt-2 border-t border-white/5">
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-1 text-[11px] font-semibold text-pink-300">
                          <Sparkles className="w-3 h-3 text-pink-400" />
                          <span>Enhanced WAN 3.0 Output</span>
                        </div>

                        <div className="flex items-center gap-2">
                          {isItemExpanded && (
                            <div className="flex items-center bg-black/40 p-0.5 rounded-lg border border-white/10 text-[10px] font-mono">
                              <button
                                type="button"
                                onClick={() => setActiveTabMap({ ...activeTabMap, [item.id]: 'full' })}
                                className={`px-2 py-0.5 rounded transition ${
                                  activeTab === 'full' ? 'bg-pink-500/30 text-white font-bold' : 'text-neutral-400'
                                }`}
                              >
                                Full
                              </button>
                              <button
                                type="button"
                                onClick={() => setActiveTabMap({ ...activeTabMap, [item.id]: 'video' })}
                                className={`px-2 py-0.5 rounded transition flex items-center gap-1 ${
                                  activeTab === 'video' ? 'bg-pink-500/30 text-white font-bold' : 'text-neutral-400'
                                }`}
                              >
                                <Film className="w-2.5 h-2.5" />
                                Video
                              </button>
                              <button
                                type="button"
                                onClick={() => setActiveTabMap({ ...activeTabMap, [item.id]: 'audio' })}
                                className={`px-2 py-0.5 rounded transition flex items-center gap-1 ${
                                  activeTab === 'audio' ? 'bg-pink-500/30 text-white font-bold' : 'text-neutral-400'
                                }`}
                              >
                                <Music className="w-2.5 h-2.5" />
                                Audio
                              </button>
                            </div>
                          )}

                          <button
                            type="button"
                            onClick={() => setExpandedItemId(isItemExpanded ? null : item.id)}
                            className="text-[11px] text-pink-400 hover:text-pink-300 font-medium transition flex items-center gap-0.5"
                          >
                            <span>{isItemExpanded ? 'Show Less' : 'View Full Prompt'}</span>
                            {isItemExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>

                      {/* Prompt Content */}
                      <div className="bg-[#12121c] p-3 rounded-lg border border-white/5 text-xs text-neutral-300 font-mono leading-relaxed overflow-hidden">
                        {isItemExpanded ? (
                          <div className="max-h-60 overflow-y-auto whitespace-pre-wrap pr-1 scrollbar-thin">
                            {activeTab === 'video'
                              ? item.enhancedResult.video
                              : activeTab === 'audio'
                              ? item.enhancedResult.audio
                              : item.enhancedResult.full}
                          </div>
                        ) : (
                          <p className="line-clamp-2 text-neutral-400">
                            {item.enhancedResult.full}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
