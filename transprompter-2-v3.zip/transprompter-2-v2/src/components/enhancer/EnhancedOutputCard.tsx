import type { Ref } from 'react';
import { Check, Copy, Film, Sparkles, Volume2, Video, ArrowRight } from 'lucide-react';
import { STEP_CONFIG } from '../../constants/enhancer';
import type { SplitPromptResult } from '../../types';

export type OutputTab = 'full' | 'video' | 'audio';

interface EnhancedOutputCardProps {
  outputRef: Ref<HTMLDivElement>;
  result: SplitPromptResult | null;
  isGenerating: boolean;
  currentStep: number;
  activeOutputTab: OutputTab;
  onOutputTabChange: (tab: OutputTab) => void;
  copiedSection: string | null;
  onCopy: (text: string, label: string, section: string) => void;
  onSendToVideoGenerator?: (prompt: string) => void;
}

export function EnhancedOutputCard({
  outputRef,
  result,
  isGenerating,
  currentStep,
  activeOutputTab,
  onOutputTabChange,
  copiedSection,
  onCopy,
  onSendToVideoGenerator,
}: EnhancedOutputCardProps) {
  return (
                <div
                  ref={outputRef}
                  id="enhanced-prompt-frame"
                  className="trans-card flex flex-col justify-between overflow-hidden border-pink-500/30 min-h-[480px]"
                >
                  {/* Output Header */}
                  <div className="px-5 sm:px-6 py-4 bg-black/40 border-b border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-pink-400" />
                      <h2 className="text-base font-bold text-white">Enhanced WAN 3.0 Prompt</h2>
                      {result && !isGenerating && (
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-medium">
                          Generated
                        </span>
                      )}
                      {isGenerating && (
                        <span className="text-[10px] bg-pink-500/20 text-pink-300 border border-pink-500/30 px-2 py-0.5 rounded-full font-medium animate-pulse">
                          Generating…
                        </span>
                      )}
                      {!result && !isGenerating && (
                        <span className="text-[10px] bg-white/10 text-neutral-400 border border-white/10 px-2 py-0.5 rounded-full font-medium">
                          Awaiting Generation
                        </span>
                      )}
                    </div>

                    {result && !isGenerating && (
                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          onClick={() => onCopy(result.video, 'Video Prompt', 'video')}
                          className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-[#0e0e17] hover:bg-pink-500/10 border border-white/10 hover:border-pink-500/30 text-neutral-300 hover:text-pink-300 transition flex items-center gap-1.5"
                          title="Copy Video Generation Track"
                        >
                          <Film className="w-3.5 h-3.5" />
                          <span>{copiedSection === 'video' ? 'Copied!' : 'Copy Video'}</span>
                        </button>

                        <button
                          onClick={() => onCopy(result.audio, 'Audio Prompt', 'audio')}
                          className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-[#0e0e17] hover:bg-pink-500/10 border border-white/10 hover:border-pink-500/30 text-neutral-300 hover:text-pink-300 transition flex items-center gap-1.5"
                          title="Copy Audio & SFX Track"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>{copiedSection === 'audio' ? 'Copied!' : 'Copy Audio'}</span>
                        </button>

                        <button
                          onClick={() => onCopy(result.full, 'Full Prompt', 'full')}
                          className="px-3 py-1.5 rounded-lg text-xs font-bold bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white transition flex items-center gap-1.5 shadow-md shadow-pink-600/20"
                          title="Copy Full Document"
                        >
                          <Copy className="w-3.5 h-3.5" />
                          <span>{copiedSection === 'full' ? 'Copied!' : 'Copy All'}</span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Body State A: Actively Generating */}
                  {isGenerating && (
                    <div className="p-8 flex flex-col items-center justify-center gap-6 flex-1 my-auto">
                      {/* Glowing Double-Ring Animation */}
                      <div className="relative w-20 h-20 flex items-center justify-center">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-pink-500 to-purple-600 animate-pulse-glow shadow-lg shadow-pink-500/50" />
                        <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-pink-400 animate-spin-slow" />
                        <div className="absolute inset-2 rounded-full border-2 border-transparent border-t-purple-400 animate-spin" />
                      </div>

                      <div className="text-center">
                        <h3 className="text-lg font-bold text-white mb-1">{STEP_CONFIG[currentStep].title}</h3>
                        <p className="text-xs text-neutral-400">{STEP_CONFIG[currentStep].subtitle}</p>
                      </div>

                      <div className="w-full max-w-sm space-y-2.5">
                        {STEP_CONFIG.map((step, idx) => {
                          const isDone = idx < currentStep;
                          const isActive = idx === currentStep;
                          return (
                            <div
                              key={idx}
                              className={`flex items-center gap-3 text-xs transition ${
                                isActive
                                  ? 'text-pink-300 font-semibold'
                                  : isDone
                                  ? 'text-pink-500'
                                  : 'text-neutral-500'
                              }`}
                            >
                              <div
                                className={`w-2.5 h-2.5 rounded-full transition ${
                                  isActive
                                    ? 'bg-pink-400 ring-4 ring-pink-400/20'
                                    : isDone
                                    ? 'bg-pink-500'
                                    : 'bg-neutral-800'
                                }`}
                              />
                              <span>{step.title.replace('…', '')}</span>
                              {isDone && <Check className="w-3.5 h-3.5 text-pink-400 ml-auto" />}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Body State B: Prompt Result Present */}
                  {result && !isGenerating && (
                    <>
                      {/* Output Format Tabs */}
                      <div className="px-6 bg-black/20 border-b border-white/10 flex gap-2 overflow-x-auto no-scrollbar">
                        <button
                          onClick={() => onOutputTabChange('full')}
                          className={`py-3 px-3 text-xs font-semibold border-b-2 transition whitespace-nowrap ${
                            activeOutputTab === 'full'
                              ? 'border-pink-500 text-pink-400'
                              : 'border-transparent text-neutral-400 hover:text-white'
                          }`}
                        >
                          Full Document
                        </button>
                        <button
                          onClick={() => onOutputTabChange('video')}
                          className={`py-3 px-3 text-xs font-semibold border-b-2 transition whitespace-nowrap ${
                            activeOutputTab === 'video'
                              ? 'border-pink-500 text-pink-400'
                              : 'border-transparent text-neutral-400 hover:text-white'
                          }`}
                        >
                          Video Track
                        </button>
                        <button
                          onClick={() => onOutputTabChange('audio')}
                          className={`py-3 px-3 text-xs font-semibold border-b-2 transition whitespace-nowrap ${
                            activeOutputTab === 'audio'
                              ? 'border-pink-500 text-pink-400'
                              : 'border-transparent text-neutral-400 hover:text-white'
                          }`}
                        >
                          Audio &amp; SFX Track
                        </button>
                      </div>

                      {/* Prompt Document Pre */}
                      <div className="p-5 flex-1 flex flex-col">
                        <pre className="font-mono-code text-xs leading-relaxed text-neutral-200 bg-[#0e0e17] p-4 sm:p-5 rounded-xl border border-white/10 overflow-x-auto whitespace-pre-wrap flex-1 max-h-[460px] overflow-y-auto">
                          {activeOutputTab === 'full' && result.full}
                          {activeOutputTab === 'video' && result.video}
                          {activeOutputTab === 'audio' && result.audio}
                        </pre>

                        {/* Action Bar: Send to Video Generator */}
                        <div className="mt-4 pt-3.5 border-t border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#0a0a12] p-3 rounded-xl border border-purple-500/20">
                          <div className="text-xs text-neutral-400 flex items-center gap-2">
                            <Sparkles className="w-4 h-4 text-pink-400 flex-shrink-0" />
                            <span>
                              Ready to animate with start &amp; end keyframes in <strong className="text-pink-300 font-semibold">Video Studio</strong>
                            </span>
                          </div>

                          <button
                            type="button"
                            onClick={() => {
                              const promptToSend =
                                activeOutputTab === 'video'
                                  ? result.video
                                  : result.full;
                              onSendToVideoGenerator?.(promptToSend);
                            }}
                            className="px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 hover:from-pink-400 hover:via-purple-500 hover:to-indigo-500 transition shadow-lg shadow-pink-600/25 flex items-center justify-center gap-2 group active:scale-[0.98] cursor-pointer whitespace-nowrap"
                            title="Send start & end frames and enhanced prompt to Video Studio"
                          >
                            <Video className="w-4 h-4 text-pink-200 group-hover:scale-110 transition-transform flex-shrink-0" />
                            <span>Send to Video Generator</span>
                            <ArrowRight className="w-3.5 h-3.5 text-white/80 group-hover:translate-x-0.5 transition-transform flex-shrink-0" />
                          </button>
                        </div>
                      </div>
                    </>
                  )}


                  {/* Body State C: Idle / Awaiting Generation */}
                  {!result && !isGenerating && (
                    <div className="p-8 flex flex-col items-center justify-center text-center flex-1 my-auto">
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-pink-500/15 to-purple-600/15 border border-pink-500/30 flex items-center justify-center text-pink-400 mb-4 shadow-lg shadow-pink-500/10">
                        <Film className="w-8 h-8" />
                      </div>
                      <h3 className="text-base font-bold text-white mb-1.5">
                        WAN 3.0 Interpolation Prompt Ready
                      </h3>
                      <p className="text-xs text-neutral-400 max-w-sm mb-6 leading-relaxed">
                        Configure your keyframes above, refine your narrative intent on the left, and click <strong className="text-pink-300 font-semibold">Enhance Prompt with AI</strong> to generate your cinematic prompt here.
                      </p>

                      <div className="grid grid-cols-2 gap-2.5 w-full max-w-sm text-left">
                        <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-[11px]">
                          <span className="font-semibold text-pink-300 block mb-0.5">Visual Delta</span>
                          <span className="text-neutral-400 text-[10px]">Morphological &amp; color shifts between A &amp; B</span>
                        </div>
                        <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-[11px]">
                          <span className="font-semibold text-purple-300 block mb-0.5">Cinematics</span>
                          <span className="text-neutral-400 text-[10px]">Camera tracking, pans, orbits, and lighting</span>
                        </div>
                        <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-[11px]">
                          <span className="font-semibold text-indigo-300 block mb-0.5">Dialogue Cues</span>
                          <span className="text-neutral-400 text-[10px]">Explicit character attribution &amp; delivery</span>
                        </div>
                        <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-[11px]">
                          <span className="font-semibold text-emerald-300 block mb-0.5">Foley Audio</span>
                          <span className="text-neutral-400 text-[10px]">Timestamped SFX and acoustic atmosphere</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
  );
}
