import React from 'react';
import { KeyframeChatbot } from './KeyframeChatbot';
import { useKeyframeStudio } from './keyframe/useKeyframeStudio';
import type { KeyframeGeneratorProps } from './keyframe/types';
import { ControlsColumn } from './keyframe/ControlsColumn';
import { PreviewColumn } from './keyframe/PreviewColumn';
import { ZoomLightbox } from './keyframe/ZoomLightbox';
export { detectNearestAspectRatio } from './keyframe/aspectRatio';

export const KeyframeGenerator: React.FC<KeyframeGeneratorProps> = (props) => {
  const studio = useKeyframeStudio(props);
  const {
    onShowToast,
    prompt,
    imageSize,
    aspectRatio,
    generatedImage,
    generatedMime,
    isZoomModalOpen,
    editPrompt,
    copilotRef,
    copilotInitialQuery,
    setCopilotInitialQuery,
    handleApplyInitialPrompt,
    handleApplyEditPrompt,
    uploadInputRef,
    processUploadedFile,
    handleUploadCustomImage,
  } = studio;

  return (
    <div className="flex flex-col gap-6">
      <input
        ref={uploadInputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        className="hidden"
        onChange={handleUploadCustomImage}
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Controls Column: Keyframe Details Frame (order-2 on mobile, order-1 on desktop) */}
        <ControlsColumn studio={studio} />

        {/* Preview & Keyframe Binding Column: Rendered Preview Frame (order-1 on mobile, order-2 on desktop) */}
        <PreviewColumn studio={studio} />
      </div>

      {/* Transformation Scenario & Prompt Copilot - Positioned below Keyframe Details & Rendered Preview in Desktop View */}
      <div ref={copilotRef} className="w-full">
        <KeyframeChatbot
          currentPrompt={prompt}
          currentEditPrompt={editPrompt}
          activeImage={generatedImage}
          activeImageMime={generatedMime}
          imageSize={imageSize}
          aspectRatio={aspectRatio}
          onApplyInitialPrompt={handleApplyInitialPrompt}
          onApplyEditPrompt={handleApplyEditPrompt}
          onShowToast={onShowToast}
          isEmbedded={true}
          initialQuery={copilotInitialQuery}
          onClearInitialQuery={() => setCopilotInitialQuery(null)}
          onUploadImage={(file) => processUploadedFile(file, 'reverse_prompt')}
        />
      </div>

      {/* Full-Screen Zoom Lightbox Modal for Rendered Preview with Before/After Comparison */}
      {isZoomModalOpen && generatedImage && <ZoomLightbox studio={studio} />}
    </div>
  );
};
