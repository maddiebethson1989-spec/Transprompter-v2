import React from 'react';
import { useKeyframeChatbot } from './keyframe-chatbot/useKeyframeChatbot';
import type { KeyframeChatbotProps } from './keyframe-chatbot/types';
import { ChatHeader } from './keyframe-chatbot/ChatHeader';
import { QuickIdeasDrawer } from './keyframe-chatbot/QuickIdeasDrawer';
import { MethodologyGuide } from './keyframe-chatbot/MethodologyGuide';
import { ChatSubheader } from './keyframe-chatbot/ChatSubheader';
import { MessageThread } from './keyframe-chatbot/MessageThread';
import { SuggestionPills } from './keyframe-chatbot/SuggestionPills';
import { ChatInputBar } from './keyframe-chatbot/ChatInputBar';
export { generateRandomizedIdeaPrompt } from './keyframe-chatbot/randomIdeas';

export const KeyframeChatbot: React.FC<KeyframeChatbotProps> = (props) => {
  const studio = useKeyframeChatbot(props);
  const { isEmbedded, showMethodologyGuide, showQuickIdeas } = studio;

  return (
    <div
      className={`trans-card border-purple-500/25 overflow-hidden flex flex-col shadow-2xl ${isEmbedded ? 'min-h-[640px]' : 'h-full max-h-[85vh]'}`}
    >
      {/* Merged Frame Header: Title, Description, Model Selector & Role Selection matching VFX Director */}
      <ChatHeader studio={studio} />

      {/* Expandable Quick Ideas Drawer */}
      {showQuickIdeas && <QuickIdeasDrawer studio={studio} />}


      {/* Expandable Methodology Guide Box */}
      {showMethodologyGuide && <MethodologyGuide studio={studio} />}

      {/* Chat Subheader Bar matching VFX Director */}
      <ChatSubheader studio={studio} />

      {/* Messages Thread */}
      <MessageThread studio={studio} />

      {/* Quick Suggestion Pills matching VFX Director */}
      <SuggestionPills studio={studio} />

      {/* Input Bar matching VFX Director */}
      <ChatInputBar studio={studio} />
    </div>
  );
};
