import { useState, useEffect } from 'react';
import { Film, Image as ImageIcon, Key, Video } from 'lucide-react';
import { GeminiKeyModal, GeminiKeyStatus, AtlasCloudKeyStatus } from '../GeminiKeyModal';
import { safeFetchJson, getStoredGeminiApiKey, getStoredAtlasCloudApiKey } from '../../utils/safeApi';

export type TabView = 'enhancer' | 'video_studio' | 'keyframe_gen';

interface AppHeaderProps {
  activeTab: TabView;
  onTabChange: (tab: TabView) => void;
}

export function AppHeader({ activeTab, onTabChange }: AppHeaderProps) {
  const [isKeyModalOpen, setIsKeyModalOpen] = useState(false);
  const [keyStatus, setKeyStatus] = useState<GeminiKeyStatus | null>(null);
  const [atlasStatus, setAtlasStatus] = useState<AtlasCloudKeyStatus | null>(null);

  const fetchStatuses = async () => {
    // 1. Fetch Gemini status
    try {
      const data = await safeFetchJson<GeminiKeyStatus>('/api/gemini/status');
      setKeyStatus(data);
    } catch {
      const stored = getStoredGeminiApiKey();
      if (stored) {
        setKeyStatus({
          configured: true,
          isCustom: true,
          source: 'uploaded',
          maskedKey: stored.length > 8 ? `${stored.slice(0, 6)}••••••••${stored.slice(-4)}` : '••••••••',
        });
      }
    }

    // 2. Fetch AtlasCloud status
    try {
      const atlasData = await safeFetchJson<AtlasCloudKeyStatus>('/api/atlascloud/status');
      setAtlasStatus(atlasData);
    } catch {
      const storedAtlas = getStoredAtlasCloudApiKey();
      if (storedAtlas) {
        setAtlasStatus({
          configured: true,
          isCustom: true,
          source: 'uploaded',
          maskedKey: storedAtlas.length > 8 ? `${storedAtlas.slice(0, 6)}••••••••${storedAtlas.slice(-4)}` : '••••••••',
        });
      }
    }
  };

  useEffect(() => {
    fetchStatuses();
  }, []);

  const hasAnyKey = keyStatus?.configured || atlasStatus?.configured;
  const hasBothKeys = keyStatus?.configured && atlasStatus?.configured;

  return (
    <>
      <header className="sticky top-0 z-50 bg-[#0a0a0f]/90 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-3 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between py-2.5 md:py-0 md:h-16 gap-2.5 md:gap-4">
            {/* Top row in mobile: Logo & Brand + Mobile Key Button */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="relative w-8 h-8 flex-shrink-0 flex items-center justify-center">
                  <svg className="w-8 h-8" viewBox="0 0 32 32" fill="none">
                    <circle cx="16" cy="16" r="15" stroke="url(#hGrad1)" strokeWidth="2" />
                    <path d="M10 16 C10 10, 22 10, 22 16 C22 22, 10 22, 10 16Z" fill="url(#hGrad2)" />
                    <circle cx="16" cy="16" r="4" fill="url(#hGrad1)" />
                    <defs>
                      <linearGradient id="hGrad1" x1="0" y1="0" x2="32" y2="32">
                        <stop offset="0%" stopColor="#f472b6" />
                        <stop offset="100%" stopColor="#a855f7" />
                      </linearGradient>
                      <linearGradient id="hGrad2" x1="0" y1="0" x2="32" y2="32">
                        <stop offset="0%" stopColor="#f472b6" stopOpacity="0.4" />
                        <stop offset="100%" stopColor="#a855f7" stopOpacity="0.4" />
                      </linearGradient>
                    </defs>
                  </svg>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-sm sm:text-base tracking-tight text-white whitespace-nowrap">
                    Transprompter <span className="gradient-text font-black">2</span>
                  </span>
                </div>
              </div>

              {/* Mobile Key Button */}
              <div className="md:hidden">
                <button
                  type="button"
                  onClick={() => setIsKeyModalOpen(true)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#111118] hover:bg-[#181824] border border-white/10 text-xs font-semibold text-neutral-300 hover:text-white transition active:scale-95"
                  title="Configure Gemini & AtlasCloud API Keys"
                >
                  <Key className="w-3.5 h-3.5 text-pink-400" />
                  <span className="text-[11px]">API Keys</span>
                  <span
                    className={`w-2 h-2 rounded-full ml-0.5 ${
                      hasBothKeys
                        ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]'
                        : hasAnyKey
                        ? 'bg-amber-400 shadow-[0_0_6px_rgba(251,191,36,0.8)]'
                        : 'bg-neutral-600'
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Navigation Mode Switcher - 3 Accessible Tabs on both mobile & desktop */}
            <nav
              aria-label="Navigation Tabs"
              className="flex items-center bg-[#111118] p-1 rounded-xl border border-white/10 w-full md:w-auto shadow-inner overflow-x-auto no-scrollbar gap-1"
            >
              {/* TAB 1: I2V Enhancer */}
              <button
                type="button"
                onClick={() => onTabChange('enhancer')}
                className={`flex-1 md:flex-initial px-2.5 sm:px-3 py-2 sm:py-1.5 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 whitespace-nowrap ${
                  activeTab === 'enhancer'
                    ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md shadow-pink-500/25 font-bold'
                    : 'text-neutral-400 hover:text-white hover:bg-white/5'
                }`}
                title="I2V Interpolation Prompt Enhancer"
              >
                <Film className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="inline">I2V Enhancer</span>
              </button>

              {/* TAB 2: Video Studio (Between I2V Enhancer and Keyframe Studio) */}
              <button
                type="button"
                onClick={() => onTabChange('video_studio')}
                className={`flex-1 md:flex-initial px-2.5 sm:px-3 py-2 sm:py-1.5 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 whitespace-nowrap ${
                  activeTab === 'video_studio'
                    ? 'bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 text-white shadow-md shadow-pink-500/25 font-bold'
                    : 'text-neutral-400 hover:text-white hover:bg-white/5'
                }`}
                title="WAN 3.0 Video Studio & Generation"
              >
                <Video className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="inline">Video Studio</span>
                <span className="hidden xs:inline-block text-[9px] bg-purple-400/20 text-purple-300 px-1 py-0.2 rounded font-mono">
                  WAN 3.0
                </span>
              </button>

              {/* TAB 3: Keyframe Studio */}
              <button
                type="button"
                onClick={() => onTabChange('keyframe_gen')}
                className={`flex-1 md:flex-initial px-2.5 sm:px-3 py-2 sm:py-1.5 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 whitespace-nowrap ${
                  activeTab === 'keyframe_gen'
                    ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md shadow-pink-500/25 font-bold'
                    : 'text-neutral-400 hover:text-white hover:bg-white/5'
                }`}
                title="Keyframe Studio & Image Editor"
              >
                <ImageIcon className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="inline">Keyframe Studio</span>
                <span className="hidden xs:inline-block text-[9px] bg-pink-400/20 text-pink-300 px-1 py-0.2 rounded font-mono">
                  1K-4K
                </span>
              </button>
            </nav>


            {/* Desktop Actions: Unified API Key Manager Button */}
            <div className="hidden md:flex items-center gap-3">
              <button
                type="button"
                onClick={() => setIsKeyModalOpen(true)}
                className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-[#111118] hover:bg-[#181826] border border-white/10 hover:border-pink-500/40 text-xs font-semibold text-neutral-300 hover:text-white transition shadow-sm group cursor-pointer"
                title="Upload or configure Gemini & AtlasCloud API Keys"
              >
                <div className="relative flex items-center justify-center">
                  <Key className="w-3.5 h-3.5 text-pink-400 group-hover:rotate-12 transition-transform" />
                </div>
                <span>API Keys</span>

                {/* Status Pills */}
                <div className="flex items-center gap-2 pl-2 border-l border-white/10 text-[10px] font-mono">
                  <span className="flex items-center gap-1">
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        keyStatus?.configured ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]' : 'bg-neutral-500'
                      }`}
                    />
                    <span className="text-neutral-400">Gemini</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        atlasStatus?.configured ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]' : 'bg-neutral-500'
                      }`}
                    />
                    <span className="text-neutral-400">AtlasCloud</span>
                  </span>
                </div>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Unified API Key Configuration Modal */}
      <GeminiKeyModal
        isOpen={isKeyModalOpen}
        onClose={() => setIsKeyModalOpen(false)}
        onKeyUpdated={(st) => setKeyStatus(st)}
        onAtlasKeyUpdated={(st) => setAtlasStatus(st)}
      />
    </>
  );
}
